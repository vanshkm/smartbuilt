"use client"

import type React from "react"

import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  Building2,
  Calendar,
  LayoutDashboard,
  MessageSquare,
  Ruler,
  Settings,
  ClipboardList,
  MapPin,
  Users,
  CheckSquare,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { useLanguage } from "@/contexts/language-context"

interface SidebarNavProps extends React.HTMLAttributes<HTMLElement> {
  items: {
    href: string
    title: string
    icon: React.ComponentType<{ className?: string }>
  }[]
}

export function ContractorSidebar({ className }: React.HTMLAttributes<HTMLElement>) {
  const { t } = useLanguage()

  const items = [
    {
      href: "/contractor-dashboard",
      title: t("dashboard"),
      icon: LayoutDashboard,
    },
    {
      href: "/contractor-dashboard/projects",
      title: t("projects"),
      icon: Building2,
    },
    {
      href: "/contractor-dashboard/tasks",
      title: t("tasks"),
      icon: ClipboardList,
    },
    {
      href: "/contractor-dashboard/todo",
      title: t("todoList"),
      icon: CheckSquare,
    },
    {
      href: "/contractor-dashboard/calendar",
      title: t("calendar"),
      icon: Calendar,
    },
    {
      href: "/contractor-dashboard/material-estimation",
      title: t("materialEstimation"),
      icon: Ruler,
    },
    {
      href: "/contractor-dashboard/map",
      title: t("map"),
      icon: MapPin,
    },
    {
      href: "/contractor-dashboard/messages",
      title: t("messages"),
      icon: MessageSquare,
    },
    {
      href: "/contractor-dashboard/profile",
      title: t("profile"),
      icon: Users,
    },
    {
      href: "/contractor-dashboard/settings",
      title: t("settings"),
      icon: Settings,
    },
  ]

  return (
    <nav className={cn("hidden border-r bg-background lg:block lg:w-64 lg:flex-shrink-0", className)}>
      <ScrollArea className="py-6 h-full">
        <div className="px-4 py-2">
          <h2 className="mb-2 px-2 text-lg font-semibold tracking-tight">{t("dashboard")}</h2>
          <SidebarNav items={items} />
        </div>
      </ScrollArea>
    </nav>
  )
}

function SidebarNav({ items, className }: SidebarNavProps) {
  const pathname = usePathname()

  return (
    <div className={cn("grid gap-1", className)}>
      {items.map((item) => {
        const Icon = item.icon
        return (
          <Button
            key={item.href}
            variant={pathname === item.href ? "secondary" : "ghost"}
            className={cn(
              "justify-start",
              pathname === item.href ? "bg-amber-500/10 text-amber-500 hover:bg-amber-500/20" : "",
            )}
            asChild
          >
            <Link href={item.href}>
              <Icon className="mr-2 h-4 w-4" />
              {item.title}
            </Link>
          </Button>
        )
      })}
    </div>
  )
}

