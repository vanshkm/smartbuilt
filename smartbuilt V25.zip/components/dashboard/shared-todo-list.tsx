"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import { Plus, Trash2, Edit, Check, X } from "lucide-react"
import { useLanguage } from "@/contexts/language-context"
import { useToast } from "@/hooks/use-toast"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// This would typically come from a database or API
// For demo purposes, we're using localStorage to simulate syncing
interface TodoItem {
  id: string
  text: string
  completed: boolean
  createdBy: string
  createdAt: string // Store as ISO string to avoid serialization issues
  assignedTo: string[]
  projectId?: string
  projectName?: string
}

export function SharedTodoList() {
  const { t } = useLanguage()
  const { toast } = useToast()
  const [todos, setTodos] = useState<TodoItem[]>([])
  const [newTodoText, setNewTodoText] = useState("")
  const [userType, setUserType] = useState<"architect" | "contractor" | "client">("architect")
  const [userName, setUserName] = useState("")
  const [editingId, setEditingId] = useState<string | null>(null)
  const [editText, setEditText] = useState("")
  const [selectedProject, setSelectedProject] = useState<string>("")
  const [projects, setProjects] = useState<{ id: string; name: string }[]>([])
  const [assignTo, setAssignTo] = useState<string[]>([])

  // Determine user type based on URL path
  useEffect(() => {
    if (typeof window !== "undefined") {
      const path = window.location.pathname
      if (path.includes("contractor")) {
        setUserType("contractor")
      } else if (path.includes("client")) {
        setUserType("client")
      } else {
        setUserType("architect")
      }

      // Get user name from localStorage
      const storedName = localStorage.getItem("userName") || "User"
      setUserName(storedName)
    }
  }, [])

  // Load todos from localStorage on component mount
  useEffect(() => {
    // Load mock projects first
    const mockProjects = [
      { id: "1", name: "Lakeside Villa" },
      { id: "2", name: "Tech Hub Offices" },
      { id: "3", name: "Urban Apartment Complex" },
      { id: "4", name: "Modern Residential Complex" },
      { id: "5", name: "Waterfront Restaurant" },
    ]
    setProjects(mockProjects)

    // Then load todos
    const storedTodos = localStorage.getItem("sharedTodos")
    if (storedTodos) {
      try {
        const parsedTodos = JSON.parse(storedTodos)
        setTodos(parsedTodos)
      } catch (e) {
        console.error("Error parsing todos from localStorage", e)
      }
    } else {
      // Set some initial demo todos if none exist
      const initialTodos: TodoItem[] = [
        {
          id: "1",
          text: "Review project proposal for Lakeside Villa",
          completed: false,
          createdBy: "architect",
          createdAt: new Date().toISOString(),
          assignedTo: ["architect", "client"],
          projectId: "1",
          projectName: "Lakeside Villa",
        },
        {
          id: "2",
          text: "Schedule site visit for Tech Hub Offices",
          completed: true,
          createdBy: "contractor",
          createdAt: new Date(Date.now() - 86400000).toISOString(), // 1 day ago
          assignedTo: ["architect", "contractor", "client"],
          projectId: "2",
          projectName: "Tech Hub Offices",
        },
        {
          id: "3",
          text: "Submit material specifications for Urban Apartment Complex",
          completed: false,
          createdBy: "architect",
          createdAt: new Date(Date.now() - 172800000).toISOString(), // 2 days ago
          assignedTo: ["contractor"],
          projectId: "3",
          projectName: "Urban Apartment Complex",
        },
      ]
      setTodos(initialTodos)
      localStorage.setItem("sharedTodos", JSON.stringify(initialTodos))
    }
  }, [])

  // Save todos to localStorage whenever they change
  useEffect(() => {
    if (todos.length > 0) {
      localStorage.setItem("sharedTodos", JSON.stringify(todos))
    }
  }, [todos])

  const createNotification = (title: string, description: string, type: string, relatedId?: string) => {
    // Get existing notifications
    const storedNotifications = localStorage.getItem("notifications")
    let notifications = []

    if (storedNotifications) {
      try {
        notifications = JSON.parse(storedNotifications)
      } catch (e) {
        console.error("Error parsing notifications", e)
      }
    }

    // Create a new notification
    const newNotification = {
      id: Date.now().toString(),
      title,
      description,
      time: "Just now",
      read: false,
      type,
      relatedId,
    }

    notifications.unshift(newNotification)

    // Save back to localStorage
    localStorage.setItem("notifications", JSON.stringify(notifications))
  }

  const addTodo = () => {
    if (newTodoText.trim() === "") return
    if (!selectedProject) {
      toast({
        title: "Project Required",
        description: "Please select a project for this task",
        variant: "destructive",
      })
      return
    }

    if (assignTo.length === 0) {
      toast({
        title: "Assignee Required",
        description: "Please assign this task to at least one role",
        variant: "destructive",
      })
      return
    }

    const selectedProjectObj = projects.find((p) => p.id === selectedProject)

    const newTodo: TodoItem = {
      id: Date.now().toString(),
      text: newTodoText,
      completed: false,
      createdBy: userType,
      createdAt: new Date().toISOString(),
      assignedTo: assignTo,
      projectId: selectedProject,
      projectName: selectedProjectObj?.name,
    }

    const updatedTodos = [...todos, newTodo]
    setTodos(updatedTodos)
    setNewTodoText("")
    setSelectedProject("")
    setAssignTo([])

    // Create notification for assigned users
    createNotification("New Task Assigned", `${userName} assigned a new task: ${newTodoText}`, "todo", newTodo.id)

    toast({
      title: "Task Created",
      description: "The task has been created and assigned successfully.",
    })
  }

  const toggleTodo = (id: string) => {
    const todoToToggle = todos.find((todo) => todo.id === id)
    if (!todoToToggle) return

    const updatedTodos = todos.map((todo) => {
      if (todo.id === id) {
        const completed = !todo.completed

        // Create notification for task completion if it's being completed
        if (completed) {
          createNotification("Task Completed", `${userName} completed the task: ${todo.text}`, "todo", todo.id)
        }

        return { ...todo, completed }
      }
      return todo
    })

    setTodos(updatedTodos)
  }

  const startEditing = (todo: TodoItem) => {
    setEditingId(todo.id)
    setEditText(todo.text)
  }

  const saveEdit = (id: string) => {
    if (editText.trim() === "") return

    const updatedTodos = todos.map((todo) => {
      if (todo.id === id) {
        // Create notification for task update
        createNotification("Task Updated", `${userName} updated the task: ${editText}`, "todo", todo.id)

        return { ...todo, text: editText }
      }
      return todo
    })

    setTodos(updatedTodos)
    setEditingId(null)
    setEditText("")
  }

  const cancelEdit = () => {
    setEditingId(null)
    setEditText("")
  }

  const deleteTodo = (id: string) => {
    // Create notification for task deletion
    const todoToDelete = todos.find((todo) => todo.id === id)
    if (todoToDelete) {
      createNotification("Task Deleted", `${userName} deleted the task: ${todoToDelete.text}`, "todo", id)
    }

    setTodos(todos.filter((todo) => todo.id !== id))
  }

  // Filter todos relevant to the current user type
  const relevantTodos = todos.filter((todo) => todo.assignedTo.includes(userType) || todo.createdBy === userType)

  const handleAssigneeToggle = (role: string) => {
    setAssignTo((prev) => {
      if (prev.includes(role)) {
        return prev.filter((r) => r !== role)
      } else {
        return [...prev, role]
      }
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>{t("sharedTodoList")}</CardTitle>
        <CardDescription>{t("todoListDescription")}</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4 mb-4">
          <Input
            placeholder={t("addNewTodo")}
            value={newTodoText}
            onChange={(e) => setNewTodoText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault()
                addTodo()
              }
            }}
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
            <Select value={selectedProject} onValueChange={setSelectedProject}>
              <SelectTrigger>
                <SelectValue placeholder="Select project" />
              </SelectTrigger>
              <SelectContent>
                {projects.map((project) => (
                  <SelectItem key={project.id} value={project.id}>
                    {project.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <div className="flex flex-wrap gap-2">
              <Button
                size="sm"
                variant={assignTo.includes("architect") ? "default" : "outline"}
                onClick={() => handleAssigneeToggle("architect")}
              >
                Architect
              </Button>
              <Button
                size="sm"
                variant={assignTo.includes("contractor") ? "default" : "outline"}
                onClick={() => handleAssigneeToggle("contractor")}
              >
                Contractor
              </Button>
              <Button
                size="sm"
                variant={assignTo.includes("client") ? "default" : "outline"}
                onClick={() => handleAssigneeToggle("client")}
              >
                Client
              </Button>
            </div>
          </div>

          <Button onClick={addTodo} className="w-full">
            <Plus className="h-4 w-4 mr-2" /> Add Task
          </Button>
        </div>

        <div className="space-y-2">
          {relevantTodos.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4">{t("noTodosYet")}</p>
          ) : (
            relevantTodos.map((todo) => (
              <div key={todo.id} className="flex items-start space-x-2 p-3 rounded-md hover:bg-muted/50 border">
                {editingId === todo.id ? (
                  <div className="flex-1 space-y-2">
                    <Input value={editText} onChange={(e) => setEditText(e.target.value)} autoFocus />
                    <div className="flex space-x-2">
                      <Button size="sm" onClick={() => saveEdit(todo.id)}>
                        <Check className="h-3 w-3 mr-1" /> Save
                      </Button>
                      <Button size="sm" variant="outline" onClick={cancelEdit}>
                        <X className="h-3 w-3 mr-1" /> Cancel
                      </Button>
                    </div>
                  </div>
                ) : (
                  <>
                    <Checkbox
                      id={`todo-${todo.id}`}
                      checked={todo.completed}
                      onCheckedChange={() => toggleTodo(todo.id)}
                      className="mt-1"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-start">
                        <label
                          htmlFor={`todo-${todo.id}`}
                          className={`text-sm font-medium ${todo.completed ? "line-through text-muted-foreground" : ""}`}
                        >
                          {todo.text}
                        </label>
                        <div className="flex space-x-1">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6 text-muted-foreground hover:text-primary"
                            onClick={() => startEditing(todo)}
                          >
                            <Edit className="h-3 w-3" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6 text-muted-foreground hover:text-destructive"
                            onClick={() => deleteTodo(todo.id)}
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                      <div className="flex items-center text-xs text-muted-foreground mt-1">
                        <span>
                          {t("createdBy")}: {todo.createdBy.charAt(0).toUpperCase() + todo.createdBy.slice(1)}
                        </span>
                        <span className="mx-2">•</span>
                        <span>{new Date(todo.createdAt).toLocaleDateString()}</span>
                      </div>
                      {todo.projectName && (
                        <div className="mt-1">
                          <span className="text-xs px-2 py-1 bg-primary/10 rounded-full">{todo.projectName}</span>
                        </div>
                      )}
                      <div className="mt-2 flex flex-wrap gap-1">
                        {todo.assignedTo.map((role) => (
                          <span key={role} className="text-xs px-2 py-0.5 bg-muted rounded-full">
                            {role.charAt(0).toUpperCase() + role.slice(1)}
                          </span>
                        ))}
                      </div>
                    </div>
                  </>
                )}
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  )
}

