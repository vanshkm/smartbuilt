"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  Building2,
  Calendar,
  ClipboardList,
  Home,
  Layers,
  Map,
  MessageSquare,
  Ruler,
  Settings,
  Users,
  CheckSquare,
} from "lucide-react"
import { useLanguage } from "@/contexts/language-context"

export function Sidebar() {
  const pathname = usePathname()
  const { t } = useLanguage()

  const isActive = (path: string) => {
    return pathname === path
  }

  const links = [
    { href: "/dashboard", label: t("dashboard"), icon: Home },
    { href: "/dashboard/projects", label: t("projects"), icon: Building2 },
    { href: "/dashboard/tasks", label: t("tasks"), icon: ClipboardList },
    { href: "/dashboard/todo", label: t("todoList"), icon: CheckSquare },
    { href: "/dashboard/team", label: t("team"), icon: Users },
    { href: "/dashboard/calendar", label: t("calendar"), icon: Calendar },
    { href: "/dashboard/material-estimation", label: t("materialEstimation"), icon: Ruler },
    { href: "/dashboard/resources", label: t("resources"), icon: Layers },
    { href: "/dashboard/map", label: t("map"), icon: Map },
    { href: "/dashboard/messages", label: t("messages"), icon: MessageSquare },
    { href: "/dashboard/profile", label: t("profile"), icon: Settings },
  ]

  return (
    <div className="hidden border-r bg-sidebar-background lg:block w-64 sidebar">
      <div className="flex h-full max-h-screen flex-col gap-2">
        <div className="flex-1 overflow-auto py-2">
          <nav className="grid items-start px-2 text-sm font-medium">
            {links.map((link, index) => {
              const Icon = link.icon
              return (
                <Link
                  key={index}
                  href={link.href}
                  className={`flex items-center gap-3 rounded-lg px-3 py-2 transition-all hover:text-primary ${
                    isActive(link.href)
                      ? "bg-primary/10 text-primary font-semibold"
                      : "text-muted-foreground hover:bg-primary/5"
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {link.label}
                </Link>
              )
            })}
          </nav>
        </div>
      </div>
    </div>
  )
}

