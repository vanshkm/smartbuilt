"use client"

export function RecentProjects() {
  const projects = [
    {
      id: 1,
      name: "Modern Residential Complex",
      client: "Horizon Developers",
      lastUpdated: "2 hours ago",
      progress: 75,
    },
    {
      id: 2,
      name: "Downtown Office Renovation",
      client: "Metro Business Solutions",
      lastUpdated: "Yesterday",
      progress: 45,
    },
    {
      id: 3,
      name: "Waterfront Restaurant",
      client: "Coastal Dining Group",
      lastUpdated: "3 days ago",
      progress: 90,
    },
    {
      id: 4,
      name: "Community Center",
      client: "Oakridge Municipality",
      lastUpdated: "1 week ago",
      progress: 30,
    },
  ]

  return (
    <div className="space-y-4">
      {projects.map((project) => (
        <div key={project.id} className="flex flex-col space-y-2 rounded-lg border p-4">
          <div className="flex justify-between">
            <h3 className="font-medium">{project.name}</h3>
            <span className="text-xs text-muted-foreground">{project.lastUpdated}</span>
          </div>
          <p className="text-sm text-muted-foreground">{project.client}</p>
          <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
            <div className="h-full bg-primary" style={{ width: `${project.progress}%` }} />
          </div>
          <div className="flex justify-between text-xs">
            <span>Progress</span>
            <span>{project.progress}%</span>
          </div>
        </div>
      ))}
    </div>
  )
}

