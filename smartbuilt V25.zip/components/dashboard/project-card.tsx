"use client"

import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Calendar, Clock, Users } from "lucide-react"

// Update the ProjectCard component to include a dialog for project details

// First, import the Dialog components
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

interface ProjectCardProps {
  title: string
  client: string
  progress: number
  dueDate: string
  team: number
  tasks: number
  image: string
}

export function ProjectCard({ title, client, progress, dueDate, team, tasks, image }: ProjectCardProps) {
  // Format the due date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return new Intl.DateTimeFormat("en-US", {
      month: "short",
      day: "numeric",
      year: "numeric",
    }).format(date)
  }

  // Then modify the return statement to wrap the Card in a Dialog
  // Replace the entire return statement with:

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Card className="overflow-hidden transition-all hover:shadow-md cursor-pointer">
          <div className="aspect-video w-full overflow-hidden">
            <img
              src={image || "/placeholder.svg"}
              alt={title}
              className="h-full w-full object-cover transition-all hover:scale-105"
            />
          </div>
          <CardContent className="p-4">
            <h3 className="font-semibold">{title}</h3>
            <p className="text-sm text-muted-foreground">{client}</p>
            <div className="mt-4 space-y-2">
              <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                <div
                  className={`h-full ${
                    progress >= 90
                      ? "bg-green-500"
                      : progress >= 50
                        ? "bg-primary"
                        : progress >= 25
                          ? "bg-amber-500"
                          : "bg-destructive"
                  }`}
                  style={{ width: `${progress}%` }}
                />
              </div>
              <div className="flex justify-between text-xs">
                <span>Progress</span>
                <span>{progress}%</span>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between border-t p-4 text-xs text-muted-foreground">
            <div className="flex items-center">
              <Calendar className="mr-1 h-3.5 w-3.5" />
              {formatDate(dueDate)}
            </div>
            <div className="flex items-center">
              <Users className="mr-1 h-3.5 w-3.5" />
              {team}
            </div>
            <div className="flex items-center">
              <Clock className="mr-1 h-3.5 w-3.5" />
              {tasks} tasks
            </div>
          </CardFooter>
        </Card>
      </DialogTrigger>
      <DialogContent className="max-w-3xl">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>Client: {client}</DialogDescription>
        </DialogHeader>
        <div className="grid gap-6 py-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h3 className="font-medium mb-2">Project Gallery</h3>
              <div className="grid grid-cols-2 gap-2">
                {/* Project images - using placeholder images for now */}
                <img
                  src="/placeholder.svg?height=200&width=300"
                  alt="Project view 1"
                  className="rounded-md object-cover w-full h-32"
                />
                <img
                  src="/placeholder.svg?height=200&width=300"
                  alt="Project view 2"
                  className="rounded-md object-cover w-full h-32"
                />
                <img
                  src="/placeholder.svg?height=200&width=300"
                  alt="Project view 3"
                  className="rounded-md object-cover w-full h-32"
                />
                <img
                  src="/placeholder.svg?height=200&width=300"
                  alt="Project view 4"
                  className="rounded-md object-cover w-full h-32"
                />
              </div>
            </div>
            <div>
              <h3 className="font-medium mb-2">Project Details</h3>
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium">Completed Work</h4>
                  <ul className="mt-1 text-sm text-muted-foreground list-disc pl-5">
                    <li>Foundation and structural framework</li>
                    <li>Electrical wiring and plumbing</li>
                    <li>Exterior wall construction</li>
                    <li>Window installation</li>
                  </ul>
                </div>
                <div>
                  <h4 className="text-sm font-medium">Remaining Work</h4>
                  <ul className="mt-1 text-sm text-muted-foreground list-disc pl-5">
                    <li>Interior finishing and painting</li>
                    <li>Flooring installation</li>
                    <li>Kitchen and bathroom fixtures</li>
                    <li>Final inspections and approvals</li>
                  </ul>
                </div>
                <div>
                  <h4 className="text-sm font-medium">Project Stats</h4>
                  <div className="grid grid-cols-2 gap-2 mt-1">
                    <div className="text-sm">
                      <span className="text-muted-foreground">Due Date:</span>
                      <p>{formatDate(dueDate)}</p>
                    </div>
                    <div className="text-sm">
                      <span className="text-muted-foreground">Team Size:</span>
                      <p>{team} members</p>
                    </div>
                    <div className="text-sm">
                      <span className="text-muted-foreground">Tasks:</span>
                      <p>{tasks} total</p>
                    </div>
                    <div className="text-sm">
                      <span className="text-muted-foreground">Progress:</span>
                      <p>{progress}% complete</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

