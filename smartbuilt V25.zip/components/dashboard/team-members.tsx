"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

export function TeamMembers() {
  const members = [
    {
      id: 1,
      name: "Arjun Patel",
      role: "Senior Architect",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "AP",
      status: "online",
    },
    {
      id: 2,
      name: "Priya Sharma",
      role: "Project Manager",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "PS",
      status: "online",
    },
    {
      id: 3,
      name: "Vikram Mehta",
      role: "Interior Designer",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "VM",
      status: "offline",
    },
    {
      id: 4,
      name: "Neha Gupta",
      role: "Structural Engineer",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "NG",
      status: "online",
    },
    {
      id: 5,
      name: "Raj Singh",
      role: "Landscape Architect",
      avatar: "/placeholder.svg?height=32&width=32",
      initials: "RS",
      status: "offline",
    },
  ]

  return (
    <div className="space-y-4">
      {members.map((member) => (
        <div key={member.id} className="flex items-center gap-4">
          <div className="relative">
            <Avatar>
              <AvatarImage src={member.avatar} alt={member.name} />
              <AvatarFallback>{member.initials}</AvatarFallback>
            </Avatar>
            <span
              className={`absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full border-2 border-background ${
                member.status === "online" ? "bg-green-500" : "bg-muted"
              }`}
            />
          </div>
          <div>
            <p className="text-sm font-medium leading-none">{member.name}</p>
            <p className="text-xs text-muted-foreground">{member.role}</p>
          </div>
        </div>
      ))}
    </div>
  )
}

