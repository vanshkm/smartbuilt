"use client"

import { useRouter } from "next/navigation"
import { Bell, Menu, Search, Building2, X } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Sheet, SheetContent, SheetTrigger, SheetClose } from "@/components/ui/sheet"
import { ThemeSwitch } from "@/components/theme-switch"
import { Sidebar } from "@/components/dashboard/sidebar"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useEffect, useState } from "react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { useLanguage } from "@/contexts/language-context"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"

interface Notification {
  id: string
  title: string
  description: string
  time: string
  read: boolean
  type: string
  relatedId?: string
}

// Add this fallback function
function useLanguageSafe() {
  try {
    return useLanguage()
  } catch (e) {
    // Return a default implementation if context is not available
    return {
      language: "en" as const,
      setLanguage: () => {},
      t: (key: string) => key,
    }
  }
}

export function DashboardHeader() {
  const router = useRouter()
  const { t } = useLanguageSafe()
  const [userName, setUserName] = useState("")
  const [searchQuery, setSearchQuery] = useState("")
  const [showSearchResults, setShowSearchResults] = useState(false)
  const [showNotifications, setShowNotifications] = useState(false)
  const [isMobileSearchOpen, setIsMobileSearchOpen] = useState(false)
  const [notifications, setNotifications] = useState<Notification[]>([
    {
      id: "1",
      title: "New project proposal",
      description: "Vikram Mehta has submitted a new project proposal.",
      time: "10 minutes ago",
      read: false,
      type: "project",
    },
    {
      id: "2",
      title: "Task assigned",
      description: "Priya Sharma has assigned you a new task: Review floor plans.",
      time: "1 hour ago",
      read: false,
      type: "todo",
    },
    {
      id: "3",
      title: "Meeting reminder",
      description: "Client meeting with Horizon Developers in 30 minutes.",
      time: "2 hours ago",
      read: true,
      type: "system",
    },
  ])

  // Load user name and notifications on mount
  useEffect(() => {
    const storedName = localStorage.getItem("userName")
    if (storedName) {
      setUserName(storedName)
    }

    // Load notifications from localStorage
    const storedNotifications = localStorage.getItem("notifications")
    if (storedNotifications) {
      try {
        const parsedNotifications = JSON.parse(storedNotifications)
        if (Array.isArray(parsedNotifications) && parsedNotifications.length > 0) {
          setNotifications(parsedNotifications)
        }
      } catch (e) {
        console.error("Error parsing notifications", e)
      }
    } else {
      // Save initial notifications to localStorage
      localStorage.setItem("notifications", JSON.stringify(notifications))
    }
  }, [])

  // Set up polling for new notifications
  useEffect(() => {
    const checkForNotifications = () => {
      const storedNotifications = localStorage.getItem("notifications")
      if (storedNotifications) {
        try {
          const parsedNotifications = JSON.parse(storedNotifications)
          if (Array.isArray(parsedNotifications)) {
            setNotifications(parsedNotifications)
          }
        } catch (e) {
          console.error("Error parsing notifications", e)
        }
      }
    }

    const intervalId = setInterval(checkForNotifications, 5000)
    return () => clearInterval(intervalId)
  }, [])

  const unreadCount = notifications.filter((n) => !n.read).length

  const handleLogout = () => {
    localStorage.removeItem("isLoggedIn")
    localStorage.removeItem("userRole")
    localStorage.removeItem("userEmail")
    localStorage.removeItem("userName")
    router.push("/login")
  }

  const handleSearch = (e) => {
    if (e.key === "Enter" && searchQuery.trim() !== "") {
      setShowSearchResults(true)
    }
  }

  const handleMarkAsRead = (id: string) => {
    const updatedNotifications = notifications.map((notification) =>
      notification.id === id ? { ...notification, read: true } : notification,
    )

    setNotifications(updatedNotifications)
    localStorage.setItem("notifications", JSON.stringify(updatedNotifications))
  }

  const handleMarkAllAsRead = () => {
    const updatedNotifications = notifications.map((notification) => ({ ...notification, read: true }))
    setNotifications(updatedNotifications)
    localStorage.setItem("notifications", JSON.stringify(updatedNotifications))
  }

  const handleDeleteNotification = (id: string) => {
    const updatedNotifications = notifications.filter((notification) => notification.id !== id)
    setNotifications(updatedNotifications)
    localStorage.setItem("notifications", JSON.stringify(updatedNotifications))
  }

  // Mock search results
  const searchResults = [
    { type: "project", title: "Modern Residential Complex", link: "/dashboard/projects" },
    { type: "task", title: "Review floor plans", link: "/dashboard/tasks" },
    { type: "team", title: "Priya Sharma", link: "/dashboard/team" },
    { type: "document", title: "Building Code Reference Guide", link: "/dashboard/resources" },
  ].filter((result) => result.title.toLowerCase().includes(searchQuery.toLowerCase()))

  return (
    <header className="sticky top-0 z-50 flex h-16 items-center gap-2 md:gap-4 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 dashboard-header px-2 md:px-4">
      <Sheet>
        <SheetTrigger asChild>
          <Button variant="outline" size="icon" className="lg:hidden">
            <Menu className="h-5 w-5" />
            <span className="sr-only">Toggle navigation menu</span>
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-[80vw] max-w-xs p-0">
          <div className="flex items-center justify-between p-4 border-b">
            <div className="flex items-center gap-2">
              <Building2 className="h-5 w-5 text-primary" />
              <span className="font-semibold">SmartBuilt</span>
            </div>
            <SheetClose className="rounded-full p-1 hover:bg-muted">
              <X className="h-4 w-4" />
            </SheetClose>
          </div>
          <Sidebar />
        </SheetContent>
      </Sheet>

      <Link href="/" className="flex items-center gap-2 font-semibold">
        <Building2 className="h-6 w-6 text-primary" />
        <span className="text-lg font-bold hidden sm:inline">SmartBuilt Architect</span>
        <span className="text-lg font-bold sm:hidden">SmartBuilt</span>
      </Link>

      {/* Desktop Search */}
      <div className="relative hidden md:flex flex-1 md:grow-0 md:w-80">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          type="search"
          placeholder={t("search")}
          className="w-full pl-8 md:w-80"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          onKeyDown={handleSearch}
          onFocus={() => searchQuery && setShowSearchResults(true)}
        />
        {showSearchResults && searchQuery && (
          <div className="absolute top-full left-0 right-0 mt-1 bg-background border rounded-md shadow-lg z-50">
            <div className="p-2 border-b">
              <h3 className="text-sm font-medium">Search Results</h3>
            </div>
            {searchResults.length > 0 ? (
              <div className="max-h-80 overflow-auto">
                {searchResults.map((result, index) => (
                  <Link key={index} href={result.link} onClick={() => setShowSearchResults(false)}>
                    <div className="p-2 hover:bg-muted cursor-pointer">
                      <div className="font-medium text-sm">{result.title}</div>
                      <div className="text-xs text-muted-foreground capitalize">{result.type}</div>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="p-4 text-center text-muted-foreground">No results found for "{searchQuery}"</div>
            )}
            <div className="p-2 border-t text-right">
              <Button variant="ghost" size="sm" onClick={() => setShowSearchResults(false)}>
                Close
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Mobile Search Button */}
      <Button
        variant="ghost"
        size="icon"
        className="md:hidden"
        onClick={() => setIsMobileSearchOpen(!isMobileSearchOpen)}
      >
        <Search className="h-5 w-5" />
      </Button>

      {/* Mobile Search Overlay */}
      {isMobileSearchOpen && (
        <div className="fixed inset-0 bg-background z-50 p-4 flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-medium">Search</h2>
            <Button variant="ghost" size="icon" onClick={() => setIsMobileSearchOpen(false)}>
              <X className="h-5 w-5" />
            </Button>
          </div>
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder={t("search")}
              className="w-full pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={handleSearch}
              autoFocus
            />
          </div>
          <div className="flex-1 mt-4 overflow-auto">
            {searchQuery ? (
              searchResults.length > 0 ? (
                <div className="space-y-2">
                  {searchResults.map((result, index) => (
                    <Link
                      key={index}
                      href={result.link}
                      onClick={() => {
                        setIsMobileSearchOpen(false)
                        setShowSearchResults(false)
                      }}
                    >
                      <div className="p-3 border rounded-md hover:bg-muted">
                        <div className="font-medium">{result.title}</div>
                        <div className="text-sm text-muted-foreground capitalize">{result.type}</div>
                      </div>
                    </Link>
                  ))}
                </div>
              ) : (
                <div className="p-4 text-center text-muted-foreground">No results found for "{searchQuery}"</div>
              )
            ) : (
              <div className="p-4 text-center text-muted-foreground">
                Enter a search term to find projects, tasks, and more
              </div>
            )}
          </div>
        </div>
      )}

      <div className="ml-auto flex items-center gap-1 sm:gap-3">
        <ThemeSwitch />
        <Dialog open={showNotifications} onOpenChange={setShowNotifications}>
          <Button variant="outline" size="icon" className="relative" onClick={() => setShowNotifications(true)}>
            <Bell className="h-5 w-5" />
            <span className="sr-only">Notifications</span>
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 h-4 w-4 rounded-full bg-primary text-[10px] font-bold text-primary-foreground flex items-center justify-center">
                {unreadCount}
              </span>
            )}
          </Button>
          <DialogContent className="sm:max-w-[425px] w-[calc(100vw-2rem)] max-w-[calc(100vw-2rem)] sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle className="flex items-center justify-between">
                <span>Notifications</span>
                {unreadCount > 0 && (
                  <Button variant="ghost" size="sm" onClick={handleMarkAllAsRead}>
                    Mark all as read
                  </Button>
                )}
              </DialogTitle>
            </DialogHeader>
            <div className="max-h-[60vh] overflow-auto">
              {notifications.length > 0 ? (
                <div className="space-y-2">
                  {notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-3 rounded-md ${notification.read ? "bg-background" : "bg-muted"} relative group`}
                    >
                      <div className="flex justify-between">
                        <h3 className="font-medium text-sm">{notification.title}</h3>
                        <span className="text-xs text-muted-foreground">{notification.time}</span>
                      </div>
                      <p className="text-sm mt-1">{notification.description}</p>
                      <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
                        {!notification.read && (
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6"
                            onClick={() => handleMarkAsRead(notification.id)}
                          >
                            <span className="sr-only">Mark as read</span>✓
                          </Button>
                        )}
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6 text-muted-foreground hover:text-destructive"
                          onClick={() => handleDeleteNotification(notification.id)}
                        >
                          <span className="sr-only">Delete</span>×
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="py-8 text-center text-muted-foreground">No notifications</div>
              )}
            </div>
          </DialogContent>
        </Dialog>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="rounded-full">
              <Avatar className="h-8 w-8">
                <AvatarImage src="/placeholder.svg?height=32&width=32" alt="Avatar" />
                <AvatarFallback>
                  {userName
                    .split(" ")
                    .map((n) => n[0] || "")
                    .join("")}
                </AvatarFallback>
              </Avatar>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>{t("profile")}</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem asChild>
              <Link href="/dashboard/profile">{t("profile")}</Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link href="/dashboard/profile?tab=settings">{t("settings")}</Link>
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={handleLogout}>{t("logout")}</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  )
}

