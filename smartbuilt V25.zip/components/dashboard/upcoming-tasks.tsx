"use client"

import { CheckCircle2, Clock } from "lucide-react"

export function UpcomingTasks() {
  const tasks = [
    {
      id: 1,
      title: "Review floor plans for Horizon Residential",
      dueDate: "Today, 2:00 PM",
      priority: "High",
    },
    {
      id: 2,
      title: "Client meeting with Metro Business Solutions",
      dueDate: "Tomorrow, 10:00 AM",
      priority: "High",
    },
    {
      id: 3,
      title: "Submit permit applications for Urban Park project",
      dueDate: "Wed, 12:00 PM",
      priority: "Medium",
    },
    {
      id: 4,
      title: "Material selection for Luxury Hotel project",
      dueDate: "Thu, 3:00 PM",
      priority: "Medium",
    },
    {
      id: 5,
      title: "Team coordination meeting",
      dueDate: "Fri, 9:00 AM",
      priority: "Low",
    },
  ]

  return (
    <div className="space-y-4">
      {tasks.map((task) => (
        <div key={task.id} className="flex items-start gap-2 rounded-lg border p-3">
          <div className="mt-0.5">
            <CheckCircle2 className="h-5 w-5 text-muted-foreground" />
          </div>
          <div className="flex-1 space-y-1">
            <div className="font-medium">{task.title}</div>
            <div className="flex items-center text-xs text-muted-foreground">
              <Clock className="mr-1 h-3 w-3" />
              {task.dueDate}
            </div>
          </div>
          <div
            className={`text-xs px-2 py-1 rounded-full ${
              task.priority === "High"
                ? "bg-destructive/10 text-destructive"
                : task.priority === "Medium"
                  ? "bg-amber-500/10 text-amber-500"
                  : "bg-green-500/10 text-green-500"
            }`}
          >
            {task.priority}
          </div>
        </div>
      ))}
    </div>
  )
}

