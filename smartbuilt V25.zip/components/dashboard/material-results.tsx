"use client"

export function MaterialResults() {
  const materials = [
    {
      category: "Concrete",
      items: [
        { name: "Foundation Concrete", quantity: "45 cubic yards", cost: "$6,750" },
        { name: "Slab Concrete", quantity: "30 cubic yards", cost: "$4,500" },
      ],
    },
    {
      category: "Masonry",
      items: [
        { name: "Bricks", quantity: "8,500 pieces", cost: "$5,950" },
        { name: "Mortar", quantity: "85 bags", cost: "$1,275" },
      ],
    },
    {
      category: "Lumber",
      items: [
        { name: "Framing Lumber", quantity: "3,200 board feet", cost: "$7,680" },
        { name: "Plywood Sheathing", quantity: "120 sheets", cost: "$4,800" },
      ],
    },
    {
      category: "Roofing",
      items: [
        { name: "Asphalt Shingles", quantity: "30 squares", cost: "$3,000" },
        { name: "Underlayment", quantity: "30 rolls", cost: "$900" },
      ],
    },
  ]

  const totalCost = materials.reduce((sum, category) => {
    return (
      sum +
      category.items.reduce((catSum, item) => {
        return catSum + Number.parseInt(item.cost.replace(/[^0-9]/g, ""))
      }, 0)
    )
  }, 0)

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-US", {
      style: "currency",
      currency: "USD",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount)
  }

  return (
    <div className="space-y-6">
      {materials.map((category, index) => (
        <div key={index} className="space-y-2">
          <h3 className="font-medium">{category.category}</h3>
          <div className="space-y-1">
            {category.items.map((item, itemIndex) => (
              <div key={itemIndex} className="flex justify-between text-sm">
                <div className="flex-1">{item.name}</div>
                <div className="flex-1 text-center">{item.quantity}</div>
                <div className="flex-1 text-right">{item.cost}</div>
              </div>
            ))}
          </div>
        </div>
      ))}
      <div className="border-t pt-4">
        <div className="flex justify-between font-medium">
          <div>Total Estimated Cost</div>
          <div>{formatCurrency(totalCost)}</div>
        </div>
      </div>
      <div className="text-xs text-muted-foreground">
        * Prices are estimates based on current market rates and may vary by location and supplier.
      </div>
    </div>
  )
}

