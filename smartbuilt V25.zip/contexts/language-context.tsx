"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect } from "react"

type Language = "en" | "es" | "fr" | "de"

type Translations = {
  [key in Language]: {
    [key: string]: string
  }
}

// Basic translations for demonstration
const translations: Translations = {
  en: {
    // Common
    dashboard: "Dashboard",
    projects: "Projects",
    tasks: "Tasks",
    team: "Team",
    calendar: "Calendar",
    messages: "Messages",
    settings: "Settings",
    profile: "Profile",
    logout: "Log out",
    search: "Search",
    materialEstimation: "Material Estimation",
    resources: "Resources",
    map: "Map",

    // Project related
    newProject: "New Project",
    projectProposals: "Project Proposals",
    activeProjects: "Active Projects",
    completedProjects: "Completed Projects",
    projectDetails: "Project Details",
    projectName: "Project Name",
    client: "Client",
    architect: "Architect",
    contractor: "Contractor",
    budget: "Budget",
    deadline: "Deadline",
    status: "Status",
    progress: "Progress",
    newProjectRequest: "New Project Request",
    submitProposal: "Submit Proposal",
    viewDetails: "View Details",
    approve: "Approve",
    reject: "Reject",
    projectOpportunities: "Project Opportunities",
    submitBid: "Submit Bid",

    // Material estimation
    buildingSpecifications: "Building Specifications",
    enterDimensions: "Enter the dimensions and details of your building project",
    projectType: "Project Type",
    totalArea: "Total Area (sq m)",
    floors: "Number of Floors",
    length: "Length (m)",
    width: "Width (m)",
    height: "Height per Floor (m)",
    foundationType: "Foundation Type",
    wallConstruction: "Wall Construction",
    roofType: "Roof Type",
    calculateMaterials: "Calculate Materials",
    estimatedMaterials: "Estimated Materials",
    totalEstimatedCost: "Total Estimated Cost",

    // Add these translations to the English section
    interiorSpecifications: "Interior Specifications",
    enterInteriorDetails: "Enter details for interior finishes and materials",
    flooringType: "Flooring Type",
    flooringArea: "Flooring Area (sq. meters)",
    ceilingHeight: "Ceiling Height (meters)",
    wallFinish: "Wall Finish",
    cabinetType: "Cabinet Type",
    countertopMaterial: "Countertop Material",
    estimatedInteriorMaterials: "Estimated Interior Materials",

    landscapeSpecifications: "Landscape Specifications",
    enterLandscapeDetails: "Enter details for outdoor and landscape materials",
    landscapeType: "Landscape Type",
    lawnPercentage: "Lawn Percentage (%)",
    hardscapeType: "Hardscape Type",
    irrigationSystem: "Irrigation System",
    plantingDensity: "Planting Density",
    estimatedLandscapeMaterials: "Estimated Landscape Materials",

    // Quick actions
    quickActions: "Quick Actions",
    commonTasks: "Common tasks and shortcuts",
    viewAllProjects: "View all projects",
    manageTeam: "Manage your team",
    checkMessages: "Check communications",
    updateProfile: "Update your profile",

    // Map
    interactiveMap: "Interactive Map",
    projectLocations: "Project Locations",
    addLocation: "Add Location",
    searchLocations: "Search locations...",
    all: "All",
    contractors: "Contractors",
    suppliers: "Suppliers",

    // To-Do List
    todoList: "To-Do List",
    sharedTodoList: "Shared To-Do List",
    todoListDescription: "Tasks shared between architects, contractors, and clients",
    addNewTodo: "Add a new task...",
    noTodosYet: "No tasks yet. Add one to get started!",
    createdBy: "Created by",
  },
  es: {
    // Common
    dashboard: "Panel de Control",
    projects: "Proyectos",
    tasks: "Tareas",
    team: "Equipo",
    calendar: "Calendario",
    messages: "Mensajes",
    settings: "Configuración",
    profile: "Perfil",
    logout: "Cerrar Sesión",
    search: "Buscar",
    materialEstimation: "Estimación de Materiales",
    resources: "Recursos",
    map: "Mapa",

    // Project related
    newProject: "Nuevo Proyecto",
    projectProposals: "Propuestas de Proyectos",
    activeProjects: "Proyectos Activos",
    completedProjects: "Proyectos Completados",
    projectDetails: "Detalles del Proyecto",
    projectName: "Nombre del Proyecto",
    client: "Cliente",
    architect: "Arquitecto",
    contractor: "Contratista",
    budget: "Presupuesto",
    deadline: "Fecha Límite",
    status: "Estado",
    progress: "Progreso",
    newProjectRequest: "Nueva Solicitud de Proyecto",
    submitProposal: "Enviar Propuesta",
    viewDetails: "Ver Detalles",
    approve: "Aprobar",
    reject: "Rechazar",
    projectOpportunities: "Oportunidades de Proyectos",
    submitBid: "Enviar Oferta",

    // Material estimation
    buildingSpecifications: "Especificaciones del Edificio",
    enterDimensions: "Ingrese las dimensiones y detalles de su proyecto de construcción",
    projectType: "Tipo de Proyecto",
    totalArea: "Área Total (m²)",
    floors: "Número de Pisos",
    length: "Longitud (m)",
    width: "Ancho (m)",
    height: "Altura por Piso (m)",
    foundationType: "Tipo de Cimentación",
    wallConstruction: "Construcción de Paredes",
    roofType: "Tipo de Techo",
    calculateMaterials: "Calcular Materiales",
    estimatedMaterials: "Materiales Estimados",
    totalEstimatedCost: "Costo Total Estimado",

    // Quick actions
    quickActions: "Acciones Rápidas",
    commonTasks: "Tareas comunes y atajos",
    viewAllProjects: "Ver todos los proyectos",
    manageTeam: "Gestionar su equipo",
    checkMessages: "Revisar comunicaciones",
    updateProfile: "Actualizar su perfil",

    // Map
    interactiveMap: "Mapa Interactivo",
    projectLocations: "Ubicaciones de Proyectos",
    addLocation: "Añadir Ubicación",
    searchLocations: "Buscar ubicaciones...",
    all: "Todos",
    contractors: "Contratistas",
    suppliers: "Proveedores",
  },
  fr: {
    // Common
    dashboard: "Tableau de Bord",
    projects: "Projets",
    tasks: "Tâches",
    team: "Équipe",
    calendar: "Calendrier",
    messages: "Messages",
    settings: "Paramètres",
    profile: "Profil",
    logout: "Déconnexion",
    search: "Rechercher",
    materialEstimation: "Estimation des Matériaux",
    resources: "Ressources",
    map: "Carte",

    // Project related
    newProject: "Nouveau Projet",
    projectProposals: "Propositions de Projets",
    activeProjects: "Projets Actifs",
    completedProjects: "Projets Terminés",
    projectDetails: "Détails du Projet",
    projectName: "Nom du Projet",
    client: "Client",
    architect: "Architecte",
    contractor: "Entrepreneur",
    budget: "Budget",
    deadline: "Date Limite",
    status: "Statut",
    progress: "Progression",
    newProjectRequest: "Nouvelle Demande de Projet",
    submitProposal: "Soumettre une Proposition",
    viewDetails: "Voir les Détails",
    approve: "Approuver",
    reject: "Rejeter",
    projectOpportunities: "Opportunités de Projets",
    submitBid: "Soumettre une Offre",

    // Material estimation
    buildingSpecifications: "Spécifications du Bâtiment",
    enterDimensions: "Entrez les dimensions et les détails de votre projet de construction",
    projectType: "Type de Projet",
    totalArea: "Surface Totale (m²)",
    floors: "Nombre d'Étages",
    length: "Longueur (m)",
    width: "Largeur (m)",
    height: "Hauteur par Étage (m)",
    foundationType: "Type de Fondation",
    wallConstruction: "Construction des Murs",
    roofType: "Type de Toit",
    calculateMaterials: "Calculer les Matériaux",
    estimatedMaterials: "Matériaux Estimés",
    totalEstimatedCost: "Coût Total Estimé",

    // Quick actions
    quickActions: "Actions Rapides",
    commonTasks: "Tâches courantes et raccourcis",
    viewAllProjects: "Voir tous les projets",
    manageTeam: "Gérer votre équipe",
    checkMessages: "Vérifier les communications",
    updateProfile: "Mettre à jour votre profil",

    // Map
    interactiveMap: "Carte Interactive",
    projectLocations: "Emplacements des Projets",
    addLocation: "Ajouter un Emplacement",
    searchLocations: "Rechercher des emplacements...",
    all: "Tous",
    contractors: "Entrepreneurs",
    suppliers: "Fournisseurs",
  },
  de: {
    // Common
    dashboard: "Dashboard",
    projects: "Projekte",
    tasks: "Aufgaben",
    team: "Team",
    calendar: "Kalender",
    messages: "Nachrichten",
    settings: "Einstellungen",
    profile: "Profil",
    logout: "Abmelden",
    search: "Suchen",
    materialEstimation: "Materialschätzung",
    resources: "Ressourcen",
    map: "Karte",

    // Project related
    newProject: "Neues Projekt",
    projectProposals: "Projektvorschläge",
    activeProjects: "Aktive Projekte",
    completedProjects: "Abgeschlossene Projekte",
    projectDetails: "Projektdetails",
    projectName: "Projektname",
    client: "Kunde",
    architect: "Architekt",
    contractor: "Auftragnehmer",
    budget: "Budget",
    deadline: "Frist",
    status: "Status",
    progress: "Fortschritt",
    newProjectRequest: "Neue Projektanfrage",
    submitProposal: "Vorschlag einreichen",
    viewDetails: "Details anzeigen",
    approve: "Genehmigen",
    reject: "Ablehnen",
    projectOpportunities: "Projektmöglichkeiten",
    submitBid: "Angebot einreichen",

    // Material estimation
    buildingSpecifications: "Gebäudespezifikationen",
    enterDimensions: "Geben Sie die Abmessungen und Details Ihres Bauprojekts ein",
    projectType: "Projekttyp",
    totalArea: "Gesamtfläche (m²)",
    floors: "Anzahl der Stockwerke",
    length: "Länge (m)",
    width: "Breite (m)",
    height: "Höhe pro Stockwerk (m)",
    foundationType: "Fundamenttyp",
    wallConstruction: "Wandkonstruktion",
    roofType: "Dachtyp",
    calculateMaterials: "Materialien berechnen",
    estimatedMaterials: "Geschätzte Materialien",
    totalEstimatedCost: "Geschätzte Gesamtkosten",

    // Quick actions
    quickActions: "Schnellaktionen",
    commonTasks: "Häufige Aufgaben und Verknüpfungen",
    viewAllProjects: "Alle Projekte anzeigen",
    manageTeam: "Team verwalten",
    checkMessages: "Kommunikation prüfen",
    updateProfile: "Profil aktualisieren",

    // Map
    interactiveMap: "Interaktive Karte",
    projectLocations: "Projektstandorte",
    addLocation: "Standort hinzufügen",
    searchLocations: "Standorte suchen...",
    all: "Alle",
    contractors: "Auftragnehmer",
    suppliers: "Lieferanten",
  },
}

interface LanguageContextType {
  language: Language
  setLanguage: (language: Language) => void
  t: (key: string) => string
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<Language>("en")
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    // Get language from localStorage on client side
    const storedLanguage = localStorage.getItem("language") as Language
    if (storedLanguage && ["en", "es", "fr", "de"].includes(storedLanguage)) {
      setLanguage(storedLanguage)
    }
    setMounted(true)
  }, [])

  useEffect(() => {
    // Save language to localStorage when it changes
    if (mounted) {
      localStorage.setItem("language", language)
    }
  }, [language, mounted])

  // Translation function
  const t = (key: string): string => {
    return translations[language][key] || key
  }

  return <LanguageContext.Provider value={{ language, setLanguage, t }}>{children}</LanguageContext.Provider>
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}

