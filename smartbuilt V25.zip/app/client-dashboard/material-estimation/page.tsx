import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

export default function ClientMaterialEstimationPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Material Estimation</h1>
        <p className="text-muted-foreground">View estimated materials and costs for your projects.</p>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Project Materials</CardTitle>
          <CardDescription>Estimated materials and costs for Modern Residence</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Material</TableHead>
                <TableHead>Quantity</TableHead>
                <TableHead>Unit</TableHead>
                <TableHead className="text-right">Cost (₹)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[
                { material: "Concrete", quantity: 120, unit: "cubic meters", cost: 840000 },
                { material: "Steel", quantity: 15, unit: "tons", cost: 1200000 },
                { material: "Glass", quantity: 85, unit: "square meters", cost: 425000 },
                { material: "Wood", quantity: 45, unit: "cubic meters", cost: 675000 },
                { material: "Paint", quantity: 200, unit: "liters", cost: 100000 },
              ].map((item, i) => (
                <TableRow key={i}>
                  <TableCell className="font-medium">{item.material}</TableCell>
                  <TableCell>{item.quantity}</TableCell>
                  <TableCell>{item.unit}</TableCell>
                  <TableCell className="text-right">₹{item.cost.toLocaleString()}</TableCell>
                </TableRow>
              ))}
              <TableRow>
                <TableCell colSpan={3} className="font-bold text-right">
                  Total
                </TableCell>
                <TableCell className="text-right font-bold">₹3,240,000</TableCell>
              </TableRow>
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  )
}

