import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Send } from "lucide-react"

export default function ClientMessagesPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Messages</h1>
        <p className="text-muted-foreground">Communicate with your architects and contractors.</p>
      </div>
      <div className="grid gap-6 md:grid-cols-3">
        <Card className="md:col-span-1">
          <CardHeader>
            <CardTitle>Conversations</CardTitle>
            <CardDescription>Recent message threads</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {[
                "Architect Studio 1",
                "Contractor Team A",
                "Interior Designer",
                "Project Manager",
                "Landscape Architect",
              ].map((contact, i) => (
                <div
                  key={i}
                  className={`p-3 rounded-md cursor-pointer ${i === 0 ? "bg-primary/10" : "hover:bg-muted"}`}
                >
                  <div className="font-medium">{contact}</div>
                  <div className="text-sm text-muted-foreground truncate">Latest message preview...</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Architect Studio 1</CardTitle>
            <CardDescription>Project: Modern Residence</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <div className="h-[400px] border-y bg-muted/30 p-4 overflow-y-auto">
              <div className="space-y-4">
                <div className="flex justify-start">
                  <div className="bg-muted rounded-lg rounded-tl-none p-3 max-w-[80%]">
                    <p>I've sent over the updated floor plans for your review.</p>
                    <p className="text-xs text-muted-foreground mt-1">9:30 AM</p>
                  </div>
                </div>
                <div className="flex justify-end">
                  <div className="bg-primary/10 text-primary-foreground rounded-lg rounded-tr-none p-3 max-w-[80%]">
                    <p>Thank you! I'll take a look and get back to you by tomorrow.</p>
                    <p className="text-xs text-muted-foreground mt-1">9:45 AM</p>
                  </div>
                </div>
                <div className="flex justify-start">
                  <div className="bg-muted rounded-lg rounded-tl-none p-3 max-w-[80%]">
                    <p>Great! Also, would you like to schedule a site visit next week?</p>
                    <p className="text-xs text-muted-foreground mt-1">10:00 AM</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="p-4 flex gap-2">
              <Input placeholder="Type your message..." className="flex-1" />
              <Button size="icon">
                <Send className="h-4 w-4" />
                <span className="sr-only">Send message</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

