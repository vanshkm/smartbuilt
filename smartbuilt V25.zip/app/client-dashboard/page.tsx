"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Building2, Calendar, ChevronRight, FileText, MessageSquare } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useLanguage } from "@/contexts/language-context"
import { Badge } from "@/components/ui/badge"

interface ProjectProposal {
  id: string
  title: string
  architect: string
  budget: string
  submitted: string
  description: string
  status: "pending" | "approved" | "rejected"
  images: string[]
  timeline: string
  scope: string[]
}

export default function ClientDashboard() {
  const router = useRouter()
  const { t } = useLanguage()
  const [userName, setUserName] = useState("")
  const [projectName, setProjectName] = useState("")
  const [projectDescription, setProjectDescription] = useState("")
  const [projectType, setProjectType] = useState("residential")
  const [budget, setBudget] = useState("")
  const [deadline, setDeadline] = useState("")
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [selectedProposal, setSelectedProposal] = useState<ProjectProposal | null>(null)
  const [showProposalDetails, setShowProposalDetails] = useState(false)
  const [proposals, setProposals] = useState<ProjectProposal[]>([
    {
      id: "prop-1",
      title: "Backyard Landscaping",
      architect: "Sarah Wilson",
      budget: "$45,000",
      submitted: "2024-03-10",
      description: "Complete redesign of the backyard area including a patio, garden beds, and water feature.",
      status: "pending",
      images: [
        "/placeholder.svg?height=300&width=500",
        "/placeholder.svg?height=300&width=500",
        "/placeholder.svg?height=300&width=500",
      ],
      timeline: "3 months",
      scope: [
        "Demolition of existing structures",
        "Grading and drainage work",
        "Installation of hardscaping elements",
        "Planting and landscaping",
        "Lighting and irrigation systems",
      ],
    },
    {
      id: "prop-2",
      title: "Kitchen Remodeling",
      architect: "David Lee",
      budget: "$75,000",
      submitted: "2024-03-08",
      description: "Complete kitchen renovation with new cabinets, countertops, appliances, and flooring.",
      status: "pending",
      images: [
        "/placeholder.svg?height=300&width=500",
        "/placeholder.svg?height=300&width=500",
        "/placeholder.svg?height=300&width=500",
      ],
      timeline: "6 weeks",
      scope: [
        "Demolition of existing kitchen",
        "Plumbing and electrical updates",
        "Cabinet and countertop installation",
        "Appliance installation",
        "Flooring and backsplash installation",
      ],
    },
  ])

  useEffect(() => {
    // Check if user is logged in and is a client
    const isLoggedIn = localStorage.getItem("isLoggedIn") === "true"
    const userRole = localStorage.getItem("userRole")
    const storedName = localStorage.getItem("userName")

    if (!isLoggedIn || userRole !== "client") {
      router.push("/login")
    }

    if (storedName) {
      setUserName(storedName)
    }
  }, [router])

  const handleSubmitProjectRequest = () => {
    // In a real app, this would submit to a backend
    setIsDialogOpen(false)
    // Reset form
    setProjectName("")
    setProjectDescription("")
    setProjectType("residential")
    setBudget("")
    setDeadline("")
  }

  const handleViewProposalDetails = (proposal: ProjectProposal) => {
    setSelectedProposal(proposal)
    setShowProposalDetails(true)
  }

  const handleApproveProposal = (proposalId: string) => {
    setProposals((prevProposals) =>
      prevProposals.map((proposal) => (proposal.id === proposalId ? { ...proposal, status: "approved" } : proposal)),
    )
  }

  const pendingProposals = proposals.filter((p) => p.status === "pending")

  return (
    <div className="flex flex-col gap-6 p-2 sm:p-4 md:p-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <h1 className="text-2xl sm:text-3xl font-bold">{t("dashboard")}</h1>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button className="w-full sm:w-auto">
              <FileText className="mr-2 h-4 w-4" /> {t("newProjectRequest")}
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[525px] w-[calc(100vw-2rem)] max-w-[calc(100vw-2rem)] sm:max-w-[525px]">
            <DialogHeader>
              <DialogTitle>{t("newProjectRequest")}</DialogTitle>
              <DialogDescription>
                Fill out the form below to submit a new project request to architects.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-2 sm:gap-4">
                <Label htmlFor="project-name" className="sm:text-right">
                  {t("projectName")}
                </Label>
                <Input
                  id="project-name"
                  value={projectName}
                  onChange={(e) => setProjectName(e.target.value)}
                  className="sm:col-span-3"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-2 sm:gap-4">
                <Label htmlFor="project-type" className="sm:text-right">
                  {t("projectType")}
                </Label>
                <div className="sm:col-span-3">
                  <Select value={projectType} onValueChange={setProjectType}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select project type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="residential">Residential</SelectItem>
                      <SelectItem value="commercial">Commercial</SelectItem>
                      <SelectItem value="industrial">Industrial</SelectItem>
                      <SelectItem value="institutional">Institutional</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-2 sm:gap-4">
                <Label htmlFor="budget" className="sm:text-right">
                  {t("budget")}
                </Label>
                <Input
                  id="budget"
                  value={budget}
                  onChange={(e) => setBudget(e.target.value)}
                  placeholder="e.g. $50,000"
                  className="sm:col-span-3"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-center gap-2 sm:gap-4">
                <Label htmlFor="deadline" className="sm:text-right">
                  {t("deadline")}
                </Label>
                <Input
                  id="deadline"
                  type="date"
                  value={deadline}
                  onChange={(e) => setDeadline(e.target.value)}
                  className="sm:col-span-3"
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-4 items-start gap-2 sm:gap-4">
                <Label htmlFor="description" className="sm:text-right">
                  Description
                </Label>
                <Textarea
                  id="description"
                  value={projectDescription}
                  onChange={(e) => setProjectDescription(e.target.value)}
                  className="sm:col-span-3"
                  rows={5}
                />
              </div>
            </div>
            <DialogFooter className="flex-col sm:flex-row gap-2">
              <Button variant="outline" onClick={() => setIsDialogOpen(false)} className="w-full sm:w-auto">
                Cancel
              </Button>
              <Button type="submit" onClick={handleSubmitProjectRequest} className="w-full sm:w-auto">
                Submit Request
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-4 sm:gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">{t("activeProjects")}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3</div>
            <p className="text-xs text-muted-foreground">+1 from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">{t("projectProposals")}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{pendingProposals.length}</div>
            <p className="text-xs text-muted-foreground">Awaiting your review</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Upcoming Meetings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">4</div>
            <p className="text-xs text-muted-foreground">In the next 7 days</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Budget Utilization</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">62%</div>
            <p className="text-xs text-muted-foreground">Across all projects</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 sm:gap-6 grid-cols-1 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Your Projects</CardTitle>
            <CardDescription>Current and upcoming architectural projects</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { title: "Modern Residential Complex", architect: "Jane Doe", progress: 75, dueDate: "2024-08-15" },
                { title: "Waterfront Restaurant", architect: "Emily Chen", progress: 30, dueDate: "2024-10-20" },
                {
                  title: "Urban Apartment Renovation",
                  architect: "Michael Brown",
                  progress: 10,
                  dueDate: "2024-11-30",
                },
              ].map((project, i) => (
                <div
                  key={i}
                  className="flex flex-col sm:flex-row sm:items-center justify-between rounded-lg border p-4 gap-4"
                >
                  <div className="space-y-1">
                    <h3 className="font-medium">{project.title}</h3>
                    <p className="text-sm text-muted-foreground">Architect: {project.architect}</p>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <Calendar className="mr-1 h-3.5 w-3.5" />
                      Due: {new Date(project.dueDate).toLocaleDateString()}
                    </div>
                  </div>
                  <div className="flex flex-col items-start sm:items-end gap-2">
                    <div className="text-sm font-medium">{project.progress}% Complete</div>
                    <div className="w-full sm:w-24 h-2 bg-muted rounded-full overflow-hidden">
                      <div className="h-full bg-green-500" style={{ width: `${project.progress}%` }} />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>{t("projectProposals")}</CardTitle>
            <CardDescription>Review and approve project proposals</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {pendingProposals.map((proposal) => (
                <div
                  key={proposal.id}
                  className="flex flex-col sm:flex-row items-start justify-between rounded-lg border p-4 gap-3"
                >
                  <div className="space-y-1">
                    <h3 className="font-medium">{proposal.title}</h3>
                    <p className="text-sm text-muted-foreground">Architect: {proposal.architect}</p>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <FileText className="mr-1 h-3.5 w-3.5" />
                      Budget: {proposal.budget}
                    </div>
                  </div>
                  <div className="flex flex-col items-start sm:items-end gap-2 w-full sm:w-auto">
                    <div className="text-xs text-muted-foreground">
                      Submitted: {new Date(proposal.submitted).toLocaleDateString()}
                    </div>
                    <div className="flex gap-2 w-full sm:w-auto">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleViewProposalDetails(proposal)}
                        className="flex-1 sm:flex-none"
                      >
                        {t("viewDetails")}
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => handleApproveProposal(proposal.id)}
                        className="flex-1 sm:flex-none"
                      >
                        {t("approve")}
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 sm:gap-6 grid-cols-1">
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>{t("quickActions")}</CardTitle>
            <CardDescription>{t("commonTasks")}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {[
                {
                  icon: Building2,
                  title: t("projects"),
                  description: t("viewAllProjects"),
                  color: "bg-green-500/10 text-green-500",
                },
                {
                  icon: MessageSquare,
                  title: t("messages"),
                  description: t("checkMessages"),
                  color: "bg-blue-500/10 text-blue-500",
                },
                {
                  icon: FileText,
                  title: "Documents",
                  description: "View project files",
                  color: "bg-amber-500/10 text-amber-500",
                },
              ].map((action, i) => (
                <div key={i} className="flex items-center gap-4 rounded-lg border p-4 hover:bg-muted/50 cursor-pointer">
                  <div className={`rounded-full p-2 ${action.color}`}>
                    <action.icon className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-medium">{action.title}</h3>
                    <p className="text-xs text-muted-foreground">{action.description}</p>
                  </div>
                  <ChevronRight className="ml-auto h-4 w-4 text-muted-foreground" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Proposal Details Dialog */}
      <Dialog open={showProposalDetails} onOpenChange={setShowProposalDetails}>
        <DialogContent className="sm:max-w-[700px] w-[calc(100vw-2rem)] max-w-[calc(100vw-2rem)] sm:max-w-[700px]">
          {selectedProposal && (
            <>
              <DialogHeader>
                <DialogTitle className="text-xl">{selectedProposal.title}</DialogTitle>
                <DialogDescription>
                  Proposed by {selectedProposal.architect} on{" "}
                  {new Date(selectedProposal.submitted).toLocaleDateString()}
                </DialogDescription>
              </DialogHeader>

              <div className="grid gap-6">
                <div>
                  <h3 className="text-lg font-medium mb-2">Project Overview</h3>
                  <p className="text-sm text-muted-foreground">{selectedProposal.description}</p>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Project Details</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm font-medium">Budget</p>
                      <p className="text-sm text-muted-foreground">{selectedProposal.budget}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium">Timeline</p>
                      <p className="text-sm text-muted-foreground">{selectedProposal.timeline}</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Scope of Work</h3>
                  <ul className="list-disc pl-5 text-sm text-muted-foreground space-y-1">
                    {selectedProposal.scope.map((item, index) => (
                      <li key={index}>{item}</li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h3 className="text-lg font-medium mb-2">Project Visualizations</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                    {selectedProposal.images.map((image, index) => (
                      <img
                        key={index}
                        src={image || "/placeholder.svg"}
                        alt={`Project visualization ${index + 1}`}
                        className="rounded-md object-cover w-full h-32"
                      />
                    ))}
                  </div>
                </div>
              </div>

              <DialogFooter className="flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <Badge variant="outline" className="mr-2">
                    Status:{" "}
                    {selectedProposal.status === "pending"
                      ? "Pending Review"
                      : selectedProposal.status === "approved"
                        ? "Approved"
                        : "Rejected"}
                  </Badge>
                </div>
                <div className="flex gap-2 w-full sm:w-auto">
                  <Button
                    variant="outline"
                    onClick={() => setShowProposalDetails(false)}
                    className="flex-1 sm:flex-none"
                  >
                    Close
                  </Button>
                  {selectedProposal.status === "pending" && (
                    <>
                      <Button
                        variant="destructive"
                        onClick={() => {
                          setProposals((prevProposals) =>
                            prevProposals.map((proposal) =>
                              proposal.id === selectedProposal.id ? { ...proposal, status: "rejected" } : proposal,
                            ),
                          )
                          setShowProposalDetails(false)
                        }}
                        className="flex-1 sm:flex-none"
                      >
                        Reject
                      </Button>
                      <Button
                        onClick={() => {
                          handleApproveProposal(selectedProposal.id)
                          setShowProposalDetails(false)
                        }}
                        className="flex-1 sm:flex-none"
                      >
                        Approve
                      </Button>
                    </>
                  )}
                </div>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

