"use client"

import { useState } from "react"
import { Suspense } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

export default function ClientProjectsPage() {
  const [projects] = useState([
    {
      title: "Modern Residence",
      architect: "Architect Studio 1",
      progress: 75,
      status: "In Progress",
      images: [
        "/placeholder.svg?height=200&width=300",
        "/placeholder.svg?height=200&width=300",
        "/placeholder.svg?height=200&width=300",
      ],
      completedWork: [
        "Foundation and structural work",
        "Exterior walls and roofing",
        "Windows and doors installation",
        "Rough electrical and plumbing",
      ],
      remainingWork: [
        "Interior finishing",
        "Flooring installation",
        "Kitchen and bathroom fixtures",
        "Landscaping",
        "Final inspections",
      ],
    },
    {
      title: "Office Renovation",
      architect: "Architect Studio 2",
      progress: 30,
      status: "In Progress",
      images: ["/placeholder.svg?height=200&width=300", "/placeholder.svg?height=200&width=300"],
      completedWork: ["Demolition of old structures", "Structural modifications", "Rough framing"],
      remainingWork: [
        "Electrical and plumbing",
        "Drywall installation",
        "Flooring",
        "Painting",
        "Fixtures and furniture",
        "Final touches",
      ],
    },
    {
      title: "Retail Space",
      architect: "Architect Studio 3",
      progress: 100,
      status: "Completed",
      images: [
        "/placeholder.svg?height=200&width=300",
        "/placeholder.svg?height=200&width=300",
        "/placeholder.svg?height=200&width=300",
        "/placeholder.svg?height=200&width=300",
      ],
      completedWork: [
        "Design and planning",
        "Construction and structural work",
        "Electrical and plumbing systems",
        "Interior finishing",
        "Display installations",
        "Lighting systems",
        "Final inspections and approvals",
      ],
      remainingWork: [],
    },
    {
      title: "New Restaurant",
      architect: "Architect Studio 4",
      progress: 10,
      status: "Just Started",
      images: ["/placeholder.svg?height=200&width=300"],
      completedWork: ["Initial design approval", "Site preparation"],
      remainingWork: [
        "Foundation work",
        "Structural framing",
        "Exterior construction",
        "Roofing",
        "Plumbing and electrical",
        "Kitchen equipment installation",
        "Interior design and finishing",
        "Furniture and fixtures",
        "Final inspections",
      ],
    },
  ])

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">My Projects</h1>
        <p className="text-muted-foreground">Track and manage your architectural projects.</p>
      </div>
      <Suspense fallback={<div>Loading projects...</div>}>
        <div className="grid gap-6 md:grid-cols-2">
          {projects.map((project, i) => (
            <Dialog key={i}>
              <DialogTrigger asChild>
                <Card className="cursor-pointer hover:shadow-md transition-all">
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{project.title}</CardTitle>
                        <CardDescription>Designed by {project.architect}</CardDescription>
                      </div>
                      <Badge variant={project.status === "Completed" ? "default" : "outline"}>{project.status}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Progress</span>
                          <span>{project.progress}%</span>
                        </div>
                        <Progress value={project.progress} />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </DialogTrigger>
              <DialogContent className="max-w-3xl">
                <DialogHeader>
                  <DialogTitle>{project.title}</DialogTitle>
                  <DialogDescription>Designed by {project.architect}</DialogDescription>
                </DialogHeader>
                <div className="grid gap-6 py-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <h3 className="font-medium mb-2">Project Gallery</h3>
                      <div className="grid grid-cols-2 gap-2">
                        {project.images.map((image, index) => (
                          <img
                            key={index}
                            src={image || "/placeholder.svg"}
                            alt={`Project view ${index + 1}`}
                            className="rounded-md object-cover w-full h-32"
                          />
                        ))}
                      </div>
                    </div>
                    <div>
                      <h3 className="font-medium mb-2">Project Details</h3>
                      <div className="space-y-4">
                        <div>
                          <h4 className="text-sm font-medium">Completed Work</h4>
                          <ul className="mt-1 text-sm text-muted-foreground list-disc pl-5">
                            {project.completedWork.map((item, index) => (
                              <li key={index}>{item}</li>
                            ))}
                          </ul>
                        </div>
                        {project.remainingWork.length > 0 && (
                          <div>
                            <h4 className="text-sm font-medium">Remaining Work</h4>
                            <ul className="mt-1 text-sm text-muted-foreground list-disc pl-5">
                              {project.remainingWork.map((item, index) => (
                                <li key={index}>{item}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                        <div>
                          <h4 className="text-sm font-medium">Project Stats</h4>
                          <div className="grid grid-cols-2 gap-2 mt-1">
                            <div className="text-sm">
                              <span className="text-muted-foreground">Status:</span>
                              <p>{project.status}</p>
                            </div>
                            <div className="text-sm">
                              <span className="text-muted-foreground">Progress:</span>
                              <p>{project.progress}% complete</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          ))}
        </div>
      </Suspense>
    </div>
  )
}

