"use client"

import type React from "react"
import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { ClientSidebar } from "@/components/dashboard/client-sidebar"
import { ClientHeader } from "@/components/dashboard/client-header"
import { LanguageProvider } from "@/contexts/language-context"

export default function ClientDashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const router = useRouter()

  useEffect(() => {
    // Check if user is logged in and is a client
    const isLoggedIn = localStorage.getItem("isLoggedIn") === "true"
    const userRole = localStorage.getItem("userRole")

    if (!isLoggedIn) {
      router.push("/login")
    } else if (userRole !== "client") {
      // Redirect to appropriate dashboard based on role
      if (userRole === "architect") {
        router.push("/dashboard")
      } else if (userRole === "contractor") {
        router.push("/contractor-dashboard")
      } else {
        router.push("/login")
      }
    }
  }, [router])

  return (
    <div className="flex min-h-screen flex-col client-theme">
      <LanguageProvider>
        <ClientHeader />
        <div className="flex flex-1">
          <ClientSidebar />
          <main className="flex-1 p-6">{children}</main>
        </div>
      </LanguageProvider>
    </div>
  )
}

