"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar } from "@/components/ui/calendar"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

export default function ClientCalendarPage() {
  const [date, setDate] = useState<Date | undefined>(new Date())

  // Sample events data
  const events = [
    { date: new Date(2024, 3, 5), title: "Design Review Meeting", type: "meeting" },
    { date: new Date(2024, 3, 12), title: "Material Selection Deadline", type: "deadline" },
    { date: new Date(2024, 3, 15), title: "Construction Phase 1 Complete", type: "milestone" },
    { date: new Date(2024, 3, 20), title: "Client Walkthrough", type: "meeting" },
    { date: new Date(2024, 3, 25), title: "Final Approval Due", type: "deadline" },
    { date: new Date(2024, 3, 28), title: "Project Handover", type: "milestone" },
  ]

  // Get events for the selected date
  const selectedDateEvents = events.filter((event) => date && event.date.toDateString() === date.toDateString())

  // Function to render the day content with event indicators
  const renderDayContent = (day: Date) => {
    const dayEvents = events.filter((event) => event.date.toDateString() === day.toDateString())

    if (dayEvents.length === 0) return null

    return (
      <div className="flex justify-center mt-1">
        <div className="flex gap-0.5">
          {dayEvents.map((event, i) => (
            <span
              key={i}
              className={`h-1.5 w-1.5 rounded-full ${
                event.type === "meeting" ? "bg-blue-500" : event.type === "deadline" ? "bg-red-500" : "bg-green-500"
              }`}
            />
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Calendar</h1>
        <p className="text-muted-foreground">View project milestones and scheduled meetings.</p>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Project Timeline</CardTitle>
            <CardDescription>Important dates and milestones</CardDescription>
          </CardHeader>
          <CardContent>
            <Calendar
              mode="single"
              selected={date}
              onSelect={setDate}
              className="rounded-md border"
              components={{
                DayContent: ({ day }) => (
                  <>
                    {day.day}
                    {renderDayContent(day.date)}
                  </>
                ),
              }}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>
              {date
                ? date.toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })
                : "No Date Selected"}
            </CardTitle>
            <CardDescription>Events for selected date</CardDescription>
          </CardHeader>
          <CardContent>
            {selectedDateEvents.length > 0 ? (
              <div className="space-y-4">
                {selectedDateEvents.map((event, i) => (
                  <Dialog key={i}>
                    <DialogTrigger asChild>
                      <div className="flex items-center gap-2 p-2 rounded-md hover:bg-muted cursor-pointer">
                        <Badge
                          variant={
                            event.type === "meeting" ? "default" : event.type === "deadline" ? "destructive" : "outline"
                          }
                        >
                          {event.type.charAt(0).toUpperCase() + event.type.slice(1)}
                        </Badge>
                        <span>{event.title}</span>
                      </div>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>{event.title}</DialogTitle>
                        <DialogDescription>
                          {date?.toLocaleDateString("en-US", {
                            weekday: "long",
                            month: "long",
                            day: "numeric",
                            year: "numeric",
                          })}
                        </DialogDescription>
                      </DialogHeader>
                      <div className="py-4">
                        <h3 className="font-medium mb-2">Event Details</h3>
                        <p className="text-sm text-muted-foreground mb-4">
                          {event.type === "meeting"
                            ? "This is a scheduled meeting with your architect and project team to discuss project progress and address any concerns."
                            : event.type === "deadline"
                              ? "This is an important deadline for project deliverables or decisions that need to be made to keep the project on schedule."
                              : "This marks a significant achievement or completion of a project phase."}
                        </p>
                        <div className="text-sm">
                          <span className="font-medium">Participants:</span>
                          <ul className="mt-1 list-disc pl-5">
                            <li>You (Client)</li>
                            <li>Project Architect</li>
                            <li>Design Team Lead</li>
                            {event.type === "meeting" && <li>Contractor Representative</li>}
                          </ul>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">No events scheduled for this date</div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Upcoming Events</CardTitle>
          <CardDescription>Next 30 days</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {events
              .filter((event) => {
                const today = new Date()
                const thirtyDaysLater = new Date()
                thirtyDaysLater.setDate(today.getDate() + 30)
                return event.date >= today && event.date <= thirtyDaysLater
              })
              .sort((a, b) => a.date.getTime() - b.date.getTime())
              .map((event, i) => (
                <div key={i} className="flex items-center justify-between p-2 rounded-md hover:bg-muted">
                  <div className="flex items-center gap-2">
                    <Badge
                      variant={
                        event.type === "meeting" ? "default" : event.type === "deadline" ? "destructive" : "outline"
                      }
                    >
                      {event.type.charAt(0).toUpperCase() + event.type.slice(1)}
                    </Badge>
                    <span>{event.title}</span>
                  </div>
                  <span className="text-sm text-muted-foreground">
                    {event.date.toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                  </span>
                </div>
              ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

