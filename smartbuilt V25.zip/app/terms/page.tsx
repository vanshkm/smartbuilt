import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function TermsPage() {
  return (
    <div className="container py-12 space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl">Terms of Service</h1>
        <p className="max-w-[700px] mx-auto text-muted-foreground">
          Please read these terms carefully before using SmartBuilt's services.
        </p>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>1. Acceptance of Terms</CardTitle>
        </CardHeader>
        <CardContent>
          <p>
            By accessing or using SmartBuilt's services, you agree to be bound by these Terms of Service. If you do not
            agree to these terms, please do not use our services.
          </p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>2. Description of Service</CardTitle>
        </CardHeader>
        <CardContent>
          <p>
            SmartBuilt provides a cloud-based platform for architectural project management, collaboration, and resource
            planning. Our services are subject to change and may be modified at any time without notice.
          </p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>3. User Accounts</CardTitle>
        </CardHeader>
        <CardContent>
          <p>
            To access certain features of SmartBuilt, you may be required to create an account. You are responsible for
            maintaining the confidentiality of your account information and for all activities that occur under your
            account.
          </p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>4. Intellectual Property Rights</CardTitle>
        </CardHeader>
        <CardContent>
          <p>
            All content and materials available on SmartBuilt, including but not limited to text, graphics, website
            name, code, images, and logos, are the intellectual property of SmartBuilt and are protected by applicable
            copyright and trademark law.
          </p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>5. Limitation of Liability</CardTitle>
        </CardHeader>
        <CardContent>
          <p>
            SmartBuilt shall not be liable for any indirect, incidental, special, consequential, or punitive damages,
            including without limitation, loss of profits, data, use, goodwill, or other intangible losses, resulting
            from your access to or use of or inability to access or use the services.
          </p>
        </CardContent>
      </Card>
      <p className="text-sm text-muted-foreground text-center">Last updated: March 7, 2024</p>
    </div>
  )
}

