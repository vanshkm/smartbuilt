import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  ArrowRight,
  Building2,
  Calendar,
  ClipboardList,
  Compass,
  Layers,
  Map,
  MessageSquare,
  Ruler,
  Users,
} from "lucide-react"
import Link from "next/link"

export default function FeaturesPage() {
  const features = [
    {
      icon: Building2,
      title: "Project Management",
      description: "Efficiently manage all your architectural projects from concept to completion.",
    },
    {
      icon: Users,
      title: "Team Collaboration",
      description: "Seamlessly collaborate with your team, contractors, and clients in real-time.",
    },
    {
      icon: ClipboardList,
      title: "Task Management",
      description: "Create and assign tasks, set deadlines, and track progress effortlessly.",
    },
    {
      icon: Calendar,
      title: "Scheduling",
      description: "Manage appointments, deadlines, and project timelines with an intuitive calendar.",
    },
    {
      icon: Ruler,
      title: "Material Estimation",
      description: "Accurately estimate required materials and costs for your projects.",
    },
    {
      icon: Layers,
      title: "Resource Management",
      description: "Efficiently allocate and manage resources across multiple projects.",
    },
    {
      icon: Map,
      title: "Interactive MiniMap",
      description: "Visualize project locations and nearby resources with an interactive map.",
    },
    {
      icon: Compass,
      title: "3D Blueprint Viewer",
      description: "View and interact with 3D blueprints directly within the platform.",
    },
    {
      icon: MessageSquare,
      title: "Client Communication",
      description: "Streamline communication with clients through integrated messaging and file sharing.",
    },
  ]

  return (
    <div className="container py-12 space-y-12">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl">Powerful Features for Architects</h1>
        <p className="max-w-[700px] mx-auto text-muted-foreground">
          SmartBuilt provides a comprehensive suite of tools designed to streamline your architectural workflow and
          enhance collaboration.
        </p>
      </div>
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {features.map((feature, index) => (
          <Card key={index}>
            <CardHeader>
              <feature.icon className="w-10 h-10 text-primary mb-2" />
              <CardTitle>{feature.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription>{feature.description}</CardDescription>
            </CardContent>
          </Card>
        ))}
      </div>
      <div className="text-center">
        <Link href="/pricing">
          <Button size="lg" className="mt-8">
            View Pricing <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </Link>
      </div>
    </div>
  )
}

