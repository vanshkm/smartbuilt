import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowRight, Building, Building2, HomeIcon, Laptop, TrendingUp } from "lucide-react"
import Link from "next/link"

export default function SolutionsPage() {
  const solutions = [
    {
      icon: Building2,
      title: "For Architecture Firms",
      description:
        "Streamline project management, enhance team collaboration, and deliver exceptional results to your clients.",
      benefits: [
        "Centralized project management",
        "Resource allocation and tracking",
        "Client portal for seamless communication",
        "Advanced reporting and analytics",
      ],
    },
    {
      icon: HomeIcon,
      title: "For Residential Architects",
      description:
        "Simplify your workflow, from initial client consultations to final design approvals and construction oversight.",
      benefits: [
        "3D visualization tools",
        "Material and cost estimation",
        "Customizable project templates",
        "Integration with popular CAD software",
      ],
    },
    {
      icon: Building,
      title: "For Commercial Architects",
      description:
        "Manage complex commercial projects with ease, ensuring compliance, collaboration, and on-time delivery.",
      benefits: [
        "Multi-stakeholder collaboration features",
        "Regulatory compliance tracking",
        "Large-scale resource management",
        "Integration with BIM platforms",
      ],
    },
    {
      icon: Laptop,
      title: "For Freelance Architects",
      description:
        "Boost your productivity and professionalism with tools designed for independent architectural professionals.",
      benefits: [
        "Client management and invoicing",
        "Portfolio showcase features",
        "Time tracking and project planning",
        "Marketing and lead generation tools",
      ],
    },
  ]

  return (
    <div className="container py-12 space-y-12">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl">Solutions Tailored for Your Needs</h1>
        <p className="max-w-[700px] mx-auto text-muted-foreground">
          Whether you're an established firm, a solo practitioner, or somewhere in between, SmartBuilt has the right
          solution for you.
        </p>
      </div>
      <div className="grid gap-6 md:grid-cols-2">
        {solutions.map((solution, index) => (
          <Card key={index} className="flex flex-col">
            <CardHeader>
              <solution.icon className="w-10 h-10 text-primary mb-2" />
              <CardTitle>{solution.title}</CardTitle>
              <CardDescription>{solution.description}</CardDescription>
            </CardHeader>
            <CardContent className="flex-grow">
              <ul className="list-disc list-inside space-y-2">
                {solution.benefits.map((benefit, benefitIndex) => (
                  <li key={benefitIndex} className="text-sm">
                    {benefit}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        ))}
      </div>
      <div className="bg-muted rounded-lg p-8 text-center space-y-4">
        <TrendingUp className="w-12 h-12 text-primary mx-auto" />
        <h2 className="text-2xl font-bold">Ready to grow your architecture business?</h2>
        <p className="max-w-[600px] mx-auto text-muted-foreground">
          SmartBuilt provides the tools and support you need to take your practice to the next level.
        </p>
        <Link href="/contact">
          <Button size="lg">
            Get in Touch <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </Link>
      </div>
    </div>
  )
}

