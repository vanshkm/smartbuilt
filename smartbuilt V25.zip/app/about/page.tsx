import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { ArrowRight } from "lucide-react"
import Link from "next/link"

export default function AboutPage() {
  const team = [
    { name: "Vansh Mevada", role: "Chief Technology Officer", image: "/placeholder.svg?height=200&width=200" },
    { name: "Ved Patel", role: "Lead Architect", image: "/placeholder.svg?height=200&width=200" },
    { name: "Ved Raval", role: "UI/UX Designer", image: "/placeholder.svg?height=200&width=200" },
  ]

  return (
    <div className="container py-12 space-y-12">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl">About SmartBuilt</h1>
        <p className="max-w-[700px] mx-auto text-muted-foreground">
          We're on a mission to revolutionize the way architects work, collaborate, and deliver exceptional projects.
        </p>
      </div>
      <div className="grid gap-8 md:grid-cols-2">
        <div>
          <h2 className="text-2xl font-bold mb-4">Our Story</h2>
          <p className="text-muted-foreground mb-4">
            Founded in 2020 by a team of architects and software engineers, SmartBuilt was born out of frustration with
            existing tools that didn't meet the unique needs of architectural practices.
          </p>
          <p className="text-muted-foreground mb-4">
            We set out to create a comprehensive platform that would streamline workflows, enhance collaboration, and
            ultimately allow architects to focus on what they do best: designing amazing spaces.
          </p>
          <p className="text-muted-foreground">
            Today, SmartBuilt is used by thousands of architects worldwide, from solo practitioners to large
            multinational firms.
          </p>
        </div>
        <div>
          <img
            src="/placeholder.svg?height=400&width=600"
            alt="SmartBuilt team"
            className="rounded-lg object-cover w-full h-full"
          />
        </div>
      </div>
      <div className="text-center space-y-4">
        <h2 className="text-2xl font-bold">Our Team</h2>
        <p className="max-w-[700px] mx-auto text-muted-foreground">
          Meet the passionate individuals behind SmartBuilt, dedicated to transforming architectural practices.
        </p>
      </div>
      <div className="grid gap-6 sm:grid-cols-3">
        {team.map((member, index) => (
          <Card key={index}>
            <CardContent className="p-4 text-center">
              <img
                src={member.image || "/placeholder.svg"}
                alt={member.name}
                className="rounded-full w-32 h-32 mx-auto mb-4"
              />
              <h3 className="font-semibold">{member.name}</h3>
              <p className="text-sm text-muted-foreground">{member.role}</p>
            </CardContent>
          </Card>
        ))}
      </div>
      <div className="text-center space-y-4">
        <h2 className="text-2xl font-bold">Join Our Team</h2>
        <p className="max-w-[600px] mx-auto text-muted-foreground">
          We're always looking for talented individuals to join our mission. Check out our open positions and help shape
          the future of architectural software.
        </p>
        <Link href="/careers">
          <Button size="lg">
            View Open Positions <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </Link>
      </div>
    </div>
  )
}

