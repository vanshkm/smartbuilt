"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useLanguage } from "@/contexts/language-context"
import { useToast } from "@/hooks/use-toast"
import { useRouter } from "next/navigation"

export default function ContractorProfilePage() {
  const { language, setLanguage, t } = useLanguage()
  const { toast } = useToast()
  const router = useRouter()
  const [firstName, setFirstName] = useState("Robert")
  const [lastName, setLastName] = useState("Johnson")
  const [email, setEmail] = useState("robert@johnsonconstruction.com")
  const [phone, setPhone] = useState("+1 (555) 789-0123")
  const [companyName, setCompanyName] = useState("Johnson Construction")
  const [bio, setBio] = useState(
    "General contractor with 15 years of experience in residential and commercial construction.",
  )
  const [timezone, setTimezone] = useState("Pacific Time (UTC-8)")
  const [notifications, setNotifications] = useState(true)
  const [marketing, setMarketing] = useState(false)

  useEffect(() => {
    // Check if user is logged in and is a contractor
    const isLoggedIn = localStorage.getItem("isLoggedIn") === "true"
    const userRole = localStorage.getItem("userRole")

    if (!isLoggedIn || userRole !== "contractor") {
      router.push("/login")
    }
  }, [router])

  // Save settings
  const saveSettings = () => {
    // In a real app, this would save to a database
    localStorage.setItem("language", language)

    toast({
      title: "Settings saved",
      description: "Your settings have been saved successfully.",
    })
  }

  // Save personal info
  const savePersonalInfo = () => {
    // In a real app, this would save to a database
    localStorage.setItem("userName", `${firstName} ${lastName}`)

    toast({
      title: "Profile updated",
      description: "Your profile information has been updated successfully.",
    })
  }

  return (
    <div className="flex flex-col gap-6 p-6">
      <h1 className="text-3xl font-bold">{t("profile")}</h1>
      <div className="grid gap-6 md:grid-cols-[1fr_2fr]">
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col items-center gap-4">
              <Avatar className="h-24 w-24">
                <AvatarImage src="/placeholder.svg?height=96&width=96" alt="Profile" />
                <AvatarFallback>{`${firstName.charAt(0)}${lastName.charAt(0)}`}</AvatarFallback>
              </Avatar>
              <div className="text-center">
                <h2 className="text-xl font-bold">{`${firstName} ${lastName}`}</h2>
                <p className="text-sm text-muted-foreground">{companyName}</p>
              </div>
              <div className="flex flex-wrap gap-2 justify-center">
                <Badge variant="secondary">General Contractor</Badge>
                <Badge variant="secondary">Residential</Badge>
                <Badge variant="secondary">Commercial</Badge>
              </div>
              <div className="grid w-full gap-2">
                <Button variant="outline" size="sm">
                  {t("updateProfile")}
                </Button>
                <Button variant="outline" size="sm">
                  View Public Profile
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
        <div className="space-y-6">
          <Tabs defaultValue="personal">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="personal">Personal Info</TabsTrigger>
              <TabsTrigger value="company">Company</TabsTrigger>
              <TabsTrigger value="projects">Projects</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>
            <TabsContent value="personal" className="mt-6 space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Personal Information</CardTitle>
                  <CardDescription>Update your personal details and contact information</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="first-name">First name</Label>
                      <Input id="first-name" value={firstName} onChange={(e) => setFirstName(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="last-name">Last name</Label>
                      <Input id="last-name" value={lastName} onChange={(e) => setLastName(e.target.value)} />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone</Label>
                    <Input id="phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bio">Bio</Label>
                    <Textarea id="bio" value={bio} onChange={(e) => setBio(e.target.value)} />
                  </div>
                  <Button onClick={savePersonalInfo}>Save Changes</Button>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="company" className="mt-6 space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Company Information</CardTitle>
                  <CardDescription>Update your company details and business information</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="company-name">Company Name</Label>
                    <Input id="company-name" value={companyName} onChange={(e) => setCompanyName(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="business-type">Business Type</Label>
                    <Select defaultValue="general">
                      <SelectTrigger id="business-type">
                        <SelectValue placeholder="Select business type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="general">General Contractor</SelectItem>
                        <SelectItem value="electrical">Electrical</SelectItem>
                        <SelectItem value="plumbing">Plumbing</SelectItem>
                        <SelectItem value="hvac">HVAC</SelectItem>
                        <SelectItem value="roofing">Roofing</SelectItem>
                        <SelectItem value="landscaping">Landscaping</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="license-number">License Number</Label>
                    <Input id="license-number" placeholder="e.g. GC12345" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="insurance">Insurance Information</Label>
                    <Textarea
                      id="insurance"
                      placeholder="e.g. Liability Insurance Policy #12345, Workers' Comp Policy #67890"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="service-area">Service Area</Label>
                    <Input id="service-area" placeholder="e.g. San Francisco Bay Area" />
                  </div>
                  <Button>Save Company Information</Button>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="projects" className="mt-6 space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Current Projects</CardTitle>
                  <CardDescription>View and manage your current construction projects</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="flex items-center justify-between rounded-lg border p-4">
                        <div className="space-y-1">
                          <h3 className="font-medium">Modern Residential Complex - Phase {i}</h3>
                          <p className="text-sm text-muted-foreground">Horizon Developers</p>
                          <div className="text-xs text-muted-foreground">
                            Due: {new Date(2024, 5 + i, 15).toLocaleDateString()}
                          </div>
                        </div>
                        <div className="flex flex-col items-end gap-2">
                          <div className="text-sm font-medium">
                            {i === 1 ? "75%" : i === 2 ? "45%" : "20%"} Complete
                          </div>
                          <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                            <div
                              className="h-full bg-amber-500"
                              style={{ width: i === 1 ? "75%" : i === 2 ? "45%" : "20%" }}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="settings" className="mt-6 space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Account Settings</CardTitle>
                  <CardDescription>Manage your account preferences and settings</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="language">Language</Label>
                    <Select value={language} onValueChange={(value) => setLanguage(value as any)}>
                      <SelectTrigger id="language">
                        <SelectValue placeholder="Select language" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="en">English</SelectItem>
                        <SelectItem value="es">Español</SelectItem>
                        <SelectItem value="fr">Français</SelectItem>
                        <SelectItem value="de">Deutsch</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="timezone">Timezone</Label>
                    <Select value={timezone} onValueChange={setTimezone}>
                      <SelectTrigger id="timezone">
                        <SelectValue placeholder="Select timezone" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Pacific Time (UTC-8)">Pacific Time (UTC-8)</SelectItem>
                        <SelectItem value="Mountain Time (UTC-7)">Mountain Time (UTC-7)</SelectItem>
                        <SelectItem value="Central Time (UTC-6)">Central Time (UTC-6)</SelectItem>
                        <SelectItem value="Eastern Time (UTC-5)">Eastern Time (UTC-5)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="notifications"
                      className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                      checked={notifications}
                      onChange={(e) => setNotifications(e.target.checked)}
                    />
                    <Label htmlFor="notifications">Email notifications</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="marketing"
                      className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                      checked={marketing}
                      onChange={(e) => setMarketing(e.target.checked)}
                    />
                    <Label htmlFor="marketing">Marketing emails</Label>
                  </div>
                  <Button onClick={saveSettings}>Save Settings</Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}

