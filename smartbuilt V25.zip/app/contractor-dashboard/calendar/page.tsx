"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar } from "@/components/ui/calendar"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

export default function ContractorCalendarPage() {
  const [date, setDate] = useState<Date | undefined>(new Date())

  // Sample events data
  const events = [
    { date: new Date(2024, 3, 3), title: "Site Inspection", type: "task", project: "Modern Office Tower 1" },
    { date: new Date(2024, 3, 5), title: "Team Coordination Meeting", type: "meeting", project: "All Projects" },
    { date: new Date(2024, 3, 8), title: "Material Delivery", type: "delivery", project: "Modern Office Tower 2" },
    {
      date: new Date(2024, 3, 10),
      title: "Foundation Inspection",
      type: "inspection",
      project: "Modern Office Tower 3",
    },
    { date: new Date(2024, 3, 15), title: "Phase 1 Completion", type: "milestone", project: "Modern Office Tower 1" },
    { date: new Date(2024, 3, 18), title: "Client Walkthrough", type: "meeting", project: "Modern Office Tower 4" },
    {
      date: new Date(2024, 3, 22),
      title: "Electrical System Installation",
      type: "task",
      project: "Modern Office Tower 5",
    },
    { date: new Date(2024, 3, 25), title: "Safety Inspection", type: "inspection", project: "All Projects" },
    { date: new Date(2024, 3, 28), title: "Progress Review Meeting", type: "meeting", project: "All Projects" },
  ]

  // Get events for the selected date
  const selectedDateEvents = events.filter((event) => date && event.date.toDateString() === date.toDateString())

  // Function to render the day content with event indicators
  const renderDayContent = (day: Date) => {
    const dayEvents = events.filter((event) => event.date.toDateString() === day.toDateString())

    if (dayEvents.length === 0) return null

    return (
      <div className="flex justify-center mt-1">
        <div className="flex gap-0.5">
          {dayEvents.slice(0, 3).map((event, i) => (
            <span
              key={i}
              className={`h-1.5 w-1.5 rounded-full ${
                event.type === "meeting"
                  ? "bg-blue-500"
                  : event.type === "task"
                    ? "bg-amber-500"
                    : event.type === "inspection"
                      ? "bg-red-500"
                      : event.type === "delivery"
                        ? "bg-purple-500"
                        : "bg-green-500"
              }`}
            />
          ))}
          {dayEvents.length > 3 && <span className="h-1.5 w-1.5 rounded-full bg-gray-500" />}
        </div>
      </div>
    )
  }

  // Get badge color based on event type
  const getBadgeVariant = (type) => {
    switch (type) {
      case "meeting":
        return "default"
      case "task":
        return "secondary"
      case "inspection":
        return "destructive"
      case "delivery":
        return "outline"
      case "milestone":
        return "default"
      default:
        return "outline"
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Calendar</h1>
        <p className="text-muted-foreground">View and manage your schedule and deadlines.</p>
      </div>

      <Tabs defaultValue="calendar">
        <TabsList>
          <TabsTrigger value="calendar">Calendar View</TabsTrigger>
          <TabsTrigger value="schedule">Schedule</TabsTrigger>
        </TabsList>

        <TabsContent value="calendar" className="space-y-6 mt-6">
          <div className="grid gap-6 md:grid-cols-3">
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Project Schedule</CardTitle>
                <CardDescription>View your upcoming deadlines and meetings</CardDescription>
              </CardHeader>
              <CardContent>
                <Calendar
                  mode="single"
                  selected={date}
                  onSelect={setDate}
                  className="rounded-md border"
                  components={{
                    DayContent: ({ day }) => (
                      <>
                        {day.day}
                        {renderDayContent(day.date)}
                      </>
                    ),
                  }}
                />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>
                  {date
                    ? date.toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" })
                    : "No Date Selected"}
                </CardTitle>
                <CardDescription>Events for selected date</CardDescription>
              </CardHeader>
              <CardContent>
                {selectedDateEvents.length > 0 ? (
                  <div className="space-y-4">
                    {selectedDateEvents.map((event, i) => (
                      <Dialog key={i}>
                        <DialogTrigger asChild>
                          <div className="flex items-center gap-2 p-2 rounded-md hover:bg-muted cursor-pointer">
                            <Badge variant={getBadgeVariant(event.type)}>
                              {event.type.charAt(0).toUpperCase() + event.type.slice(1)}
                            </Badge>
                            <div className="flex flex-col">
                              <span>{event.title}</span>
                              <span className="text-xs text-muted-foreground">{event.project}</span>
                            </div>
                          </div>
                        </DialogTrigger>
                        <DialogContent>
                          <DialogHeader>
                            <DialogTitle>{event.title}</DialogTitle>
                            <DialogDescription>
                              {date?.toLocaleDateString("en-US", {
                                weekday: "long",
                                month: "long",
                                day: "numeric",
                                year: "numeric",
                              })}
                            </DialogDescription>
                          </DialogHeader>
                          <div className="py-4">
                            <div className="flex items-center gap-2 mb-4">
                              <Badge variant={getBadgeVariant(event.type)}>
                                {event.type.charAt(0).toUpperCase() + event.type.slice(1)}
                              </Badge>
                              <span className="text-sm font-medium">{event.project}</span>
                            </div>
                            <h3 className="font-medium mb-2">Event Details</h3>
                            <p className="text-sm text-muted-foreground mb-4">
                              {event.type === "meeting"
                                ? "Coordination meeting with project stakeholders to discuss progress and next steps."
                                : event.type === "task"
                                  ? "Scheduled construction task that needs to be completed according to the project timeline."
                                  : event.type === "inspection"
                                    ? "Official inspection of completed work to ensure compliance with building codes and project specifications."
                                    : event.type === "delivery"
                                      ? "Scheduled delivery of materials or equipment needed for the construction process."
                                      : "Significant project milestone marking the completion of a major phase."}
                            </p>
                            <div className="text-sm">
                              <span className="font-medium">Participants:</span>
                              <ul className="mt-1 list-disc pl-5">
                                <li>Construction Team</li>
                                <li>Project Manager</li>
                                {event.type === "meeting" && <li>Client Representative</li>}
                                {event.type === "inspection" && <li>Building Inspector</li>}
                                {event.type === "milestone" && <li>Architect</li>}
                              </ul>
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-muted-foreground">No events scheduled for this date</div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="schedule" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Upcoming Schedule</CardTitle>
              <CardDescription>Next 30 days</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {Array.from(new Set(events.map((e) => e.project))).map((project) => (
                  <div key={project} className="space-y-2">
                    <h3 className="font-medium">{project}</h3>
                    <div className="space-y-2">
                      {events
                        .filter((event) => event.project === project)
                        .sort((a, b) => a.date.getTime() - b.date.getTime())
                        .map((event, i) => (
                          <div key={i} className="flex items-center justify-between p-2 rounded-md hover:bg-muted">
                            <div className="flex items-center gap-2">
                              <Badge variant={getBadgeVariant(event.type)}>
                                {event.type.charAt(0).toUpperCase() + event.type.slice(1)}
                              </Badge>
                              <span>{event.title}</span>
                            </div>
                            <span className="text-sm text-muted-foreground">
                              {event.date.toLocaleDateString("en-US", { month: "short", day: "numeric" })}
                            </span>
                          </div>
                        ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

