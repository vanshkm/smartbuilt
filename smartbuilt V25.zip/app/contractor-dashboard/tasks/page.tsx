import { Suspense } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { CheckCircle2, Clock, AlertCircle } from "lucide-react"

export default function ContractorTasksPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Tasks</h1>
        <p className="text-muted-foreground">Manage your assigned tasks and track progress.</p>
      </div>
      <Suspense fallback={<div>Loading tasks...</div>}>
        <div className="grid gap-6">
          {[
            {
              title: "Install HVAC System",
              status: "completed",
              project: "Modern Office Tower 1",
              deadline: "May 10, 2025",
            },
            {
              title: "Electrical Wiring",
              status: "in-progress",
              project: "Modern Office Tower 2",
              deadline: "May 15, 2025",
            },
            {
              title: "Plumbing Installation",
              status: "pending",
              project: "Modern Office Tower 3",
              deadline: "May 20, 2025",
            },
            {
              title: "Foundation Work",
              status: "in-progress",
              project: "Modern Office Tower 4",
              deadline: "May 25, 2025",
            },
            {
              title: "Roof Installation",
              status: "pending",
              project: "Modern Office Tower 5",
              deadline: "June 1, 2025",
            },
          ].map((task, i) => (
            <Card key={i}>
              <CardContent className="p-4 flex items-center justify-between">
                <div>
                  <h3 className="font-medium">{task.title}</h3>
                  <p className="text-sm text-muted-foreground">Project: {task.project}</p>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-sm text-muted-foreground">Due: {task.deadline}</div>
                  <div>
                    {task.status === "completed" && <CheckCircle2 className="h-5 w-5 text-green-500" />}
                    {task.status === "in-progress" && <Clock className="h-5 w-5 text-amber-500" />}
                    {task.status === "pending" && <AlertCircle className="h-5 w-5 text-gray-400" />}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </Suspense>
    </div>
  )
}

