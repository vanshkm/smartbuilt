"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import {
  Building2,
  Calendar,
  ChevronRight,
  ClipboardList,
  FileText,
  MessageSquare,
  Settings,
  Users,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { useLanguage } from "@/contexts/language-context"

export default function ContractorDashboard() {
  const router = useRouter()
  const { t } = useLanguage()
  const [userName, setUserName] = useState("")
  const [bidAmount, setBidAmount] = useState("")
  const [bidDescription, setBidDescription] = useState("")
  const [estimatedDuration, setEstimatedDuration] = useState("")
  const [selectedProject, setSelectedProject] = useState<any>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  useEffect(() => {
    // Check if user is logged in and is a contractor
    const isLoggedIn = localStorage.getItem("isLoggedIn") === "true"
    const userRole = localStorage.getItem("userRole")
    const storedName = localStorage.getItem("userName")

    if (!isLoggedIn || userRole !== "contractor") {
      router.push("/login")
    }

    if (storedName) {
      setUserName(storedName)
    }
  }, [router])

  const handleSubmitBid = () => {
    // In a real app, this would submit to a backend
    setIsDialogOpen(false)
    // Reset form
    setBidAmount("")
    setBidDescription("")
    setEstimatedDuration("")
    setSelectedProject(null)
  }

  const openBidDialog = (project: any) => {
    setSelectedProject(project)
    setIsDialogOpen(true)
  }

  const projectOpportunities = [
    {
      title: "Downtown Office Renovation",
      client: "Metro Business Solutions",
      budget: "$450,000",
      deadline: "2024-04-15",
    },
    {
      title: "Luxury Hotel Complex",
      client: "Elite Hospitality",
      budget: "$2,800,000",
      deadline: "2024-04-20",
    },
    {
      title: "Community Center",
      client: "Oakridge Municipality",
      budget: "$1,200,000",
      deadline: "2024-04-25",
    },
  ]

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">{t("dashboard")}</h1>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">{t("activeProjects")}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">8</div>
            <p className="text-xs text-muted-foreground">+2 from last month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Pending Bids</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">12</div>
            <p className="text-xs text-muted-foreground">+5 new this week</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">{t("team")}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">15</div>
            <p className="text-xs text-muted-foreground">+3 new this month</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$42,500</div>
            <p className="text-xs text-muted-foreground">+18% from last month</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <Card className="col-span-2">
          <CardHeader>
            <CardTitle>Current Projects</CardTitle>
            <CardDescription>Your active construction projects</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-center justify-between rounded-lg border p-4">
                  <div className="space-y-1">
                    <h3 className="font-medium">Modern Residential Complex - Phase {i}</h3>
                    <p className="text-sm text-muted-foreground">Horizon Developers</p>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <Calendar className="mr-1 h-3.5 w-3.5" />
                      Due: {new Date(2024, 5 + i, 15).toLocaleDateString()}
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <div className="text-sm font-medium">{i === 1 ? "75%" : i === 2 ? "45%" : "20%"} Complete</div>
                    <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                      <div
                        className="h-full bg-amber-500"
                        style={{ width: i === 1 ? "75%" : i === 2 ? "45%" : "20%" }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Upcoming Tasks</CardTitle>
            <CardDescription>Tasks due in the next 7 days</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { title: "Site inspection", date: "Today, 2:00 PM", priority: "High" },
                { title: "Team coordination meeting", date: "Tomorrow, 10:00 AM", priority: "Medium" },
                { title: "Material delivery", date: "Wed, 9:00 AM", priority: "High" },
                { title: "Progress report submission", date: "Fri, 5:00 PM", priority: "Medium" },
              ].map((task, i) => (
                <div key={i} className="flex items-start gap-2 rounded-lg border p-3">
                  <div className="mt-0.5">
                    <ClipboardList className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <div className="flex-1 space-y-1">
                    <div className="font-medium">{task.title}</div>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <Calendar className="mr-1 h-3 w-3" />
                      {task.date}
                    </div>
                  </div>
                  <div
                    className={`text-xs px-2 py-1 rounded-full ${
                      task.priority === "High" ? "bg-destructive/10 text-destructive" : "bg-amber-500/10 text-amber-500"
                    }`}
                  >
                    {task.priority}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card className="col-span-2">
          <CardHeader>
            <CardTitle>{t("projectOpportunities")}</CardTitle>
            <CardDescription>Recent projects open for bidding</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {projectOpportunities.map((project, i) => (
                <div key={i} className="flex items-center justify-between rounded-lg border p-4">
                  <div className="space-y-1">
                    <h3 className="font-medium">{project.title}</h3>
                    <p className="text-sm text-muted-foreground">{project.client}</p>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <FileText className="mr-1 h-3.5 w-3.5" />
                      Budget: {project.budget}
                    </div>
                  </div>
                  <div className="flex flex-col items-end gap-2">
                    <div className="text-xs text-muted-foreground">
                      Bid Deadline: {new Date(project.deadline).toLocaleDateString()}
                    </div>
                    <Button size="sm" variant="outline" onClick={() => openBidDialog(project)}>
                      {t("submitBid")}
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card className="col-span-2">
          <CardHeader>
            <CardTitle>{t("quickActions")}</CardTitle>
            <CardDescription>{t("commonTasks")}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              {[
                {
                  icon: Building2,
                  title: t("projects"),
                  description: t("viewAllProjects"),
                  color: "bg-amber-500/10 text-amber-500",
                },
                {
                  icon: Users,
                  title: t("team"),
                  description: t("manageTeam"),
                  color: "bg-blue-500/10 text-blue-500",
                },
                {
                  icon: MessageSquare,
                  title: t("messages"),
                  description: t("checkMessages"),
                  color: "bg-green-500/10 text-green-500",
                },
                {
                  icon: Settings,
                  title: t("settings"),
                  description: t("updateProfile"),
                  color: "bg-purple-500/10 text-purple-500",
                },
              ].map((action, i) => (
                <div key={i} className="flex items-center gap-4 rounded-lg border p-4 hover:bg-muted/50 cursor-pointer">
                  <div className={`rounded-full p-2 ${action.color}`}>
                    <action.icon className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="font-medium">{action.title}</h3>
                    <p className="text-xs text-muted-foreground">{action.description}</p>
                  </div>
                  <ChevronRight className="ml-auto h-4 w-4 text-muted-foreground" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[525px]">
          <DialogHeader>
            <DialogTitle>{t("submitBid")}</DialogTitle>
            <DialogDescription>Submit your bid for {selectedProject?.title}</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="bid-amount" className="text-right">
                Bid Amount
              </Label>
              <Input
                id="bid-amount"
                value={bidAmount}
                onChange={(e) => setBidAmount(e.target.value)}
                placeholder="e.g. $425,000"
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="estimated-duration" className="text-right">
                Duration
              </Label>
              <Input
                id="estimated-duration"
                value={estimatedDuration}
                onChange={(e) => setEstimatedDuration(e.target.value)}
                placeholder="e.g. 6 months"
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-start gap-4">
              <Label htmlFor="bid-description" className="text-right">
                Description
              </Label>
              <Textarea
                id="bid-description"
                value={bidDescription}
                onChange={(e) => setBidDescription(e.target.value)}
                className="col-span-3"
                rows={5}
                placeholder="Describe your approach, timeline, and any special considerations"
              />
            </div>
          </div>
          <DialogFooter>
            <Button type="submit" onClick={handleSubmitBid}>
              {t("submitBid")}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

