import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function ContractorMaterialEstimationPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Material Estimation</h1>
        <p className="text-muted-foreground">Calculate material requirements for your projects.</p>
      </div>
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Material Calculator</CardTitle>
            <CardDescription>Estimate materials needed for your project</CardDescription>
          </CardHeader>
          <CardContent>
            <form className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="project">Project</Label>
                <Select defaultValue="project1">
                  <SelectTrigger>
                    <SelectValue placeholder="Select project" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="project1">Modern Office Tower 1</SelectItem>
                    <SelectItem value="project2">Modern Office Tower 2</SelectItem>
                    <SelectItem value="project3">Modern Office Tower 3</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="material">Material Type</Label>
                <Select defaultValue="concrete">
                  <SelectTrigger>
                    <SelectValue placeholder="Select material" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="concrete">Concrete</SelectItem>
                    <SelectItem value="steel">Steel</SelectItem>
                    <SelectItem value="wood">Wood</SelectItem>
                    <SelectItem value="glass">Glass</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="area">Area (sq. ft.)</Label>
                <Input id="area" type="number" placeholder="Enter area" />
              </div>
              <Button type="submit" className="w-full">
                Calculate
              </Button>
            </form>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Estimation Results</CardTitle>
            <CardDescription>Your calculated material requirements</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <p className="text-center text-muted-foreground">
                Enter your project details and calculate to see results
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

