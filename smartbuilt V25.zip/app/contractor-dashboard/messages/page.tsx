import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Send } from "lucide-react"

export default function ContractorMessagesPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Messages</h1>
        <p className="text-muted-foreground">Communicate with architects, clients, and team members.</p>
      </div>
      <div className="grid gap-6 md:grid-cols-3">
        <Card className="md:col-span-1">
          <CardHeader>
            <CardTitle>Conversations</CardTitle>
            <CardDescription>Recent message threads</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {["Architect Studio 1", "Client Company A", "Supplier XYZ", "Team Lead", "Project Manager"].map(
                (contact, i) => (
                  <div
                    key={i}
                    className={`p-3 rounded-md cursor-pointer ${i === 0 ? "bg-primary/10" : "hover:bg-muted"}`}
                  >
                    <div className="font-medium">{contact}</div>
                    <div className="text-sm text-muted-foreground truncate">Latest message preview...</div>
                  </div>
                ),
              )}
            </div>
          </CardContent>
        </Card>
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Architect Studio 1</CardTitle>
            <CardDescription>Project: Modern Office Tower 1</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <div className="h-[400px] border-y bg-muted/30 p-4 overflow-y-auto">
              <div className="space-y-4">
                <div className="flex justify-start">
                  <div className="bg-muted rounded-lg rounded-tl-none p-3 max-w-[80%]">
                    <p>Hi, I need an update on the HVAC installation progress.</p>
                    <p className="text-xs text-muted-foreground mt-1">10:30 AM</p>
                  </div>
                </div>
                <div className="flex justify-end">
                  <div className="bg-primary/10 text-primary-foreground rounded-lg rounded-tr-none p-3 max-w-[80%]">
                    <p>We're about 70% complete. Should be finished by tomorrow.</p>
                    <p className="text-xs text-muted-foreground mt-1">10:35 AM</p>
                  </div>
                </div>
                <div className="flex justify-start">
                  <div className="bg-muted rounded-lg rounded-tl-none p-3 max-w-[80%]">
                    <p>Great! Any issues or concerns I should know about?</p>
                    <p className="text-xs text-muted-foreground mt-1">10:37 AM</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="p-4 flex gap-2">
              <Input placeholder="Type your message..." className="flex-1" />
              <Button size="icon">
                <Send className="h-4 w-4" />
                <span className="sr-only">Send message</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

