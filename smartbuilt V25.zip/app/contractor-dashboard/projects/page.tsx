"use client"

import { useState } from "react"
import { Suspense } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

export default function ContractorProjectsPage() {
  const [projects] = useState([
    {
      id: 1,
      title: "Modern Office Tower 1",
      architect: "Architect Studio 1",
      status: "In Progress",
      deadline: "June 15, 2025",
      tasksCompleted: 12,
      totalTasks: 20,
      images: [
        "/placeholder.svg?height=200&width=300",
        "/placeholder.svg?height=200&width=300",
        "/placeholder.svg?height=200&width=300",
      ],
      completedWork: ["Foundation work", "Structural framing", "Exterior walls", "Roofing"],
      remainingWork: ["Interior partitions", "Electrical systems", "Plumbing", "Finishing work"],
    },
    {
      id: 2,
      title: "Modern Office Tower 2",
      architect: "Architect Studio 2",
      status: "In Progress",
      deadline: "July 20, 2025",
      tasksCompleted: 8,
      totalTasks: 18,
      images: ["/placeholder.svg?height=200&width=300", "/placeholder.svg?height=200&width=300"],
      completedWork: ["Site preparation", "Foundation work", "Structural framing"],
      remainingWork: ["Exterior walls", "Roofing", "Interior work", "Electrical and plumbing", "Finishing"],
    },
    {
      id: 3,
      title: "Modern Office Tower 3",
      architect: "Architect Studio 3",
      status: "Just Started",
      deadline: "August 30, 2025",
      tasksCompleted: 3,
      totalTasks: 22,
      images: [
        "/placeholder.svg?height=200&width=300",
        "/placeholder.svg?height=200&width=300",
        "/placeholder.svg?height=200&width=300",
        "/placeholder.svg?height=200&width=300",
      ],
      completedWork: ["Site preparation", "Initial excavation"],
      remainingWork: [
        "Foundation work",
        "Structural framing",
        "Exterior walls",
        "Roofing",
        "Interior work",
        "Systems installation",
        "Finishing",
      ],
    },
    {
      id: 4,
      title: "Modern Office Tower 4",
      architect: "Architect Studio 4",
      status: "In Progress",
      deadline: "May 10, 2025",
      tasksCompleted: 15,
      totalTasks: 20,
      images: ["/placeholder.svg?height=200&width=300", "/placeholder.svg?height=200&width=300"],
      completedWork: [
        "Site preparation",
        "Foundation work",
        "Structural framing",
        "Exterior walls",
        "Roofing",
        "Rough electrical",
      ],
      remainingWork: ["Plumbing", "HVAC installation", "Interior finishing", "Final inspections"],
    },
    {
      id: 5,
      title: "Modern Office Tower 5",
      architect: "Architect Studio 5",
      status: "Almost Complete",
      deadline: "April 5, 2025",
      tasksCompleted: 18,
      totalTasks: 20,
      images: [
        "/placeholder.svg?height=200&width=300",
        "/placeholder.svg?height=200&width=300",
        "/placeholder.svg?height=200&width=300",
      ],
      completedWork: [
        "Site preparation",
        "Foundation work",
        "Structural framing",
        "Exterior walls",
        "Roofing",
        "Electrical systems",
        "Plumbing",
        "HVAC installation",
      ],
      remainingWork: ["Interior finishing", "Final inspections"],
    },
  ])

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Projects</h1>
        <p className="text-muted-foreground">Manage your ongoing and upcoming projects.</p>
      </div>
      <Suspense fallback={<div>Loading projects...</div>}>
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {projects.map((project) => (
            <Dialog key={project.id}>
              <DialogTrigger asChild>
                <Card className="cursor-pointer hover:shadow-md transition-all">
                  <CardHeader className="pb-2">
                    <CardTitle>{project.title}</CardTitle>
                    <CardDescription>Assigned by {project.architect}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-sm text-muted-foreground mb-2">
                      <span className="font-medium text-foreground">Status:</span> {project.status}
                    </div>
                    <div className="text-sm text-muted-foreground mb-2">
                      <span className="font-medium text-foreground">Deadline:</span> {project.deadline}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      <span className="font-medium text-foreground">Tasks:</span> {project.tasksCompleted}/
                      {project.totalTasks} completed
                    </div>
                  </CardContent>
                </Card>
              </DialogTrigger>
              <DialogContent className="max-w-3xl">
                <DialogHeader>
                  <DialogTitle>{project.title}</DialogTitle>
                  <DialogDescription>Assigned by {project.architect}</DialogDescription>
                </DialogHeader>
                <div className="grid gap-6 py-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <h3 className="font-medium mb-2">Project Gallery</h3>
                      <div className="grid grid-cols-2 gap-2">
                        {project.images.map((image, index) => (
                          <img
                            key={index}
                            src={image || "/placeholder.svg"}
                            alt={`Project view ${index + 1}`}
                            className="rounded-md object-cover w-full h-32"
                          />
                        ))}
                      </div>
                    </div>
                    <div>
                      <h3 className="font-medium mb-2">Project Details</h3>
                      <div className="space-y-4">
                        <div>
                          <h4 className="text-sm font-medium">Completed Work</h4>
                          <ul className="mt-1 text-sm text-muted-foreground list-disc pl-5">
                            {project.completedWork.map((item, index) => (
                              <li key={index}>{item}</li>
                            ))}
                          </ul>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium">Remaining Work</h4>
                          <ul className="mt-1 text-sm text-muted-foreground list-disc pl-5">
                            {project.remainingWork.map((item, index) => (
                              <li key={index}>{item}</li>
                            ))}
                          </ul>
                        </div>
                        <div>
                          <h4 className="text-sm font-medium">Project Stats</h4>
                          <div className="grid grid-cols-2 gap-2 mt-1">
                            <div className="text-sm">
                              <span className="text-muted-foreground">Status:</span>
                              <p>{project.status}</p>
                            </div>
                            <div className="text-sm">
                              <span className="text-muted-foreground">Deadline:</span>
                              <p>{project.deadline}</p>
                            </div>
                            <div className="text-sm">
                              <span className="text-muted-foreground">Tasks:</span>
                              <p>
                                {project.tasksCompleted}/{project.totalTasks} completed
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          ))}
        </div>
      </Suspense>
    </div>
  )
}

