"use client"

import type React from "react"
import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { ContractorSidebar } from "@/components/dashboard/contractor-sidebar"
import { ContractorHeader } from "@/components/dashboard/contractor-header"
import { LanguageProvider } from "@/contexts/language-context"

export default function ContractorDashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const router = useRouter()

  useEffect(() => {
    // Check if user is logged in and is a contractor
    const isLoggedIn = localStorage.getItem("isLoggedIn") === "true"
    const userRole = localStorage.getItem("userRole")

    if (!isLoggedIn) {
      router.push("/login")
    } else if (userRole !== "contractor") {
      // Redirect to appropriate dashboard based on role
      if (userRole === "architect") {
        router.push("/dashboard")
      } else if (userRole === "client") {
        router.push("/client-dashboard")
      } else {
        router.push("/login")
      }
    }
  }, [router])

  return (
    <LanguageProvider>
      <div className="flex min-h-screen flex-col contractor-theme">
        <ContractorHeader />
        <div className="flex flex-1">
          <ContractorSidebar />
          <main className="flex-1 p-6">{children}</main>
        </div>
      </div>
    </LanguageProvider>
  )
}

