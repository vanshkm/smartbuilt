"use client"

import { useState, useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useLanguage } from "@/contexts/language-context"
import { useToast } from "@/hooks/use-toast"
import { Switch } from "@/components/ui/switch"

export default function ProfilePage() {
  const { language, setLanguage, t } = useLanguage()
  const { toast } = useToast()
  const searchParams = useSearchParams()
  const tabParam = searchParams.get("tab")

  const [activeTab, setActiveTab] = useState("personal")
  const [firstName, setFirstName] = useState("Arjun")
  const [lastName, setLastName] = useState("Patel")
  const [email, setEmail] = useState("arjun.patel@example.com")
  const [phone, setPhone] = useState("+91 98765 43210")
  const [bio, setBio] = useState(
    "Senior architect with over 10 years of experience in residential and commercial projects. Specializing in sustainable design and modern aesthetics.",
  )
  const [timezone, setTimezone] = useState("Asia/Kolkata")
  const [notifications, setNotifications] = useState(true)
  const [marketing, setMarketing] = useState(false)
  const [darkMode, setDarkMode] = useState(false)
  const [emailNotifications, setEmailNotifications] = useState({
    projectUpdates: true,
    taskAssignments: true,
    teamMessages: true,
    systemAnnouncements: false,
    marketingUpdates: false,
  })

  // Portfolio projects
  const [portfolioProjects, setPortfolioProjects] = useState([
    {
      id: 1,
      title: "Lakeside Villa",
      type: "Residential",
      year: "2023",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 2,
      title: "Tech Hub Offices",
      type: "Commercial",
      year: "2022",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 3,
      title: "Urban Apartment Complex",
      type: "Residential",
      year: "2021",
      image: "/placeholder.svg?height=200&width=300",
    },
  ])

  // New project form
  const [newProject, setNewProject] = useState({
    title: "",
    type: "Residential",
    year: new Date().getFullYear().toString(),
    image: "/placeholder.svg?height=200&width=300",
  })

  // Set active tab from URL parameter
  useEffect(() => {
    if (tabParam && ["personal", "portfolio", "settings"].includes(tabParam)) {
      setActiveTab(tabParam)
    }
  }, [tabParam])

  // Save settings
  const handleSaveSettings = () => {
    // In a real app, this would save to a database
    localStorage.setItem("language", language)
    localStorage.setItem("darkMode", darkMode.toString())
    localStorage.setItem("notifications", JSON.stringify(emailNotifications))

    toast({
      title: "Settings saved",
      description: "Your settings have been saved successfully.",
    })
  }

  // Save personal info
  const handleSavePersonalInfo = () => {
    // In a real app, this would save to a database
    localStorage.setItem("userName", `${firstName} ${lastName}`)
    localStorage.setItem("userEmail", email)
    localStorage.setItem("userPhone", phone)
    localStorage.setItem("userBio", bio)

    toast({
      title: "Profile updated",
      description: "Your profile information has been updated successfully.",
    })
  }

  // Add new portfolio project
  const handleAddProject = () => {
    if (!newProject.title) return

    const project = {
      id: portfolioProjects.length + 1,
      title: newProject.title,
      type: newProject.type,
      year: newProject.year,
      image: newProject.image,
    }

    setPortfolioProjects([...portfolioProjects, project])

    // Reset form
    setNewProject({
      title: "",
      type: "Residential",
      year: new Date().getFullYear().toString(),
      image: "/placeholder.svg?height=200&width=300",
    })

    toast({
      title: "Project added",
      description: "Your portfolio project has been added successfully.",
    })
  }

  // Delete portfolio project
  const handleDeleteProject = (id) => {
    setPortfolioProjects(portfolioProjects.filter((project) => project.id !== id))

    toast({
      title: "Project deleted",
      description: "Your portfolio project has been deleted.",
    })
  }

  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-3xl font-bold">{t("profile")}</h1>
      <div className="grid gap-6 md:grid-cols-[1fr_2fr]">
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-col items-center gap-4">
              <Avatar className="h-24 w-24">
                <AvatarImage src="/placeholder.svg?height=96&width=96" alt="Profile" />
                <AvatarFallback>{`${firstName.charAt(0)}${lastName.charAt(0)}`}</AvatarFallback>
              </Avatar>
              <div className="text-center">
                <h2 className="text-xl font-bold">{`${firstName} ${lastName}`}</h2>
                <p className="text-sm text-muted-foreground">Senior Architect</p>
              </div>
              <div className="flex flex-wrap gap-2 justify-center">
                <Badge variant="secondary">Residential</Badge>
                <Badge variant="secondary">Commercial</Badge>
                <Badge variant="secondary">Sustainable</Badge>
                <Badge variant="secondary">Interior</Badge>
              </div>
              <div className="grid w-full gap-2">
                <Button variant="outline" size="sm">
                  Change Avatar
                </Button>
                <Button variant="outline" size="sm">
                  View Public Profile
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
        <div className="space-y-6">
          <Tabs defaultValue={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="personal">Personal Info</TabsTrigger>
              <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>
            <TabsContent value="personal" className="mt-6 space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Personal Information</CardTitle>
                  <CardDescription>Update your personal details and contact information</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="first-name">First name</Label>
                      <Input id="first-name" value={firstName} onChange={(e) => setFirstName(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="last-name">Last name</Label>
                      <Input id="last-name" value={lastName} onChange={(e) => setLastName(e.target.value)} />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone</Label>
                    <Input id="phone" type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="bio">Bio</Label>
                    <Textarea id="bio" value={bio} onChange={(e) => setBio(e.target.value)} />
                  </div>
                  <Button onClick={handleSavePersonalInfo}>Save Changes</Button>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="portfolio" className="mt-6 space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Portfolio</CardTitle>
                  <CardDescription>Showcase your best work and projects</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                    {portfolioProjects.map((project) => (
                      <div key={project.id} className="overflow-hidden rounded-md border relative group">
                        <img
                          src={project.image || "/placeholder.svg"}
                          alt={project.title}
                          className="h-48 w-full object-cover"
                        />
                        <div className="p-4">
                          <h3 className="font-medium">{project.title}</h3>
                          <p className="text-sm text-muted-foreground">
                            {project.type}, {project.year}
                          </p>
                        </div>
                        <Button
                          variant="destructive"
                          size="sm"
                          className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={() => handleDeleteProject(project.id)}
                        >
                          Delete
                        </Button>
                      </div>
                    ))}

                    {/* Add new project form */}
                    <div className="overflow-hidden rounded-md border border-dashed flex flex-col items-center justify-center p-4">
                      <div className="space-y-4 w-full">
                        <h3 className="font-medium text-center">Add New Project</h3>
                        <div className="space-y-2">
                          <Label htmlFor="project-title">Title</Label>
                          <Input
                            id="project-title"
                            value={newProject.title}
                            onChange={(e) => setNewProject({ ...newProject, title: e.target.value })}
                            placeholder="Project title"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div className="space-y-2">
                            <Label htmlFor="project-type">Type</Label>
                            <Select
                              value={newProject.type}
                              onValueChange={(value) => setNewProject({ ...newProject, type: value })}
                            >
                              <SelectTrigger id="project-type">
                                <SelectValue placeholder="Select type" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="Residential">Residential</SelectItem>
                                <SelectItem value="Commercial">Commercial</SelectItem>
                                <SelectItem value="Industrial">Industrial</SelectItem>
                                <SelectItem value="Institutional">Institutional</SelectItem>
                                <SelectItem value="Interior">Interior Design</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="project-year">Year</Label>
                            <Input
                              id="project-year"
                              value={newProject.year}
                              onChange={(e) => setNewProject({ ...newProject, year: e.target.value })}
                            />
                          </div>
                        </div>
                        <Button className="w-full" onClick={handleAddProject} disabled={!newProject.title}>
                          Add Project
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="settings" className="mt-6 space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Account Settings</CardTitle>
                  <CardDescription>Manage your account preferences and settings</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="language">Language</Label>
                    <Select value={language} onValueChange={(value) => setLanguage(value as any)}>
                      <SelectTrigger id="language">
                        <SelectValue placeholder="Select language" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="en">English</SelectItem>
                        <SelectItem value="es">Español</SelectItem>
                        <SelectItem value="fr">Français</SelectItem>
                        <SelectItem value="de">Deutsch</SelectItem>
                        <SelectItem value="hi">हिन्दी</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="timezone">Timezone</Label>
                    <Select value={timezone} onValueChange={setTimezone}>
                      <SelectTrigger id="timezone">
                        <SelectValue placeholder="Select timezone" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Asia/Kolkata">India (GMT+5:30)</SelectItem>
                        <SelectItem value="America/New_York">Eastern Time (GMT-5)</SelectItem>
                        <SelectItem value="America/Chicago">Central Time (GMT-6)</SelectItem>
                        <SelectItem value="America/Denver">Mountain Time (GMT-7)</SelectItem>
                        <SelectItem value="America/Los_Angeles">Pacific Time (GMT-8)</SelectItem>
                        <SelectItem value="Europe/London">London (GMT+0)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-sm font-medium">Theme Preferences</h3>
                    <div className="flex items-center justify-between">
                      <Label htmlFor="dark-mode">Dark Mode</Label>
                      <Switch id="dark-mode" checked={darkMode} onCheckedChange={setDarkMode} />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-sm font-medium">Email Notifications</h3>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="project-updates">Project updates</Label>
                        <Switch
                          id="project-updates"
                          checked={emailNotifications.projectUpdates}
                          onCheckedChange={(checked) =>
                            setEmailNotifications({ ...emailNotifications, projectUpdates: checked })
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="task-assignments">Task assignments</Label>
                        <Switch
                          id="task-assignments"
                          checked={emailNotifications.taskAssignments}
                          onCheckedChange={(checked) =>
                            setEmailNotifications({ ...emailNotifications, taskAssignments: checked })
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="team-messages">Team messages</Label>
                        <Switch
                          id="team-messages"
                          checked={emailNotifications.teamMessages}
                          onCheckedChange={(checked) =>
                            setEmailNotifications({ ...emailNotifications, teamMessages: checked })
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="system-announcements">System announcements</Label>
                        <Switch
                          id="system-announcements"
                          checked={emailNotifications.systemAnnouncements}
                          onCheckedChange={(checked) =>
                            setEmailNotifications({ ...emailNotifications, systemAnnouncements: checked })
                          }
                        />
                      </div>
                      <div className="flex items-center justify-between">
                        <Label htmlFor="marketing-updates">Marketing updates</Label>
                        <Switch
                          id="marketing-updates"
                          checked={emailNotifications.marketingUpdates}
                          onCheckedChange={(checked) =>
                            setEmailNotifications({ ...emailNotifications, marketingUpdates: checked })
                          }
                        />
                      </div>
                    </div>
                  </div>

                  <Button onClick={handleSaveSettings}>Save Settings</Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}

