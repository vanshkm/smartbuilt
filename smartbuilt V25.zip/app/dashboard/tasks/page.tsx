"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar, Clock, Filter, Plus, Search, Trash2, User } from "lucide-react"
import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

export default function TasksPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [showAddTaskDialog, setShowAddTaskDialog] = useState(false)
  const [newTask, setNewTask] = useState({
    title: "",
    description: "",
    dueDate: "",
    priority: "medium",
    assignee: "",
    project: "",
  })

  const [tasks, setTasks] = useState([
    {
      id: 1,
      title: "Review floor plans for Horizon Residential",
      description: "Check for any inconsistencies or issues with the latest floor plans",
      dueDate: "2024-03-15",
      priority: "high",
      status: "in-progress",
      assignee: "Arjun Patel",
      project: "Modern Residential Complex",
    },
    {
      id: 2,
      title: "Client meeting with Metro Business Solutions",
      description: "Discuss project timeline and budget adjustments",
      dueDate: "2024-03-16",
      priority: "high",
      status: "todo",
      assignee: "Priya Sharma",
      project: "Downtown Office Renovation",
    },
    {
      id: 3,
      title: "Submit permit applications for Urban Park project",
      description: "Complete and submit all required permit applications to the city",
      dueDate: "2024-03-18",
      priority: "medium",
      status: "todo",
      assignee: "Raj Singh",
      project: "Urban Park Redesign",
    },
    {
      id: 4,
      title: "Material selection for Luxury Hotel project",
      description: "Finalize material selections for lobby and common areas",
      dueDate: "2024-03-20",
      priority: "medium",
      status: "in-progress",
      assignee: "Vikram Mehta",
      project: "Luxury Hotel Complex",
    },
    {
      id: 5,
      title: "Structural analysis for Community Center",
      description: "Complete structural analysis and provide recommendations",
      dueDate: "2024-03-17",
      priority: "high",
      status: "in-progress",
      assignee: "Neha Gupta",
      project: "Community Center",
    },
    {
      id: 6,
      title: "Update CAD drawings for residential complex",
      description: "Incorporate client feedback into the latest CAD drawings",
      dueDate: "2024-03-19",
      priority: "medium",
      status: "todo",
      assignee: "Ananya Desai",
      project: "Modern Residential Complex",
    },
    {
      id: 7,
      title: "Finalize restaurant interior design",
      description: "Complete interior design plans for client approval",
      dueDate: "2024-03-14",
      priority: "high",
      status: "completed",
      assignee: "Vikram Mehta",
      project: "Waterfront Restaurant",
    },
    {
      id: 8,
      title: "Coordinate with electrical contractor",
      description: "Discuss electrical requirements for the office renovation",
      dueDate: "2024-03-13",
      priority: "medium",
      status: "completed",
      assignee: "Priya Sharma",
      project: "Downtown Office Renovation",
    },
  ])

  const toggleTaskStatus = (taskId) => {
    setTasks(
      tasks.map((task) => {
        if (task.id === taskId) {
          const newStatus = task.status === "completed" ? "in-progress" : "completed"
          return { ...task, status: newStatus }
        }
        return task
      }),
    )
  }

  const handleDeleteTask = (taskId) => {
    setTasks(tasks.filter((task) => task.id !== taskId))
  }

  const handleAddTask = () => {
    if (!newTask.title || !newTask.dueDate) return

    const newTaskItem = {
      id: tasks.length + 1,
      title: newTask.title,
      description: newTask.description || "No description provided",
      dueDate: newTask.dueDate,
      priority: newTask.priority,
      status: "todo",
      assignee: newTask.assignee || "Unassigned",
      project: newTask.project || "General",
    }

    setTasks([...tasks, newTaskItem])

    // Reset form
    setNewTask({
      title: "",
      description: "",
      dueDate: "",
      priority: "medium",
      assignee: "",
      project: "",
    })
    setShowAddTaskDialog(false)
  }

  const filteredTasks = tasks.filter(
    (task) =>
      task.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.assignee.toLowerCase().includes(searchQuery.toLowerCase()) ||
      task.project.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const todoTasks = filteredTasks.filter((task) => task.status === "todo")
  const inProgressTasks = filteredTasks.filter((task) => task.status === "in-progress")
  const completedTasks = filteredTasks.filter((task) => task.status === "completed")

  const teamMembers = [
    "Arjun Patel",
    "Priya Sharma",
    "Vikram Mehta",
    "Neha Gupta",
    "Raj Singh",
    "Ananya Desai",
    "Unassigned",
  ]

  const projects = [
    "Modern Residential Complex",
    "Downtown Office Renovation",
    "Waterfront Restaurant",
    "Community Center",
    "Luxury Hotel Complex",
    "Urban Park Redesign",
    "General",
  ]

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Tasks</h1>
        <div className="flex items-center gap-2">
          <Button variant="outline">
            <Filter className="mr-2 h-4 w-4" /> Filter
          </Button>
          <Dialog open={showAddTaskDialog} onOpenChange={setShowAddTaskDialog}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" /> Add Task
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Add New Task</DialogTitle>
                <DialogDescription>Create a new task for your project.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="title" className="text-right">
                    Title
                  </Label>
                  <Input
                    id="title"
                    value={newTask.title}
                    onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="description" className="text-right">
                    Description
                  </Label>
                  <Textarea
                    id="description"
                    value={newTask.description}
                    onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="dueDate" className="text-right">
                    Due Date
                  </Label>
                  <Input
                    id="dueDate"
                    type="date"
                    value={newTask.dueDate}
                    onChange={(e) => setNewTask({ ...newTask, dueDate: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="priority" className="text-right">
                    Priority
                  </Label>
                  <Select
                    value={newTask.priority}
                    onValueChange={(value) => setNewTask({ ...newTask, priority: value })}
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="high">High</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="assignee" className="text-right">
                    Assignee
                  </Label>
                  <Select
                    value={newTask.assignee}
                    onValueChange={(value) => setNewTask({ ...newTask, assignee: value })}
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Select assignee" />
                    </SelectTrigger>
                    <SelectContent>
                      {teamMembers.map((member) => (
                        <SelectItem key={member} value={member}>
                          {member}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="project" className="text-right">
                    Project
                  </Label>
                  <Select value={newTask.project} onValueChange={(value) => setNewTask({ ...newTask, project: value })}>
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Select project" />
                    </SelectTrigger>
                    <SelectContent>
                      {projects.map((project) => (
                        <SelectItem key={project} value={project}>
                          {project}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button type="submit" onClick={handleAddTask}>
                  Add Task
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
        <div className="relative w-full max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search tasks..."
            className="w-full pl-8"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex items-center gap-2">
          <Select defaultValue="all-projects">
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="All Projects" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all-projects">All Projects</SelectItem>
              <SelectItem value="modern-residential">Modern Residential Complex</SelectItem>
              <SelectItem value="downtown-office">Downtown Office Renovation</SelectItem>
              <SelectItem value="waterfront-restaurant">Waterfront Restaurant</SelectItem>
              <SelectItem value="community-center">Community Center</SelectItem>
              <SelectItem value="luxury-hotel">Luxury Hotel Complex</SelectItem>
              <SelectItem value="urban-park">Urban Park Redesign</SelectItem>
            </SelectContent>
          </Select>
          <Select defaultValue="all-priorities">
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="All Priorities" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all-priorities">All Priorities</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="low">Low</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">All Tasks</TabsTrigger>
          <TabsTrigger value="todo">To Do</TabsTrigger>
          <TabsTrigger value="in-progress">In Progress</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
        </TabsList>
        <TabsContent value="all" className="mt-6">
          <div className="space-y-4">
            {filteredTasks.map((task) => (
              <Card key={task.id}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <Checkbox
                      id={`task-${task.id}`}
                      checked={task.status === "completed"}
                      onCheckedChange={() => toggleTaskStatus(task.id)}
                    />
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center justify-between">
                        <label
                          htmlFor={`task-${task.id}`}
                          className={`font-medium ${task.status === "completed" ? "line-through text-muted-foreground" : ""}`}
                        >
                          {task.title}
                        </label>
                        <div className="flex items-center gap-2">
                          <div
                            className={`text-xs px-2 py-1 rounded-full ${
                              task.priority === "high"
                                ? "bg-destructive/10 text-destructive"
                                : task.priority === "medium"
                                  ? "bg-amber-500/10 text-amber-500"
                                  : "bg-green-500/10 text-green-500"
                            }`}
                          >
                            {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6 text-muted-foreground hover:text-destructive"
                            onClick={() => handleDeleteTask(task.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground">{task.description}</p>
                      <div className="flex flex-wrap gap-4 pt-2 text-xs text-muted-foreground">
                        <div className="flex items-center">
                          <Calendar className="mr-1 h-3.5 w-3.5" />
                          {new Date(task.dueDate).toLocaleDateString()}
                        </div>
                        <div className="flex items-center">
                          <User className="mr-1 h-3.5 w-3.5" />
                          {task.assignee}
                        </div>
                        <div className="flex items-center">
                          <Clock className="mr-1 h-3.5 w-3.5" />
                          {task.project}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="todo" className="mt-6">
          <div className="space-y-4">
            {todoTasks.map((task) => (
              <Card key={task.id}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <Checkbox
                      id={`task-${task.id}-todo`}
                      checked={task.status === "completed"}
                      onCheckedChange={() => toggleTaskStatus(task.id)}
                    />
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center justify-between">
                        <label htmlFor={`task-${task.id}-todo`} className="font-medium">
                          {task.title}
                        </label>
                        <div className="flex items-center gap-2">
                          <div
                            className={`text-xs px-2 py-1 rounded-full ${
                              task.priority === "high"
                                ? "bg-destructive/10 text-destructive"
                                : task.priority === "medium"
                                  ? "bg-amber-500/10 text-amber-500"
                                  : "bg-green-500/10 text-green-500"
                            }`}
                          >
                            {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6 text-muted-foreground hover:text-destructive"
                            onClick={() => handleDeleteTask(task.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground">{task.description}</p>
                      <div className="flex flex-wrap gap-4 pt-2 text-xs text-muted-foreground">
                        <div className="flex items-center">
                          <Calendar className="mr-1 h-3.5 w-3.5" />
                          {new Date(task.dueDate).toLocaleDateString()}
                        </div>
                        <div className="flex items-center">
                          <User className="mr-1 h-3.5 w-3.5" />
                          {task.assignee}
                        </div>
                        <div className="flex items-center">
                          <Clock className="mr-1 h-3.5 w-3.5" />
                          {task.project}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="in-progress" className="mt-6">
          <div className="space-y-4">
            {inProgressTasks.map((task) => (
              <Card key={task.id}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <Checkbox
                      id={`task-${task.id}-progress`}
                      checked={task.status === "completed"}
                      onCheckedChange={() => toggleTaskStatus(task.id)}
                    />
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center justify-between">
                        <label htmlFor={`task-${task.id}-progress`} className="font-medium">
                          {task.title}
                        </label>
                        <div className="flex items-center gap-2">
                          <div
                            className={`text-xs px-2 py-1 rounded-full ${
                              task.priority === "high"
                                ? "bg-destructive/10 text-destructive"
                                : task.priority === "medium"
                                  ? "bg-amber-500/10 text-amber-500"
                                  : "bg-green-500/10 text-green-500"
                            }`}
                          >
                            {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6 text-muted-foreground hover:text-destructive"
                            onClick={() => handleDeleteTask(task.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground">{task.description}</p>
                      <div className="flex flex-wrap gap-4 pt-2 text-xs text-muted-foreground">
                        <div className="flex items-center">
                          <Calendar className="mr-1 h-3.5 w-3.5" />
                          {new Date(task.dueDate).toLocaleDateString()}
                        </div>
                        <div className="flex items-center">
                          <User className="mr-1 h-3.5 w-3.5" />
                          {task.assignee}
                        </div>
                        <div className="flex items-center">
                          <Clock className="mr-1 h-3.5 w-3.5" />
                          {task.project}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="completed" className="mt-6">
          <div className="space-y-4">
            {completedTasks.map((task) => (
              <Card key={task.id}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <Checkbox
                      id={`task-${task.id}-completed`}
                      checked={task.status === "completed"}
                      onCheckedChange={() => toggleTaskStatus(task.id)}
                    />
                    <div className="flex-1 space-y-1">
                      <div className="flex items-center justify-between">
                        <label
                          htmlFor={`task-${task.id}-completed`}
                          className="font-medium line-through text-muted-foreground"
                        >
                          {task.title}
                        </label>
                        <div className="flex items-center gap-2">
                          <div
                            className={`text-xs px-2 py-1 rounded-full ${
                              task.priority === "high"
                                ? "bg-destructive/10 text-destructive"
                                : task.priority === "medium"
                                  ? "bg-amber-500/10 text-amber-500"
                                  : "bg-green-500/10 text-green-500"
                            }`}
                          >
                            {task.priority.charAt(0).toUpperCase() + task.priority.slice(1)}
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6 text-muted-foreground hover:text-destructive"
                            onClick={() => handleDeleteTask(task.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground">{task.description}</p>
                      <div className="flex flex-wrap gap-4 pt-2 text-xs text-muted-foreground">
                        <div className="flex items-center">
                          <Calendar className="mr-1 h-3.5 w-3.5" />
                          {new Date(task.dueDate).toLocaleDateString()}
                        </div>
                        <div className="flex items-center">
                          <User className="mr-1 h-3.5 w-3.5" />
                          {task.assignee}
                        </div>
                        <div className="flex items-center">
                          <Clock className="mr-1 h-3.5 w-3.5" />
                          {task.project}
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

