import { SharedTodoList } from "@/components/dashboard/shared-todo-list"

export default function ArchitectTodoPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">To-Do List</h1>
        <p className="text-muted-foreground">Manage your tasks and collaborate with contractors and clients</p>
      </div>
      <SharedTodoList />
    </div>
  )
}

