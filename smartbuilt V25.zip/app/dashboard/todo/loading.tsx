import { Skeleton } from "@/components/ui/skeleton"
import { Card, CardContent, CardHeader } from "@/components/ui/card"

export default function TodoLoading() {
  return (
    <div className="space-y-6">
      <div>
        <Skeleton className="h-8 w-[250px]" />
        <Skeleton className="h-4 w-[350px] mt-2" />
      </div>

      <Card>
        <CardHeader>
          <Skeleton className="h-6 w-[180px]" />
          <Skeleton className="h-4 w-[250px] mt-2" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-10 w-full mb-4" />

          {Array(5)
            .fill(0)
            .map((_, i) => (
              <div key={i} className="flex items-start space-x-2 mb-3">
                <Skeleton className="h-5 w-5 rounded-sm" />
                <div className="flex-1">
                  <Skeleton className="h-5 w-full" />
                  <Skeleton className="h-3 w-[200px] mt-2" />
                </div>
              </div>
            ))}
        </CardContent>
      </Card>
    </div>
  )
}

