"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  Building2,
  Hammer,
  MapPin,
  Phone,
  Search,
  Truck,
  User,
  ZoomIn,
  ZoomOut,
  Move,
  Plus,
  Trash2,
  X,
  Maximize2,
} from "lucide-react"
import { useLanguage } from "@/contexts/language-context"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function MapPage() {
  const { t } = useLanguage()
  const [searchQuery, setSearchQuery] = useState("")
  const [zoom, setZoom] = useState(1)
  const [isDragging, setIsDragging] = useState(false)
  const [mapPosition, setMapPosition] = useState({ x: 0, y: 0 })
  const [startDragPosition, setStartDragPosition] = useState({ x: 0, y: 0 })
  const mapRef = useRef<HTMLDivElement>(null)
  const [showAddLocationDialog, setShowAddLocationDialog] = useState(false)
  const [show3DView, setShow3DView] = useState(false)
  const [selectedProject, setSelectedProject] = useState(null)
  const [newLocation, setNewLocation] = useState({
    name: "",
    type: "project",
    address: "",
    status: "active",
    contact: "",
    phone: "",
    coordinates: { lat: 0, lng: 0 },
    specialty: "",
    products: "",
  })

  const [locations, setLocations] = useState([
    {
      id: 1,
      name: "Modern Residential Complex",
      type: "project",
      address: "123 MG Road, Bangalore, India",
      status: "In Progress",
      contact: "Arjun Patel",
      phone: "+91 98765 43210",
      coordinates: { lat: 12.9716, lng: 77.5946 }, // Bangalore
      image: "/placeholder.svg?height=300&width=500",
      description:
        "A modern residential complex with 200 apartments and amenities including swimming pool, gym, and community center.",
    },
    {
      id: 2,
      name: "Downtown Office Renovation",
      type: "project",
      address: "456 Nariman Point, Mumbai, India",
      status: "In Progress",
      contact: "Priya Sharma",
      phone: "+91 87654 32109",
      coordinates: { lat: 18.9217, lng: 72.833 }, // Mumbai
      image: "/placeholder.svg?height=300&width=500",
      description:
        "Renovation of a 15-story office building in Mumbai's business district with modern interiors and energy-efficient systems.",
    },
    {
      id: 3,
      name: "Kapoor Construction",
      type: "contractor",
      address: "789 Anna Salai, Chennai, India",
      specialty: "General Contractor",
      contact: "Ravi Kapoor",
      phone: "+91 32109 87654",
      coordinates: { lat: 13.0827, lng: 80.2707 }, // Chennai
    },
    {
      id: 4,
      name: "Joshi Electrical",
      type: "contractor",
      address: "321 Connaught Place, New Delhi, India",
      specialty: "Electrical Contractor",
      contact: "Meera Joshi",
      phone: "+91 21098 76543",
      coordinates: { lat: 28.6139, lng: 77.209 }, // Delhi
    },
    {
      id: 5,
      name: "Woodland Materials",
      type: "supplier",
      address: "654 Jubilee Hills, Hyderabad, India",
      products: "Lumber, Flooring, Panels",
      contact: "Vikram Mehta",
      phone: "+91 76543 21098",
      coordinates: { lat: 17.4065, lng: 78.4772 }, // Hyderabad
    },
    {
      id: 6,
      name: "Modern Surfaces",
      type: "supplier",
      address: "987 Park Street, Kolkata, India",
      products: "Tiles, Countertops, Fixtures",
      contact: "Neha Gupta",
      phone: "+91 65432 10987",
      coordinates: { lat: 22.5726, lng: 88.3639 }, // Kolkata
    },
    {
      id: 7,
      name: "Tech Park Development",
      type: "project",
      address: "10 Electronic City, Bangalore, India",
      status: "Planning",
      contact: "Raj Singh",
      phone: "+91 54321 09876",
      coordinates: { lat: 12.8399, lng: 77.677 }, // Electronic City, Bangalore
      image: "/placeholder.svg?height=300&width=500",
      description:
        "A state-of-the-art technology park with office spaces for IT companies, conference centers, and recreational facilities.",
    },
    {
      id: 8,
      name: "Luxury Hotel Complex",
      type: "project",
      address: "25 Marine Drive, Kochi, India",
      status: "In Progress",
      contact: "Ananya Desai",
      phone: "+91 43210 98765",
      coordinates: { lat: 9.9312, lng: 76.2673 }, // Kochi
      image: "/placeholder.svg?height=300&width=500",
      description:
        "A 5-star luxury hotel with 300 rooms, multiple restaurants, conference facilities, and a spa overlooking the Arabian Sea.",
    },
    {
      id: 9,
      name: "Verma Design Studio",
      type: "contractor",
      address: "5-1 Civil Lines, Jaipur, India",
      specialty: "Interior Design",
      contact: "Sanjay Verma",
      phone: "+91 10987 65432",
      coordinates: { lat: 26.9124, lng: 75.7873 }, // Jaipur
    },
    {
      id: 10,
      name: "Goa Beachfront Resort",
      type: "project",
      address: "100 Calangute Beach Road, Goa, India",
      status: "Planning",
      contact: "Kavita Reddy",
      phone: "+91 09876 54321",
      coordinates: { lat: 15.5491, lng: 73.7632 }, // Goa
      image: "/placeholder.svg?height=300&width=500",
      description:
        "A beachfront resort with 150 villas, multiple swimming pools, restaurants, and direct beach access.",
    },
  ])

  const handleAddLocation = () => {
    if (!newLocation.name || !newLocation.address) return

    // Generate random coordinates if not provided
    const randomLat = newLocation.coordinates.lat || Math.random() * 180 - 90
    const randomLng = newLocation.coordinates.lng || Math.random() * 360 - 180

    const newLocationItem = {
      id: locations.length + 1,
      name: newLocation.name,
      type: newLocation.type,
      address: newLocation.address,
      status: newLocation.type === "project" ? newLocation.status || "In Progress" : undefined,
      specialty: newLocation.type === "contractor" ? newLocation.specialty || "General Contractor" : undefined,
      products: newLocation.type === "supplier" ? newLocation.products || "Building Materials" : undefined,
      contact: newLocation.contact || "Contact Person",
      phone: newLocation.phone || "+91 99999 88888",
      coordinates: { lat: randomLat, lng: randomLng },
      image: newLocation.type === "project" ? "/placeholder.svg?height=300&width=500" : undefined,
      description: newLocation.type === "project" ? "New project description" : undefined,
    }

    setLocations([...locations, newLocationItem])

    // Reset form
    setNewLocation({
      name: "",
      type: "project",
      address: "",
      status: "active",
      contact: "",
      phone: "",
      coordinates: { lat: 0, lng: 0 },
      specialty: "",
      products: "",
    })

    setShowAddLocationDialog(false)
  }

  const handleDeleteLocation = (id) => {
    setLocations(locations.filter((location) => location.id !== id))
  }

  const handleProjectClick = (project) => {
    setSelectedProject(project)
    setShow3DView(true)
  }

  const filteredLocations = locations.filter(
    (location) =>
      location.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      location.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
      location.contact.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const projects = filteredLocations.filter((location) => location.type === "project")
  const contractors = filteredLocations.filter((location) => location.type === "contractor")
  const suppliers = filteredLocations.filter((location) => location.type === "supplier")

  // Map interaction handlers
  const handleZoomIn = () => {
    setZoom((prev) => Math.min(prev + 0.2, 2.5))
  }

  const handleZoomOut = () => {
    setZoom((prev) => Math.max(prev - 0.2, 0.5))
  }

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true)
    setStartDragPosition({ x: e.clientX - mapPosition.x, y: e.clientY - mapPosition.y })
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging && mapRef.current) {
      const newX = e.clientX - startDragPosition.x
      const newY = e.clientY - startDragPosition.y
      setMapPosition({ x: newX, y: newY })
    }
  }

  const handleMouseUp = () => {
    setIsDragging(false)
  }

  // Convert lat/lng to x/y coordinates on the map
  const getMarkerPosition = (lat: number, lng: number) => {
    // Simple mercator projection
    const mapWidth = 1000 // Base map width
    const mapHeight = 500 // Base map height

    const x = (lng + 180) * (mapWidth / 360)
    const latRad = (lat * Math.PI) / 180
    const mercN = Math.log(Math.tan(Math.PI / 4 + latRad / 2))
    const y = mapHeight / 2 - (mapWidth * mercN) / (2 * Math.PI)

    return { x, y }
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">{t("interactiveMap")}</h1>
        <Dialog open={showAddLocationDialog} onOpenChange={setShowAddLocationDialog}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" /> {t("addLocation")}
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Add New Location</DialogTitle>
              <DialogDescription>Add a new project, contractor, or supplier to your map.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="location-type" className="text-right">
                  Type
                </Label>
                <Select
                  value={newLocation.type}
                  onValueChange={(value) => setNewLocation({ ...newLocation, type: value })}
                >
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select location type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="project">Project</SelectItem>
                    <SelectItem value="contractor">Contractor</SelectItem>
                    <SelectItem value="supplier">Supplier</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="name" className="text-right">
                  Name
                </Label>
                <Input
                  id="name"
                  value={newLocation.name}
                  onChange={(e) => setNewLocation({ ...newLocation, name: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="address" className="text-right">
                  Address
                </Label>
                <Input
                  id="address"
                  value={newLocation.address}
                  onChange={(e) => setNewLocation({ ...newLocation, address: e.target.value })}
                  className="col-span-3"
                />
              </div>

              {newLocation.type === "project" && (
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="status" className="text-right">
                    Status
                  </Label>
                  <Select
                    value={newLocation.status}
                    onValueChange={(value) => setNewLocation({ ...newLocation, status: value })}
                  >
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Planning">Planning</SelectItem>
                      <SelectItem value="In Progress">In Progress</SelectItem>
                      <SelectItem value="Completed">Completed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}

              {newLocation.type === "contractor" && (
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="specialty" className="text-right">
                    Specialty
                  </Label>
                  <Input
                    id="specialty"
                    value={newLocation.specialty}
                    onChange={(e) => setNewLocation({ ...newLocation, specialty: e.target.value })}
                    placeholder="e.g. General Contractor"
                    className="col-span-3"
                  />
                </div>
              )}

              {newLocation.type === "supplier" && (
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="products" className="text-right">
                    Products
                  </Label>
                  <Input
                    id="products"
                    value={newLocation.products}
                    onChange={(e) => setNewLocation({ ...newLocation, products: e.target.value })}
                    placeholder="e.g. Lumber, Flooring"
                    className="col-span-3"
                  />
                </div>
              )}

              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="contact" className="text-right">
                  Contact
                </Label>
                <Input
                  id="contact"
                  value={newLocation.contact}
                  onChange={(e) => setNewLocation({ ...newLocation, contact: e.target.value })}
                  className="col-span-3"
                />
              </div>

              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="phone" className="text-right">
                  Phone
                </Label>
                <Input
                  id="phone"
                  value={newLocation.phone}
                  onChange={(e) => setNewLocation({ ...newLocation, phone: e.target.value })}
                  placeholder="e.g. +91 98765 43210"
                  className="col-span-3"
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="submit" onClick={handleAddLocation}>
                Add Location
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-6 md:grid-cols-[1fr_300px]">
        <Card className="min-h-[500px]">
          <CardContent className="p-0 overflow-hidden rounded-md">
            <div
              ref={mapRef}
              className="relative w-full h-[500px] bg-muted overflow-hidden cursor-grab"
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
              style={{ cursor: isDragging ? "grabbing" : "grab" }}
            >
              {/* World Map */}
              <div
                className="absolute"
                style={{
                  transform: `translate(${mapPosition.x}px, ${mapPosition.y}px) scale(${zoom})`,
                  transformOrigin: "center",
                  transition: isDragging ? "none" : "transform 0.2s ease-out",
                }}
              >
                <img src="/world-map.svg" alt="World Map" className="w-[1000px] h-[500px] object-contain" />

                {/* Map Markers */}
                {locations.map((location) => {
                  const position = getMarkerPosition(location.coordinates.lat, location.coordinates.lng)

                  return (
                    <div
                      key={location.id}
                      className="absolute cursor-pointer group"
                      style={{
                        left: `${position.x}px`,
                        top: `${position.y}px`,
                      }}
                      onClick={() => location.type === "project" && handleProjectClick(location)}
                    >
                      <div
                        className={`p-2 rounded-full ${
                          location.type === "project"
                            ? "bg-primary"
                            : location.type === "contractor"
                              ? "bg-amber-500"
                              : "bg-green-500"
                        }`}
                      >
                        {location.type === "project" ? (
                          <Building2 className="h-4 w-4 text-white" />
                        ) : location.type === "contractor" ? (
                          <Hammer className="h-4 w-4 text-white" />
                        ) : (
                          <Truck className="h-4 w-4 text-white" />
                        )}
                      </div>
                      <div className="absolute left-1/2 bottom-full mb-2 -translate-x-1/2 whitespace-nowrap rounded-md bg-background p-2 text-xs font-medium shadow-md opacity-0 group-hover:opacity-100 transition-opacity z-10">
                        <div className="font-bold">{location.name}</div>
                        <div className="text-muted-foreground">{location.address}</div>
                        {location.type === "project" && (
                          <div className="text-primary text-[10px] mt-1">Click to view 3D model</div>
                        )}
                      </div>
                    </div>
                  )
                })}
              </div>

              {/* Map Controls */}
              <div className="absolute bottom-4 right-4 flex flex-col gap-2">
                <Button variant="secondary" size="icon" onClick={handleZoomIn}>
                  <ZoomIn className="h-4 w-4" />
                </Button>
                <Button variant="secondary" size="icon" onClick={handleZoomOut}>
                  <ZoomOut className="h-4 w-4" />
                </Button>
                <Button variant="secondary" size="icon" onClick={() => setMapPosition({ x: 0, y: 0 })}>
                  <Move className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-6">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder={t("searchLocations")}
              className="w-full pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <Tabs defaultValue="all">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="all">{t("all")}</TabsTrigger>
              <TabsTrigger value="projects">{t("projects")}</TabsTrigger>
              <TabsTrigger value="contractors">{t("contractors")}</TabsTrigger>
              <TabsTrigger value="suppliers">{t("suppliers")}</TabsTrigger>
            </TabsList>
            <TabsContent value="all" className="mt-4 space-y-4 max-h-[350px] overflow-y-auto pr-2">
              {filteredLocations.map((location) => (
                <Card key={location.id} className="relative group">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-2 right-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity bg-background/80 hover:bg-background/90 hover:text-destructive"
                    onClick={() => handleDeleteLocation(location.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div
                        className={`rounded-full p-2 ${
                          location.type === "project"
                            ? "bg-primary/10"
                            : location.type === "contractor"
                              ? "bg-amber-500/10"
                              : "bg-green-500/10"
                        }`}
                      >
                        {location.type === "project" ? (
                          <Building2
                            className={`h-5 w-5 ${
                              location.type === "project"
                                ? "text-primary"
                                : location.type === "contractor"
                                  ? "text-amber-500"
                                  : "text-green-500"
                            }`}
                          />
                        ) : location.type === "contractor" ? (
                          <Hammer
                            className={`h-5 w-5 ${
                              location.type === "project"
                                ? "text-primary"
                                : location.type === "contractor"
                                  ? "text-amber-500"
                                  : "text-green-500"
                            }`}
                          />
                        ) : (
                          <Truck
                            className={`h-5 w-5 ${
                              location.type === "project"
                                ? "text-primary"
                                : location.type === "contractor"
                                  ? "text-amber-500"
                                  : "text-green-500"
                            }`}
                          />
                        )}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <h3 className="font-medium">{location.name}</h3>
                          <Badge variant="outline" className="capitalize">
                            {location.type}
                          </Badge>
                        </div>
                        <div className="mt-1 flex items-center text-xs text-muted-foreground">
                          <MapPin className="mr-1 h-3.5 w-3.5" />
                          {location.address}
                        </div>
                        <div className="mt-2 flex items-center text-xs">
                          {location.type === "project" ? (
                            <Badge variant="secondary">{location.status}</Badge>
                          ) : location.type === "contractor" ? (
                            <span className="text-muted-foreground">{location.specialty}</span>
                          ) : (
                            <span className="text-muted-foreground">{location.products}</span>
                          )}
                        </div>
                        <div className="mt-2 flex items-center gap-4 text-xs text-muted-foreground">
                          <div className="flex items-center">
                            <User className="mr-1 h-3.5 w-3.5" />
                            {location.contact}
                          </div>
                          <div className="flex items-center">
                            <Phone className="mr-1 h-3.5 w-3.5" />
                            {location.phone}
                          </div>
                        </div>
                        {location.type === "project" && (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="mt-2 text-xs text-primary p-0 h-auto"
                            onClick={() => handleProjectClick(location)}
                          >
                            View 3D Model
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>
            <TabsContent value="projects" className="mt-4 space-y-4 max-h-[350px] overflow-y-auto pr-2">
              {projects.map((project) => (
                <Card key={project.id} className="relative group">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-2 right-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity bg-background/80 hover:bg-background/90 hover:text-destructive"
                    onClick={() => handleDeleteLocation(project.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className="rounded-full p-2 bg-primary/10">
                        <Building2 className="h-5 w-5 text-primary" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <h3 className="font-medium">{project.name}</h3>
                          <Badge variant="outline" className="capitalize">
                            {project.type}
                          </Badge>
                        </div>
                        <div className="mt-1 flex items-center text-xs text-muted-foreground">
                          <MapPin className="mr-1 h-3.5 w-3.5" />
                          {project.address}
                        </div>
                        <div className="mt-2 flex items-center text-xs">
                          <Badge variant="secondary">{project.status}</Badge>
                        </div>
                        <div className="mt-2 flex items-center gap-4 text-xs text-muted-foreground">
                          <div className="flex items-center">
                            <User className="mr-1 h-3.5 w-3.5" />
                            {project.contact}
                          </div>
                          <div className="flex items-center">
                            <Phone className="mr-1 h-3.5 w-3.5" />
                            {project.phone}
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="mt-2 text-xs text-primary p-0 h-auto"
                          onClick={() => handleProjectClick(project)}
                        >
                          View 3D Model
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>
            <TabsContent value="contractors" className="mt-4 space-y-4 max-h-[350px] overflow-y-auto pr-2">
              {contractors.map((contractor) => (
                <Card key={contractor.id} className="relative group">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-2 right-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity bg-background/80 hover:bg-background/90 hover:text-destructive"
                    onClick={() => handleDeleteLocation(contractor.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className="rounded-full p-2 bg-amber-500/10">
                        <Hammer className="h-5 w-5 text-amber-500" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <h3 className="font-medium">{contractor.name}</h3>
                          <Badge variant="outline" className="capitalize">
                            {contractor.type}
                          </Badge>
                        </div>
                        <div className="mt-1 flex items-center text-xs text-muted-foreground">
                          <MapPin className="mr-1 h-3.5 w-3.5" />
                          {contractor.address}
                        </div>
                        <div className="mt-2 flex items-center text-xs">
                          <span className="text-muted-foreground">{contractor.specialty}</span>
                        </div>
                        <div className="mt-2 flex items-center gap-4 text-xs text-muted-foreground">
                          <div className="flex items-center">
                            <User className="mr-1 h-3.5 w-3.5" />
                            {contractor.contact}
                          </div>
                          <div className="flex items-center">
                            <Phone className="mr-1 h-3.5 w-3.5" />
                            {contractor.phone}
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>
            <TabsContent value="suppliers" className="mt-4 space-y-4 max-h-[350px] overflow-y-auto pr-2">
              {suppliers.map((supplier) => (
                <Card key={supplier.id} className="relative group">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="absolute top-2 right-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity bg-background/80 hover:bg-background/90 hover:text-destructive"
                    onClick={() => handleDeleteLocation(supplier.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                  <CardContent className="p-4">
                    <div className="flex items-start gap-4">
                      <div className="rounded-full p-2 bg-green-500/10">
                        <Truck className="h-5 w-5 text-green-500" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <h3 className="font-medium">{supplier.name}</h3>
                          <Badge variant="outline" className="capitalize">
                            {supplier.type}
                          </Badge>
                        </div>
                        <div className="mt-1 flex items-center text-xs text-muted-foreground">
                          <MapPin className="mr-1 h-3.5 w-3.5" />
                          {supplier.address}
                        </div>
                        <div className="mt-2 flex items-center text-xs">
                          <span className="text-muted-foreground">{supplier.products}</span>
                        </div>
                        <div className="mt-2 flex items-center gap-4 text-xs text-muted-foreground">
                          <div className="flex items-center">
                            <User className="mr-1 h-3.5 w-3.5" />
                            {supplier.contact}
                          </div>
                          <div className="flex items-center">
                            <Phone className="mr-1 h-3.5 w-3.5" />
                            {supplier.phone}
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* 3D View Dialog */}
      <Dialog open={show3DView} onOpenChange={setShow3DView}>
        <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
          {selectedProject && (
            <>
              <DialogHeader>
                <div className="flex items-center justify-between">
                  <DialogTitle>{selectedProject.name}</DialogTitle>
                  <Button variant="ghost" size="icon" onClick={() => setShow3DView(false)}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                <DialogDescription>{selectedProject.address}</DialogDescription>
              </DialogHeader>
              <div className="relative">
                <img
                  src={selectedProject.image || "/placeholder.svg"}
                  alt={selectedProject.name}
                  className="w-full h-[300px] object-cover rounded-md"
                />
                <Button
                  variant="secondary"
                  size="icon"
                  className="absolute top-2 right-2"
                  onClick={() => window.open(selectedProject.image, "_blank")}
                >
                  <Maximize2 className="h-4 w-4" />
                </Button>
              </div>
              <div className="space-y-4 mt-4">
                <h3 className="text-lg font-medium">Project Details</h3>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div className="font-medium">Status:</div>
                  <div>{selectedProject.status}</div>
                  <div className="font-medium">Contact:</div>
                  <div>{selectedProject.contact}</div>
                  <div className="font-medium">Phone:</div>
                  <div>{selectedProject.phone}</div>
                </div>
                <div className="pt-2">
                  <h4 className="text-md font-medium mb-2">Description</h4>
                  <p className="text-sm text-muted-foreground">{selectedProject.description}</p>
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setShow3DView(false)}>
                  Close
                </Button>
                <Button>Download Blueprint</Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

