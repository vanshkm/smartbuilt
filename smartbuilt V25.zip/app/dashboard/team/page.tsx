"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Filter, Search, UserPlus, X } from "lucide-react"
import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function TeamPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [showAddMemberDialog, setShowAddMemberDialog] = useState(false)
  const [newMember, setNewMember] = useState({
    name: "",
    role: "",
    email: "",
    phone: "",
    type: "team-member", // or "contractor"
    company: "",
    specialties: [],
    skills: [],
    projects: [],
  })
  const [teamMembers, setTeamMembers] = useState([
    {
      id: 1,
      name: "Arjun Patel",
      role: "Senior Architect",
      email: "arjun.patel@example.com",
      phone: "+91 98765 43210",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "AP",
      status: "active",
      projects: ["Modern Residential Complex", "Downtown Office Renovation"],
      skills: ["Residential", "Commercial", "Sustainable Design"],
    },
    {
      id: 2,
      name: "Priya Sharma",
      role: "Project Manager",
      email: "priya.sharma@example.com",
      phone: "+91 87654 32109",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "PS",
      status: "active",
      projects: ["Modern Residential Complex", "Urban Park Redesign"],
      skills: ["Project Management", "Budgeting", "Client Relations"],
    },
    {
      id: 3,
      name: "Vikram Mehta",
      role: "Interior Designer",
      email: "vikram.mehta@example.com",
      phone: "+91 76543 21098",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "VM",
      status: "active",
      projects: ["Luxury Hotel Complex", "Waterfront Restaurant"],
      skills: ["Interior Design", "Color Theory", "Space Planning"],
    },
    {
      id: 4,
      name: "Neha Gupta",
      role: "Structural Engineer",
      email: "neha.gupta@example.com",
      phone: "+91 65432 10987",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "NG",
      status: "active",
      projects: ["Community Center", "Downtown Office Renovation"],
      skills: ["Structural Analysis", "Building Codes", "Seismic Design"],
    },
    {
      id: 5,
      name: "Raj Singh",
      role: "Landscape Architect",
      email: "raj.singh@example.com",
      phone: "+91 54321 09876",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "RS",
      status: "away",
      projects: ["Urban Park Redesign", "Community Center"],
      skills: ["Landscape Design", "Sustainable Landscaping", "Urban Planning"],
    },
    {
      id: 6,
      name: "Ananya Desai",
      role: "CAD Specialist",
      email: "ananya.desai@example.com",
      phone: "+91 43210 98765",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "AD",
      status: "offline",
      projects: ["Modern Residential Complex", "Luxury Hotel Complex"],
      skills: ["AutoCAD", "Revit", "3D Modeling"],
    },
  ])

  const [contractors, setContractors] = useState([
    {
      id: 1,
      name: "Ravi Kapoor",
      company: "Kapoor Construction",
      role: "General Contractor",
      email: "ravi@kapoorconstruction.com",
      phone: "+91 32109 87654",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "RK",
      status: "active",
      specialties: ["Residential", "Commercial"],
    },
    {
      id: 2,
      name: "Meera Joshi",
      company: "Joshi Electrical",
      role: "Electrical Contractor",
      email: "meera@joshielectrical.com",
      phone: "+91 21098 76543",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "MJ",
      status: "active",
      specialties: ["Residential", "Commercial", "Industrial"],
    },
    {
      id: 3,
      name: "Sanjay Verma",
      company: "Verma Plumbing",
      role: "Plumbing Contractor",
      email: "sanjay@vermaplumbing.com",
      phone: "+91 10987 65432",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "SV",
      status: "away",
      specialties: ["Residential", "Commercial"],
    },
    {
      id: 4,
      name: "Kavita Reddy",
      company: "Reddy HVAC",
      role: "HVAC Contractor",
      email: "kavita@reddyhvac.com",
      phone: "+91 09876 54321",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "KR",
      status: "active",
      specialties: ["Residential", "Commercial", "Industrial"],
    },
  ])

  const handleAddMember = () => {
    if (!newMember.name || !newMember.role || !newMember.email) return

    const initials = newMember.name
      .split(" ")
      .map((part) => part[0])
      .join("")
      .toUpperCase()

    if (newMember.type === "team-member") {
      const newTeamMember = {
        id: teamMembers.length + 1,
        name: newMember.name,
        role: newMember.role,
        email: newMember.email,
        phone: newMember.phone || "+91 99999 88888",
        avatar: "/placeholder.svg?height=40&width=40",
        initials: initials,
        status: "active",
        projects: [],
        skills: newMember.skills.length ? newMember.skills : ["New Hire"],
      }
      setTeamMembers([...teamMembers, newTeamMember])
    } else {
      const newContractor = {
        id: contractors.length + 1,
        name: newMember.name,
        company: newMember.company || `${newMember.name.split(" ")[0]} Services`,
        role: newMember.role,
        email: newMember.email,
        phone: newMember.phone || "+91 99999 88888",
        avatar: "/placeholder.svg?height=40&width=40",
        initials: initials,
        status: "active",
        specialties: newMember.specialties.length ? newMember.specialties : ["Residential"],
      }
      setContractors([...contractors, newContractor])
    }

    // Reset form
    setNewMember({
      name: "",
      role: "",
      email: "",
      phone: "",
      type: "team-member",
      company: "",
      specialties: [],
      skills: [],
      projects: [],
    })
    setShowAddMemberDialog(false)
  }

  const handleRemoveMember = (id, type) => {
    if (type === "team-member") {
      setTeamMembers(teamMembers.filter((member) => member.id !== id))
    } else {
      setContractors(contractors.filter((contractor) => contractor.id !== id))
    }
  }

  const filteredTeamMembers = teamMembers.filter(
    (member) =>
      member.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      member.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
      member.email.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const filteredContractors = contractors.filter(
    (contractor) =>
      contractor.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      contractor.company.toLowerCase().includes(searchQuery.toLowerCase()) ||
      contractor.role.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Team</h1>
        <div className="flex items-center gap-2">
          <Button variant="outline">
            <Filter className="mr-2 h-4 w-4" /> Filter
          </Button>
          <Dialog open={showAddMemberDialog} onOpenChange={setShowAddMemberDialog}>
            <DialogTrigger asChild>
              <Button>
                <UserPlus className="mr-2 h-4 w-4" /> Add Member
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Add New Team Member</DialogTitle>
                <DialogDescription>Add a new team member or contractor to your project.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="member-type" className="text-right">
                    Type
                  </Label>
                  <Select value={newMember.type} onValueChange={(value) => setNewMember({ ...newMember, type: value })}>
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="team-member">Team Member</SelectItem>
                      <SelectItem value="contractor">Contractor</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="name" className="text-right">
                    Name
                  </Label>
                  <Input
                    id="name"
                    value={newMember.name}
                    onChange={(e) => setNewMember({ ...newMember, name: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="role" className="text-right">
                    Role
                  </Label>
                  <Input
                    id="role"
                    value={newMember.role}
                    onChange={(e) => setNewMember({ ...newMember, role: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                {newMember.type === "contractor" && (
                  <div className="grid grid-cols-4 items-center gap-4">
                    <Label htmlFor="company" className="text-right">
                      Company
                    </Label>
                    <Input
                      id="company"
                      value={newMember.company}
                      onChange={(e) => setNewMember({ ...newMember, company: e.target.value })}
                      className="col-span-3"
                    />
                  </div>
                )}
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="email" className="text-right">
                    Email
                  </Label>
                  <Input
                    id="email"
                    value={newMember.email}
                    onChange={(e) => setNewMember({ ...newMember, email: e.target.value })}
                    className="col-span-3"
                  />
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="phone" className="text-right">
                    Phone
                  </Label>
                  <Input
                    id="phone"
                    value={newMember.phone}
                    onChange={(e) => setNewMember({ ...newMember, phone: e.target.value })}
                    className="col-span-3"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="submit" onClick={handleAddMember}>
                  Add Member
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="relative w-full max-w-sm">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          type="search"
          placeholder="Search team members..."
          className="w-full pl-8"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <Tabs defaultValue="team-members">
        <TabsList>
          <TabsTrigger value="team-members">Team Members</TabsTrigger>
          <TabsTrigger value="contractors">Contractors</TabsTrigger>
        </TabsList>
        <TabsContent value="team-members" className="mt-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filteredTeamMembers.map((member) => (
              <Card key={member.id}>
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="relative">
                        <Avatar>
                          <AvatarImage src={member.avatar} alt={member.name} />
                          <AvatarFallback>{member.initials}</AvatarFallback>
                        </Avatar>
                        <span
                          className={`absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-background ${
                            member.status === "active"
                              ? "bg-green-500"
                              : member.status === "away"
                                ? "bg-amber-500"
                                : "bg-muted"
                          }`}
                        />
                      </div>
                      <div>
                        <CardTitle className="text-base">{member.name}</CardTitle>
                        <CardDescription>{member.role}</CardDescription>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-muted-foreground hover:text-foreground"
                      onClick={() => handleRemoveMember(member.id, "team-member")}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-1">
                      <div className="text-xs text-muted-foreground">Contact</div>
                      <div className="text-sm">{member.email}</div>
                      <div className="text-sm">{member.phone}</div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-xs text-muted-foreground">Projects</div>
                      <div className="text-sm">{member.projects.join(", ") || "No projects assigned"}</div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-xs text-muted-foreground">Skills</div>
                      <div className="flex flex-wrap gap-1">
                        {member.skills.map((skill, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="contractors" className="mt-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filteredContractors.map((contractor) => (
              <Card key={contractor.id}>
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="relative">
                        <Avatar>
                          <AvatarImage src={contractor.avatar} alt={contractor.name} />
                          <AvatarFallback>{contractor.initials}</AvatarFallback>
                        </Avatar>
                        <span
                          className={`absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-background ${
                            contractor.status === "active"
                              ? "bg-green-500"
                              : contractor.status === "away"
                                ? "bg-amber-500"
                                : "bg-muted"
                          }`}
                        />
                      </div>
                      <div>
                        <CardTitle className="text-base">{contractor.name}</CardTitle>
                        <CardDescription>{contractor.company}</CardDescription>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-muted-foreground hover:text-foreground"
                      onClick={() => handleRemoveMember(contractor.id, "contractor")}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="space-y-1">
                      <div className="text-xs text-muted-foreground">Role</div>
                      <div className="text-sm">{contractor.role}</div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-xs text-muted-foreground">Contact</div>
                      <div className="text-sm">{contractor.email}</div>
                      <div className="text-sm">{contractor.phone}</div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-xs text-muted-foreground">Specialties</div>
                      <div className="flex flex-wrap gap-1">
                        {contractor.specialties.map((specialty, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {specialty}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

