"use client"

import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Plus, Trash2 } from "lucide-react"
import { ProjectCard } from "@/components/dashboard/project-card"
import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"

export default function ProjectsPage() {
  const [showAddProjectDialog, setShowAddProjectDialog] = useState(false)
  const [newProject, setNewProject] = useState({
    title: "",
    client: "",
    dueDate: "",
    team: 3,
    tasks: 0,
    progress: 0,
    image: "/placeholder.svg?height=200&width=300",
  })

  const [projects, setProjects] = useState([
    {
      id: 1,
      title: "Modern Residential Complex",
      client: "Horizon Developers",
      progress: 75,
      dueDate: "2024-08-15",
      team: 5,
      tasks: 24,
      image: "/placeholder.svg?height=200&width=300",
      status: "active",
    },
    {
      id: 2,
      title: "Downtown Office Renovation",
      client: "Metro Business Solutions",
      progress: 45,
      dueDate: "2024-06-30",
      team: 3,
      tasks: 18,
      image: "/placeholder.svg?height=200&width=300",
      status: "active",
    },
    {
      id: 3,
      title: "Waterfront Restaurant",
      client: "Coastal Dining Group",
      progress: 90,
      dueDate: "2024-05-10",
      team: 4,
      tasks: 12,
      image: "/placeholder.svg?height=200&width=300",
      status: "completed",
    },
    {
      id: 4,
      title: "Community Center",
      client: "Oakridge Municipality",
      progress: 30,
      dueDate: "2024-11-20",
      team: 7,
      tasks: 32,
      image: "/placeholder.svg?height=200&width=300",
      status: "active",
    },
    {
      id: 5,
      title: "Luxury Hotel Complex",
      client: "Elite Hospitality",
      progress: 15,
      dueDate: "2025-02-28",
      team: 9,
      tasks: 45,
      image: "/placeholder.svg?height=200&width=300",
      status: "active",
    },
    {
      id: 6,
      title: "Urban Park Redesign",
      client: "City Parks Department",
      progress: 60,
      dueDate: "2024-07-15",
      team: 4,
      tasks: 20,
      image: "/placeholder.svg?height=200&width=300",
      status: "active",
    },
    {
      id: 7,
      title: "Public Library Renovation",
      client: "City Council",
      progress: 100,
      dueDate: "2023-11-15",
      team: 6,
      tasks: 28,
      image: "/placeholder.svg?height=200&width=300",
      status: "archived",
    },
  ])

  const handleAddProject = () => {
    if (!newProject.title || !newProject.client || !newProject.dueDate) return

    const newProjectItem = {
      id: projects.length + 1,
      title: newProject.title,
      client: newProject.client,
      progress: newProject.progress,
      dueDate: newProject.dueDate,
      team: Number.parseInt(newProject.team) || 3,
      tasks: Number.parseInt(newProject.tasks) || 0,
      image: "/placeholder.svg?height=200&width=300",
      status: "active",
    }

    setProjects([...projects, newProjectItem])

    // Reset form
    setNewProject({
      title: "",
      client: "",
      dueDate: "",
      team: 3,
      tasks: 0,
      progress: 0,
      image: "/placeholder.svg?height=200&width=300",
    })
    setShowAddProjectDialog(false)
  }

  const handleDeleteProject = (projectId) => {
    setProjects(projects.filter((project) => project.id !== projectId))
  }

  const allProjects = projects
  const activeProjects = projects.filter((project) => project.status === "active")
  const completedProjects = projects.filter((project) => project.status === "completed")
  const archivedProjects = projects.filter((project) => project.status === "archived")

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Projects</h1>
        <Dialog open={showAddProjectDialog} onOpenChange={setShowAddProjectDialog}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" /> New Project
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Add New Project</DialogTitle>
              <DialogDescription>Create a new project for your portfolio.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="title" className="text-right">
                  Title
                </Label>
                <Input
                  id="title"
                  value={newProject.title}
                  onChange={(e) => setNewProject({ ...newProject, title: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="client" className="text-right">
                  Client
                </Label>
                <Input
                  id="client"
                  value={newProject.client}
                  onChange={(e) => setNewProject({ ...newProject, client: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="dueDate" className="text-right">
                  Due Date
                </Label>
                <Input
                  id="dueDate"
                  type="date"
                  value={newProject.dueDate}
                  onChange={(e) => setNewProject({ ...newProject, dueDate: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="team" className="text-right">
                  Team Size
                </Label>
                <Input
                  id="team"
                  type="number"
                  min="1"
                  max="20"
                  value={newProject.team}
                  onChange={(e) => setNewProject({ ...newProject, team: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="progress" className="text-right">
                  Progress
                </Label>
                <Input
                  id="progress"
                  type="number"
                  min="0"
                  max="100"
                  value={newProject.progress}
                  onChange={(e) => setNewProject({ ...newProject, progress: e.target.value })}
                  className="col-span-3"
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="submit" onClick={handleAddProject}>
                Add Project
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
      <Tabs defaultValue="all">
        <TabsList>
          <TabsTrigger value="all">All Projects</TabsTrigger>
          <TabsTrigger value="active">Active</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
          <TabsTrigger value="archived">Archived</TabsTrigger>
        </TabsList>
        <TabsContent value="all" className="mt-6">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {allProjects.map((project) => (
              <div key={project.id} className="relative group">
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-2 right-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity bg-background/80 hover:bg-background/90 hover:text-destructive"
                  onClick={() => handleDeleteProject(project.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
                <ProjectCard
                  title={project.title}
                  client={project.client}
                  progress={project.progress}
                  dueDate={project.dueDate}
                  team={project.team}
                  tasks={project.tasks}
                  image={project.image}
                />
              </div>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="active" className="mt-6">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {activeProjects.map((project) => (
              <div key={project.id} className="relative group">
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-2 right-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity bg-background/80 hover:bg-background/90 hover:text-destructive"
                  onClick={() => handleDeleteProject(project.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
                <ProjectCard
                  title={project.title}
                  client={project.client}
                  progress={project.progress}
                  dueDate={project.dueDate}
                  team={project.team}
                  tasks={project.tasks}
                  image={project.image}
                />
              </div>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="completed" className="mt-6">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {completedProjects.map((project) => (
              <div key={project.id} className="relative group">
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-2 right-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity bg-background/80 hover:bg-background/90 hover:text-destructive"
                  onClick={() => handleDeleteProject(project.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
                <ProjectCard
                  title={project.title}
                  client={project.client}
                  progress={project.progress}
                  dueDate={project.dueDate}
                  team={project.team}
                  tasks={project.tasks}
                  image={project.image}
                />
              </div>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="archived" className="mt-6">
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {archivedProjects.map((project) => (
              <div key={project.id} className="relative group">
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-2 right-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity bg-background/80 hover:bg-background/90 hover:text-destructive"
                  onClick={() => handleDeleteProject(project.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
                <ProjectCard
                  title={project.title}
                  client={project.client}
                  progress={project.progress}
                  dueDate={project.dueDate}
                  team={project.team}
                  tasks={project.tasks}
                  image={project.image}
                />
              </div>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

