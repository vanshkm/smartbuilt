"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useLanguage } from "@/contexts/language-context"

// Material prices in USD
const MATERIAL_PRICES = {
  concrete: 150,
  rebar: 1,
  bricks: 0.5,
  mortar: 10,
  lumber: 3,
  plywood: 25,
  shingles: 100,
  underlayment: 30,
}

interface MaterialEstimate {
  name: string
  quantity: string
  unit: string
  costUSD: number
  costINR: number
}

export default function MaterialEstimationPage() {
  // Client-side only state
  const [isClient, setIsClient] = useState(false)
  const [projectType, setProjectType] = useState("residential")
  const [totalArea, setTotalArea] = useState("")
  const [floors, setFloors] = useState("")
  const [length, setLength] = useState("")
  const [width, setWidth] = useState("")
  const [height, setHeight] = useState("")
  const [foundationType, setFoundationType] = useState("concrete-slab")
  const [wallType, setWallType] = useState("brick")
  const [roofType, setRoofType] = useState("gable")
  const [materials, setMaterials] = useState<MaterialEstimate[]>([])
  const [totalCostUSD, setTotalCostUSD] = useState(0)
  const [totalCostINR, setTotalCostINR] = useState(0)
  const { t } = useLanguage()

  // Interior section state
  const [flooringType, setFlooringType] = useState("hardwood")
  const [flooringArea, setFlooringArea] = useState("")
  const [ceilingHeight, setCeilingHeight] = useState("")
  const [wallFinish, setWallFinish] = useState("paint")
  const [cabinetType, setCabinetType] = useState("custom")
  const [countertopMaterial, setCountertopMaterial] = useState("granite")
  const [interiorMaterials, setInteriorMaterials] = useState<MaterialEstimate[]>([])
  const [interiorTotalCostUSD, setInteriorTotalCostUSD] = useState(0)
  const [interiorTotalCostINR, setInteriorTotalCostINR] = useState(0)

  // Landscape section state
  const [landscapeType, setLandscapeType] = useState("residential")
  const [landscapeArea, setLandscapeArea] = useState("")
  const [lawnPercentage, setLawnPercentage] = useState("")
  const [hardscapeType, setHardscapeType] = useState("pavers")
  const [irrigationSystem, setIrrigationSystem] = useState("sprinkler")
  const [plantingDensity, setPlantingDensity] = useState("medium")
  const [landscapeMaterials, setLandscapeMaterials] = useState<MaterialEstimate[]>([])
  const [landscapeTotalCostUSD, setLandscapeTotalCostUSD] = useState(0)
  const [landscapeTotalCostINR, setLandscapeTotalCostINR] = useState(0)

  // Exchange rate (1 USD to INR)
  const USD_TO_INR = 75

  // Set isClient to true when component mounts on client
  useEffect(() => {
    setIsClient(true)
  }, [])

  const calculateMaterials = () => {
    const area = Number.parseFloat(totalArea) || Number.parseFloat(length) * Number.parseFloat(width) || 0
    const numFloors = Number.parseInt(floors) || 1
    const buildingHeight = (Number.parseFloat(height) || 3) * numFloors

    const newMaterials: MaterialEstimate[] = []
    let newTotalCostUSD = 0

    // Foundation
    const foundationDepth = 0.5 // meters
    const foundationVolume = area * foundationDepth
    const concreteCost = foundationVolume * MATERIAL_PRICES.concrete
    newMaterials.push({
      name: "Foundation Concrete",
      quantity: foundationVolume.toFixed(2),
      unit: "cubic meters",
      costUSD: concreteCost,
      costINR: concreteCost * USD_TO_INR,
    })
    newTotalCostUSD += concreteCost

    // Walls
    const wallArea = ((Number.parseFloat(length) || 10) * 2 + (Number.parseFloat(width) || 10) * 2) * buildingHeight
    if (wallType === "brick") {
      const brickQuantity = wallArea * 60 // Assuming 60 bricks per square meter
      const brickCost = brickQuantity * MATERIAL_PRICES.bricks
      newMaterials.push({
        name: "Bricks",
        quantity: brickQuantity.toFixed(0),
        unit: "pieces",
        costUSD: brickCost,
        costINR: brickCost * USD_TO_INR,
      })
      newTotalCostUSD += brickCost

      const mortarQuantity = wallArea * 0.05 // Assuming 0.05 cubic meters of mortar per square meter of wall
      const mortarCost = mortarQuantity * MATERIAL_PRICES.mortar
      newMaterials.push({
        name: "Mortar",
        quantity: mortarQuantity.toFixed(2),
        unit: "cubic meters",
        costUSD: mortarCost,
        costINR: mortarCost * USD_TO_INR,
      })
      newTotalCostUSD += mortarCost
    } else if (wallType === "wood-frame") {
      const lumberQuantity = wallArea * 2 // Assuming 2 board feet per square foot of wall
      const lumberCost = lumberQuantity * MATERIAL_PRICES.lumber
      newMaterials.push({
        name: "Framing Lumber",
        quantity: lumberQuantity.toFixed(2),
        unit: "board feet",
        costUSD: lumberCost,
        costINR: lumberCost * USD_TO_INR,
      })
      newTotalCostUSD += lumberCost

      const plywoodQuantity = wallArea * 0.09 // Assuming 0.09 sheets per square meter of wall
      const plywoodCost = plywoodQuantity * MATERIAL_PRICES.plywood
      newMaterials.push({
        name: "Plywood Sheathing",
        quantity: plywoodQuantity.toFixed(2),
        unit: "sheets",
        costUSD: plywoodCost,
        costINR: plywoodCost * USD_TO_INR,
      })
      newTotalCostUSD += plywoodCost
    }

    // Roof
    if (roofType === "gable" || roofType === "hip") {
      const roofArea = area * 1.2 // Assuming 20% extra for roof pitch
      const shinglesQuantity = roofArea / 3 // Assuming 1 square of shingles covers 3 square meters
      const shinglesCost = shinglesQuantity * MATERIAL_PRICES.shingles
      newMaterials.push({
        name: "Asphalt Shingles",
        quantity: shinglesQuantity.toFixed(2),
        unit: "squares",
        costUSD: shinglesCost,
        costINR: shinglesCost * USD_TO_INR,
      })
      newTotalCostUSD += shinglesCost

      const underlaymentQuantity = roofArea / 10 // Assuming 1 roll covers 10 square meters
      const underlaymentCost = underlaymentQuantity * MATERIAL_PRICES.underlayment
      newMaterials.push({
        name: "Underlayment",
        quantity: underlaymentQuantity.toFixed(2),
        unit: "rolls",
        costUSD: underlaymentCost,
        costINR: underlaymentCost * USD_TO_INR,
      })
      newTotalCostUSD += underlaymentCost
    }

    setMaterials(newMaterials)
    setTotalCostUSD(newTotalCostUSD)
    setTotalCostINR(newTotalCostUSD * USD_TO_INR)
  }

  const calculateInteriorMaterials = () => {
    const area = Number.parseFloat(flooringArea) || 100
    const height = Number.parseFloat(ceilingHeight) || 3

    const newMaterials: MaterialEstimate[] = []
    let newTotalCostUSD = 0

    // Flooring calculation
    let flooringCostPerSqM = 0
    switch (flooringType) {
      case "hardwood":
        flooringCostPerSqM = 100
        break
      case "laminate":
        flooringCostPerSqM = 40
        break
      case "tile":
        flooringCostPerSqM = 60
        break
      case "carpet":
        flooringCostPerSqM = 30
        break
      case "vinyl":
        flooringCostPerSqM = 25
        break
      default:
        flooringCostPerSqM = 100
    }

    const flooringCost = area * flooringCostPerSqM
    newMaterials.push({
      name: `${flooringType.charAt(0).toUpperCase() + flooringType.slice(1)} Flooring`,
      quantity: area.toFixed(2),
      unit: "sq. meters",
      costUSD: flooringCost,
      costINR: flooringCost * USD_TO_INR,
    })
    newTotalCostUSD += flooringCost

    // Wall finish calculation
    const wallArea = Math.sqrt(area) * 4 * height // Approximate wall area
    let wallFinishCostPerSqM = 0
    let wallFinishUnit = ""

    switch (wallFinish) {
      case "paint":
        wallFinishCostPerSqM = 8
        wallFinishUnit = "gallons"
        break
      case "wallpaper":
        wallFinishCostPerSqM = 20
        wallFinishUnit = "rolls"
        break
      case "paneling":
        wallFinishCostPerSqM = 40
        wallFinishUnit = "panels"
        break
      case "tile":
        wallFinishCostPerSqM = 60
        wallFinishUnit = "sq. meters"
        break
      default:
        wallFinishCostPerSqM = 8
        wallFinishUnit = "gallons"
    }

    const wallFinishQuantity = wallArea / (wallFinish === "paint" ? 15 : 5) // Approximate coverage
    const wallFinishCost = wallFinishQuantity * wallFinishCostPerSqM * 100
    newMaterials.push({
      name: `Interior Wall ${wallFinish.charAt(0).toUpperCase() + wallFinish.slice(1)}`,
      quantity: wallFinishQuantity.toFixed(0),
      unit: wallFinishUnit,
      costUSD: wallFinishCost,
      costINR: wallFinishCost * USD_TO_INR,
    })
    newTotalCostUSD += wallFinishCost

    // Cabinet calculation
    const cabinetLength = Math.sqrt(area) * 0.5 // Approximate cabinet length
    let cabinetCostPerMeter = 0

    switch (cabinetType) {
      case "custom":
        cabinetCostPerMeter = 500
        break
      case "stock":
        cabinetCostPerMeter = 300
        break
      case "semi-custom":
        cabinetCostPerMeter = 400
        break
      default:
        cabinetCostPerMeter = 500
    }

    const cabinetCost = cabinetLength * cabinetCostPerMeter * 10
    newMaterials.push({
      name: `${cabinetType.charAt(0).toUpperCase() + cabinetType.slice(1)} Cabinets`,
      quantity: cabinetLength.toFixed(1),
      unit: "linear meters",
      costUSD: cabinetCost,
      costINR: cabinetCost * USD_TO_INR,
    })
    newTotalCostUSD += cabinetCost

    // Countertop calculation
    const countertopArea = cabinetLength * 0.6 // Approximate countertop area
    let countertopCostPerSqM = 0

    switch (countertopMaterial) {
      case "granite":
        countertopCostPerSqM = 500
        break
      case "quartz":
        countertopCostPerSqM = 550
        break
      case "marble":
        countertopCostPerSqM = 600
        break
      case "laminate":
        countertopCostPerSqM = 150
        break
      case "butcher-block":
        countertopCostPerSqM = 300
        break
      default:
        countertopCostPerSqM = 500
    }

    const countertopCost = countertopArea * countertopCostPerSqM * 10
    newMaterials.push({
      name: `${countertopMaterial.charAt(0).toUpperCase() + countertopMaterial.slice(1)} Countertops`,
      quantity: countertopArea.toFixed(1),
      unit: "sq. meters",
      costUSD: countertopCost,
      costINR: countertopCost * USD_TO_INR,
    })
    newTotalCostUSD += countertopCost

    setInteriorMaterials(newMaterials)
    setInteriorTotalCostUSD(newTotalCostUSD)
    setInteriorTotalCostINR(newTotalCostUSD * USD_TO_INR)
  }

  const calculateLandscapeMaterials = () => {
    const area = Number.parseFloat(landscapeArea) || 500
    const lawnPercent = Number.parseFloat(lawnPercentage) || 60

    const newMaterials: MaterialEstimate[] = []
    let newTotalCostUSD = 0

    // Lawn calculation
    const lawnArea = area * (lawnPercent / 100)
    const lawnCost = lawnArea * 10
    newMaterials.push({
      name: "Lawn Sod",
      quantity: lawnArea.toFixed(0),
      unit: "sq. meters",
      costUSD: lawnCost,
      costINR: lawnCost * USD_TO_INR,
    })
    newTotalCostUSD += lawnCost

    // Hardscape calculation
    const hardscapeArea = area * ((100 - lawnPercent) / 100) * 0.7 // Assuming 70% of non-lawn is hardscape
    let hardscapeCostPerSqM = 0

    switch (hardscapeType) {
      case "pavers":
        hardscapeCostPerSqM = 40
        break
      case "natural-stone":
        hardscapeCostPerSqM = 80
        break
      case "gravel":
        hardscapeCostPerSqM = 15
        break
      case "brick":
        hardscapeCostPerSqM = 35
        break
      case "wood":
        hardscapeCostPerSqM = 60
        break
      default:
        hardscapeCostPerSqM = 40
    }

    const hardscapeCost = hardscapeArea * hardscapeCostPerSqM * 10
    newMaterials.push({
      name:
        hardscapeType === "natural-stone"
          ? "Natural Stone"
          : hardscapeType === "wood"
            ? "Wood Decking"
            : `${hardscapeType.charAt(0).toUpperCase() + hardscapeType.slice(1)}`,
      quantity: hardscapeArea.toFixed(0),
      unit: "sq. meters",
      costUSD: hardscapeCost,
      costINR: hardscapeCost * USD_TO_INR,
    })
    newTotalCostUSD += hardscapeCost

    // Irrigation calculation
    if (irrigationSystem !== "none") {
      let irrigationCostPerSqM = 0

      switch (irrigationSystem) {
        case "sprinkler":
          irrigationCostPerSqM = 5
          break
        case "drip":
          irrigationCostPerSqM = 7
          break
        case "manual":
          irrigationCostPerSqM = 1
          break
        default:
          irrigationCostPerSqM = 5
      }

      const irrigationCost = area * irrigationCostPerSqM * 10
      newMaterials.push({
        name: `${irrigationSystem.charAt(0).toUpperCase() + irrigationSystem.slice(1)} System`,
        quantity: area.toFixed(0),
        unit: "sq. meters coverage",
        costUSD: irrigationCost,
        costINR: irrigationCost * USD_TO_INR,
      })
      newTotalCostUSD += irrigationCost
    }

    // Plants calculation
    let plantDensityFactor = 0

    switch (plantingDensity) {
      case "low":
        plantDensityFactor = 2
        break
      case "medium":
        plantDensityFactor = 4
        break
      case "high":
        plantDensityFactor = 8
        break
      default:
        plantDensityFactor = 4
    }

    const plantArea = area * ((100 - lawnPercent) / 100) * 0.3 // Assuming 30% of non-lawn is planting
    const plantCost = plantArea * plantDensityFactor * 10
    newMaterials.push({
      name: "Plants and Shrubs",
      quantity: plantingDensity,
      unit: "density",
      costUSD: plantCost,
      costINR: plantCost * USD_TO_INR,
    })
    newTotalCostUSD += plantCost

    setLandscapeMaterials(newMaterials)
    setLandscapeTotalCostUSD(newTotalCostUSD)
    setLandscapeTotalCostINR(newTotalCostUSD * USD_TO_INR)
  }

  // Only render the full component on the client side
  if (!isClient) {
    return (
      <div className="flex flex-col gap-6">
        <h1 className="text-3xl font-bold">{t("materialEstimation")}</h1>
        <p>Loading material estimation tool...</p>
      </div>
    )
  }

  return (
    <div className="flex flex-col gap-6">
      <h1 className="text-3xl font-bold">{t("materialEstimation")}</h1>
      <Tabs defaultValue="building" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="building">Building</TabsTrigger>
          <TabsTrigger value="interior">Interior</TabsTrigger>
          <TabsTrigger value="landscape">Landscape</TabsTrigger>
        </TabsList>
        <TabsContent value="building" className="mt-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>{t("buildingSpecifications")}</CardTitle>
                <CardDescription>{t("enterDimensions")}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="project-type">{t("projectType")}</Label>
                  <Select value={projectType} onValueChange={setProjectType}>
                    <SelectTrigger id="project-type">
                      <SelectValue placeholder="Select project type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="residential">Residential</SelectItem>
                      <SelectItem value="commercial">Commercial</SelectItem>
                      <SelectItem value="industrial">Industrial</SelectItem>
                      <SelectItem value="institutional">Institutional</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="total-area">{t("totalArea")}</Label>
                    <Input
                      id="total-area"
                      type="number"
                      placeholder="e.g. 250"
                      value={totalArea}
                      onChange={(e) => setTotalArea(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="floors">{t("floors")}</Label>
                    <Input
                      id="floors"
                      type="number"
                      placeholder="e.g. 2"
                      value={floors}
                      onChange={(e) => setFloors(e.target.value)}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="length">{t("length")}</Label>
                    <Input
                      id="length"
                      type="number"
                      placeholder="e.g. 15"
                      value={length}
                      onChange={(e) => setLength(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="width">{t("width")}</Label>
                    <Input
                      id="width"
                      type="number"
                      placeholder="e.g. 10"
                      value={width}
                      onChange={(e) => setWidth(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="height">{t("height")}</Label>
                    <Input
                      id="height"
                      type="number"
                      placeholder="e.g. 3"
                      value={height}
                      onChange={(e) => setHeight(e.target.value)}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="foundation-type">{t("foundationType")}</Label>
                  <Select value={foundationType} onValueChange={setFoundationType}>
                    <SelectTrigger id="foundation-type">
                      <SelectValue placeholder="Select foundation type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="concrete-slab">Concrete Slab</SelectItem>
                      <SelectItem value="crawl-space">Crawl Space</SelectItem>
                      <SelectItem value="basement">Full Basement</SelectItem>
                      <SelectItem value="pier-beam">Pier and Beam</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="wall-type">{t("wallConstruction")}</Label>
                  <Select value={wallType} onValueChange={setWallType}>
                    <SelectTrigger id="wall-type">
                      <SelectValue placeholder="Select wall type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="brick">Brick</SelectItem>
                      <SelectItem value="concrete">Concrete</SelectItem>
                      <SelectItem value="wood-frame">Wood Frame</SelectItem>
                      <SelectItem value="steel-frame">Steel Frame</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="roof-type">{t("roofType")}</Label>
                  <Select value={roofType} onValueChange={setRoofType}>
                    <SelectTrigger id="roof-type">
                      <SelectValue placeholder="Select roof type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="gable">Gable</SelectItem>
                      <SelectItem value="hip">Hip</SelectItem>
                      <SelectItem value="flat">Flat</SelectItem>
                      <SelectItem value="shed">Shed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button className="w-full" onClick={calculateMaterials}>
                  {t("calculateMaterials")}
                </Button>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>{t("estimatedMaterials")}</CardTitle>
                <CardDescription>Based on your specifications, here are the estimated materials needed</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {materials.map((material, index) => (
                    <div key={index} className="flex justify-between items-center">
                      <div>
                        <div className="font-medium">{material.name}</div>
                        <div className="text-sm text-muted-foreground">
                          {material.quantity} {material.unit}
                        </div>
                      </div>
                      <div className="text-right">
                        <div>₹{material.costINR.toFixed(2)}</div>
                        <div className="text-sm text-muted-foreground">${material.costUSD.toFixed(2)}</div>
                      </div>
                    </div>
                  ))}
                  {materials.length > 0 && (
                    <div className="pt-4 border-t">
                      <div className="flex justify-between items-center font-bold">
                        <div>{t("totalEstimatedCost")}</div>
                        <div className="text-right">
                          <div>₹{totalCostINR.toFixed(2)}</div>
                          <div className="text-sm text-muted-foreground">${totalCostUSD.toFixed(2)}</div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
                {materials.length === 0 && (
                  <div className="text-center text-muted-foreground">
                    Enter building specifications and click "Calculate Materials" to see estimates.
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="interior" className="mt-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>{t("interiorSpecifications")}</CardTitle>
                <CardDescription>{t("enterInteriorDetails")}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="flooring-type">{t("flooringType")}</Label>
                  <Select value={flooringType} onValueChange={setFlooringType}>
                    <SelectTrigger id="flooring-type">
                      <SelectValue placeholder="Select flooring type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="hardwood">Hardwood</SelectItem>
                      <SelectItem value="laminate">Laminate</SelectItem>
                      <SelectItem value="tile">Tile</SelectItem>
                      <SelectItem value="carpet">Carpet</SelectItem>
                      <SelectItem value="vinyl">Vinyl</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="flooring-area">{t("flooringArea")}</Label>
                    <Input
                      id="flooring-area"
                      type="number"
                      placeholder="e.g. 100"
                      value={flooringArea}
                      onChange={(e) => setFlooringArea(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="ceiling-height">{t("ceilingHeight")}</Label>
                    <Input
                      id="ceiling-height"
                      type="number"
                      placeholder="e.g. 3"
                      value={ceilingHeight}
                      onChange={(e) => setCeilingHeight(e.target.value)}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="wall-finish">{t("wallFinish")}</Label>
                  <Select value={wallFinish} onValueChange={setWallFinish}>
                    <SelectTrigger id="wall-finish">
                      <SelectValue placeholder="Select wall finish" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="paint">Paint</SelectItem>
                      <SelectItem value="wallpaper">Wallpaper</SelectItem>
                      <SelectItem value="paneling">Wood Paneling</SelectItem>
                      <SelectItem value="tile">Tile</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cabinet-type">{t("cabinetType")}</Label>
                  <Select value={cabinetType} onValueChange={setCabinetType}>
                    <SelectTrigger id="cabinet-type">
                      <SelectValue placeholder="Select cabinet type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="custom">Custom Built</SelectItem>
                      <SelectItem value="stock">Stock Cabinets</SelectItem>
                      <SelectItem value="semi-custom">Semi-Custom</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="countertop">{t("countertopMaterial")}</Label>
                  <Select value={countertopMaterial} onValueChange={setCountertopMaterial}>
                    <SelectTrigger id="countertop">
                      <SelectValue placeholder="Select countertop material" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="granite">Granite</SelectItem>
                      <SelectItem value="quartz">Quartz</SelectItem>
                      <SelectItem value="marble">Marble</SelectItem>
                      <SelectItem value="laminate">Laminate</SelectItem>
                      <SelectItem value="butcher-block">Butcher Block</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button className="w-full" onClick={calculateInteriorMaterials}>
                  {t("calculateMaterials")}
                </Button>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>{t("estimatedInteriorMaterials")}</CardTitle>
                <CardDescription>Based on your specifications, here are the estimated materials needed</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {interiorMaterials.map((material, index) => (
                    <div key={index} className="flex justify-between items-center">
                      <div>
                        <div className="font-medium">{material.name}</div>
                        <div className="text-sm text-muted-foreground">
                          {material.quantity} {material.unit}
                        </div>
                      </div>
                      <div className="text-right">
                        <div>₹{material.costINR.toFixed(2)}</div>
                        <div className="text-sm text-muted-foreground">${material.costUSD.toFixed(2)}</div>
                      </div>
                    </div>
                  ))}
                  {interiorMaterials.length > 0 && (
                    <div className="pt-4 border-t">
                      <div className="flex justify-between items-center font-bold">
                        <div>{t("totalEstimatedCost")}</div>
                        <div className="text-right">
                          <div>₹{interiorTotalCostINR.toFixed(2)}</div>
                          <div className="text-sm text-muted-foreground">${interiorTotalCostUSD.toFixed(2)}</div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        <TabsContent value="landscape" className="mt-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>{t("landscapeSpecifications")}</CardTitle>
                <CardDescription>{t("enterLandscapeDetails")}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="landscape-type">{t("landscapeType")}</Label>
                  <Select value={landscapeType} onValueChange={setLandscapeType}>
                    <SelectTrigger id="landscape-type">
                      <SelectValue placeholder="Select landscape type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="residential">Residential</SelectItem>
                      <SelectItem value="commercial">Commercial</SelectItem>
                      <SelectItem value="public">Public Space</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="total-area-landscape">{t("totalArea")}</Label>
                    <Input
                      id="total-area-landscape"
                      type="number"
                      placeholder="e.g. 500"
                      value={landscapeArea}
                      onChange={(e) => setLandscapeArea(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lawn-percentage">{t("lawnPercentage")}</Label>
                    <Input
                      id="lawn-percentage"
                      type="number"
                      placeholder="e.g. 60"
                      value={lawnPercentage}
                      onChange={(e) => setLawnPercentage(e.target.value)}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="hardscape-type">{t("hardscapeType")}</Label>
                  <Select value={hardscapeType} onValueChange={setHardscapeType}>
                    <SelectTrigger id="hardscape-type">
                      <SelectValue placeholder="Select hardscape type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pavers">Concrete Pavers</SelectItem>
                      <SelectItem value="natural-stone">Natural Stone</SelectItem>
                      <SelectItem value="gravel">Gravel</SelectItem>
                      <SelectItem value="brick">Brick</SelectItem>
                      <SelectItem value="wood">Wood Decking</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="irrigation-system">{t("irrigationSystem")}</Label>
                  <Select value={irrigationSystem} onValueChange={setIrrigationSystem}>
                    <SelectTrigger id="irrigation-system">
                      <SelectValue placeholder="Select irrigation system" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sprinkler">Sprinkler System</SelectItem>
                      <SelectItem value="drip">Drip Irrigation</SelectItem>
                      <SelectItem value="manual">Manual Watering</SelectItem>
                      <SelectItem value="none">None</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="planting-density">{t("plantingDensity")}</Label>
                  <Select value={plantingDensity} onValueChange={setPlantingDensity}>
                    <SelectTrigger id="planting-density">
                      <SelectValue placeholder="Select planting density" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="low">Low (Minimal Plants)</SelectItem>
                      <SelectItem value="medium">Medium (Balanced)</SelectItem>
                      <SelectItem value="high">High (Lush Garden)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button className="w-full" onClick={calculateLandscapeMaterials}>
                  {t("calculateMaterials")}
                </Button>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>{t("estimatedLandscapeMaterials")}</CardTitle>
                <CardDescription>Based on your specifications, here are the estimated materials needed</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {landscapeMaterials.map((material, index) => (
                    <div key={index} className="flex justify-between items-center">
                      <div>
                        <div className="font-medium">{material.name}</div>
                        <div className="text-sm text-muted-foreground">
                          {material.quantity} {material.unit}
                        </div>
                      </div>
                      <div className="text-right">
                        <div>₹{material.costINR.toFixed(2)}</div>
                        <div className="text-sm text-muted-foreground">${material.costUSD.toFixed(2)}</div>
                      </div>
                    </div>
                  ))}
                  {landscapeMaterials.length > 0 && (
                    <div className="pt-4 border-t">
                      <div className="flex justify-between items-center font-bold">
                        <div>{t("totalEstimatedCost")}</div>
                        <div className="text-right">
                          <div>₹{landscapeTotalCostINR.toFixed(2)}</div>
                          <div className="text-sm text-muted-foreground">${landscapeTotalCostUSD.toFixed(2)}</div>
                        </div>
                      </div>
                    </div>
                  )}
                  {landscapeMaterials.length === 0 && (
                    <div className="text-center text-muted-foreground">
                      Enter landscape specifications and click "Calculate Materials" to see estimates.
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

