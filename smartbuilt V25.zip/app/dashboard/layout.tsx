"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import type React from "react"
import { Sidebar } from "@/components/dashboard/sidebar"
import { DashboardHeader } from "@/components/dashboard/header"

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const router = useRouter()

  useEffect(() => {
    // Check if user is logged in and is an architect
    const isLoggedIn = localStorage.getItem("isLoggedIn") === "true"
    const userRole = localStorage.getItem("userRole")

    if (!isLoggedIn) {
      router.push("/login")
    } else if (userRole !== "architect") {
      // Redirect to appropriate dashboard based on role
      if (userRole === "contractor") {
        router.push("/contractor-dashboard")
      } else if (userRole === "client") {
        router.push("/client-dashboard")
      } else {
        router.push("/login")
      }
    }
  }, [router])

  return (
    <div className="flex min-h-screen flex-col architect-theme">
      <DashboardHeader />
      <div className="flex flex-1">
        <Sidebar />
        <main className="flex-1 p-6">{children}</main>
      </div>
    </div>
  )
}

