"use client"

import { useState } from "react"
import dayjs from "dayjs"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CalendarIcon, Clock, MapPin, Plus, User } from "lucide-react"
import { Badge } from "@/components/ui/badge"

export default function CalendarPage() {
  const [currentDate, setCurrentDate] = useState(dayjs())
  const [selectedDate, setSelectedDate] = useState(dayjs())
  const [view, setView] = useState("month")

  const startOfMonth = currentDate.startOf("month")
  const endOfMonth = currentDate.endOf("month")
  const startDay = startOfMonth.day()
  const daysInMonth = currentDate.daysInMonth()
  const days = Array.from({ length: daysInMonth }, (_, i) => startOfMonth.add(i, "day"))

  const prevMonth = () => setCurrentDate(currentDate.subtract(1, "month"))
  const nextMonth = () => setCurrentDate(currentDate.add(1, "month"))
  const today = () => {
    setCurrentDate(dayjs())
    setSelectedDate(dayjs())
  }

  // Sample events data
  const events = [
    {
      id: 1,
      title: "Client Meeting: Metro Business Solutions",
      date: dayjs().format("YYYY-MM-DD"),
      time: "10:00 AM - 11:30 AM",
      location: "Conference Room A",
      attendees: ["Priya Sharma", "Vikram Mehta", "Client Team"],
      type: "meeting",
    },
    {
      id: 2,
      title: "Site Visit: Modern Residential Complex",
      date: dayjs().format("YYYY-MM-DD"),
      time: "2:00 PM - 4:00 PM",
      location: "Construction Site, North Sector",
      attendees: ["Arjun Patel", "Neha Gupta", "Ravi Kapoor"],
      type: "site-visit",
    },
    {
      id: 3,
      title: "Team Sync-up",
      date: dayjs().add(1, "day").format("YYYY-MM-DD"),
      time: "9:30 AM - 10:30 AM",
      location: "Virtual Meeting",
      attendees: ["All Team Members"],
      type: "internal",
    },
    {
      id: 4,
      title: "Design Review: Luxury Hotel Complex",
      date: dayjs().add(2, "day").format("YYYY-MM-DD"),
      time: "11:00 AM - 1:00 PM",
      location: "Design Studio",
      attendees: ["Vikram Mehta", "Ananya Desai", "Raj Singh"],
      type: "review",
    },
    {
      id: 5,
      title: "Permit Application Deadline",
      date: dayjs().add(5, "day").format("YYYY-MM-DD"),
      time: "All Day",
      location: "N/A",
      attendees: ["Priya Sharma"],
      type: "deadline",
    },
  ]

  // Get events for selected date
  const selectedDateEvents = events.filter((event) => event.date === selectedDate.format("YYYY-MM-DD"))

  // Check if a day has events
  const hasEvents = (day) => {
    return events.some((event) => event.date === day.format("YYYY-MM-DD"))
  }

  // Get event type color
  const getEventTypeColor = (type) => {
    switch (type) {
      case "meeting":
        return "bg-blue-500"
      case "site-visit":
        return "bg-green-500"
      case "internal":
        return "bg-purple-500"
      case "review":
        return "bg-amber-500"
      case "deadline":
        return "bg-red-500"
      default:
        return "bg-gray-500"
    }
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Calendar</h1>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={today}>
            Today
          </Button>
          <Button>
            <Plus className="mr-2 h-4 w-4" /> Add Event
          </Button>
        </div>
      </div>

      <Tabs defaultValue="month" onValueChange={setView}>
        <div className="flex items-center justify-between mb-4">
          <TabsList>
            <TabsTrigger value="month">Month</TabsTrigger>
            <TabsTrigger value="week">Week</TabsTrigger>
            <TabsTrigger value="day">Day</TabsTrigger>
          </TabsList>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="icon" onClick={prevMonth}>
              <span className="sr-only">Previous month</span>
              &lt;
            </Button>
            <h2 className="text-lg font-semibold">{currentDate.format("MMMM YYYY")}</h2>
            <Button variant="outline" size="icon" onClick={nextMonth}>
              <span className="sr-only">Next month</span>
              &gt;
            </Button>
          </div>
        </div>

        <TabsContent value="month" className="mt-0">
          <div className="grid grid-cols-7 gap-1 text-center mb-2">
            {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
              <div key={day} className="font-medium text-sm py-2">
                {day}
              </div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-1 text-center">
            {Array.from({ length: startDay }).map((_, i) => (
              <div key={`empty-${i}`} className="h-24 p-1 border rounded-md opacity-50 bg-muted/30"></div>
            ))}
            {days.map((day) => {
              const isToday = day.format("YYYY-MM-DD") === dayjs().format("YYYY-MM-DD")
              const isSelected = day.format("YYYY-MM-DD") === selectedDate.format("YYYY-MM-DD")
              const dayHasEvents = hasEvents(day)

              return (
                <div
                  key={day.format("DD-MM-YYYY")}
                  className={`h-24 p-1 border rounded-md hover:bg-muted/50 cursor-pointer transition-colors relative ${
                    isToday ? "border-primary" : ""
                  } ${isSelected ? "bg-muted" : ""}`}
                  onClick={() => setSelectedDate(day)}
                >
                  <div className={`text-right mb-1 ${isToday ? "font-bold text-primary" : ""}`}>{day.format("D")}</div>
                  {dayHasEvents && (
                    <div className="absolute bottom-1 left-0 right-0 flex justify-center">
                      <div className="h-1.5 w-1.5 rounded-full bg-primary"></div>
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </TabsContent>

        <TabsContent value="week" className="mt-0">
          <div className="text-center p-8 border rounded-md">
            <h3 className="text-lg font-medium">Week View</h3>
            <p className="text-muted-foreground">Week view is coming soon.</p>
          </div>
        </TabsContent>

        <TabsContent value="day" className="mt-0">
          <div className="text-center p-8 border rounded-md">
            <h3 className="text-lg font-medium">Day View</h3>
            <p className="text-muted-foreground">Day view is coming soon.</p>
          </div>
        </TabsContent>
      </Tabs>

      <div className="grid gap-6 md:grid-cols-[2fr_1fr]">
        <Card>
          <CardHeader>
            <CardTitle>Events for {selectedDate.format("MMMM D, YYYY")}</CardTitle>
            <CardDescription>
              {selectedDateEvents.length === 0
                ? "No events scheduled for this day."
                : `${selectedDateEvents.length} event${selectedDateEvents.length > 1 ? "s" : ""} scheduled.`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {selectedDateEvents.map((event) => (
                <div key={event.id} className="border rounded-md p-4 hover:bg-muted/50 transition-colors">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-medium">{event.title}</h3>
                      <div className="flex flex-wrap gap-4 mt-2 text-sm text-muted-foreground">
                        <div className="flex items-center">
                          <Clock className="mr-1 h-4 w-4" />
                          {event.time}
                        </div>
                        <div className="flex items-center">
                          <MapPin className="mr-1 h-4 w-4" />
                          {event.location}
                        </div>
                      </div>
                      <div className="flex items-center mt-2">
                        <User className="mr-1 h-4 w-4 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">{event.attendees.join(", ")}</span>
                      </div>
                    </div>
                    <Badge className={`${getEventTypeColor(event.type)} text-white`}>
                      {event.type.charAt(0).toUpperCase() + event.type.slice(1)}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Add</CardTitle>
            <CardDescription>Quickly add a new event to your calendar</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <CalendarIcon className="h-4 w-4 text-muted-foreground" />
                <div className="col-span-3 font-medium">{selectedDate.format("MMMM D, YYYY")}</div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Event Title</label>
                <input type="text" placeholder="Enter event title" className="w-full p-2 border rounded-md" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">Time</label>
                <div className="flex gap-2">
                  <input type="time" className="flex-1 p-2 border rounded-md" />
                  <span className="flex items-center">to</span>
                  <input type="time" className="flex-1 p-2 border rounded-md" />
                </div>
              </div>
              <Button className="w-full">Add Event</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

