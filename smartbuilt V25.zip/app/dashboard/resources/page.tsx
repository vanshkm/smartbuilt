"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Download, ExternalLink, FileText, Filter, Plus, Search, Star, Trash2 } from "lucide-react"
import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function ResourcesPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [showAddResourceDialog, setShowAddResourceDialog] = useState(false)
  const [resourceType, setResourceType] = useState("material")
  const [showDetailsDialog, setShowDetailsDialog] = useState(false)
  const [selectedResource, setSelectedResource] = useState(null)

  const [newMaterial, setNewMaterial] = useState({
    name: "",
    supplier: "",
    category: "",
    price: "",
    availability: "In Stock",
    rating: 4.5,
  })

  const [newDocument, setNewDocument] = useState({
    title: "",
    type: "PDF",
    size: "",
    category: "",
    tags: "",
  })

  const [materials, setMaterials] = useState([
    {
      id: 1,
      name: "Premium Hardwood Flooring",
      supplier: "Woodland Materials",
      category: "Flooring",
      price: "$8.50 per sq ft",
      priceINR: "₹637.50 per sq ft",
      availability: "In Stock",
      rating: 4.8,
      image: "/placeholder.svg?height=100&width=200",
      description:
        "High-quality hardwood flooring made from sustainable sources. Perfect for luxury residential and commercial projects.",
    },
    {
      id: 2,
      name: "Architectural Glass Panels",
      supplier: "GlassMasters Inc.",
      category: "Glass",
      price: "$45.00 per sq ft",
      priceINR: "₹3,375.00 per sq ft",
      availability: "2 Week Lead Time",
      rating: 4.5,
      image: "/placeholder.svg?height=100&width=200",
      description:
        "Premium architectural glass panels with excellent thermal and acoustic properties. Available in various tints and finishes.",
    },
    {
      id: 3,
      name: "Eco-Friendly Insulation",
      supplier: "GreenBuild Supplies",
      category: "Insulation",
      price: "$1.25 per sq ft",
      priceINR: "₹93.75 per sq ft",
      availability: "In Stock",
      rating: 4.7,
      image: "/placeholder.svg?height=100&width=200",
      description:
        "Environmentally friendly insulation material made from recycled content. Provides excellent thermal performance.",
    },
    {
      id: 4,
      name: "Decorative Concrete Tiles",
      supplier: "Modern Surfaces",
      category: "Tiles",
      price: "$12.75 per sq ft",
      priceINR: "₹956.25 per sq ft",
      availability: "In Stock",
      rating: 4.6,
      image: "/placeholder.svg?height=100&width=200",
      description:
        "Designer concrete tiles available in various patterns and colors. Suitable for both interior and exterior applications.",
    },
    {
      id: 5,
      name: "Sustainable Bamboo Panels",
      supplier: "EcoDesign Materials",
      category: "Panels",
      price: "$22.50 per panel",
      priceINR: "₹1,687.50 per panel",
      availability: "1 Week Lead Time",
      rating: 4.9,
      image: "/placeholder.svg?height=100&width=200",
      description:
        "Sustainable bamboo panels for walls and ceilings. Rapid-renewable resource with excellent durability.",
    },
    {
      id: 6,
      name: "Premium Marble Countertops",
      supplier: "Luxury Stone Works",
      category: "Countertops",
      price: "$75.00 per sq ft",
      priceINR: "₹5,625.00 per sq ft",
      availability: "3 Week Lead Time",
      rating: 4.8,
      image: "/placeholder.svg?height=100&width=200",
      description:
        "Luxury marble countertops sourced from the finest quarries. Available in various colors and finishes.",
    },
  ])

  const [documents, setDocuments] = useState([
    {
      id: 1,
      title: "Building Code Reference Guide",
      type: "PDF",
      size: "4.2 MB",
      lastUpdated: "2024-02-15",
      category: "Reference",
      tags: ["Building Codes", "Regulations", "Standards"],
      description: "Comprehensive guide to building codes and regulations for residential and commercial construction.",
      downloadUrl: "#",
    },
    {
      id: 2,
      title: "Sustainable Design Best Practices",
      type: "PDF",
      size: "3.8 MB",
      lastUpdated: "2024-01-20",
      category: "Guide",
      tags: ["Sustainability", "Green Building", "LEED"],
      description: "Best practices for sustainable design and green building certification processes.",
      downloadUrl: "#",
    },
    {
      id: 3,
      title: "Material Specification Templates",
      type: "DOCX",
      size: "1.5 MB",
      lastUpdated: "2024-02-28",
      category: "Template",
      tags: ["Specifications", "Materials", "Documentation"],
      description: "Templates for creating detailed material specifications for architectural projects.",
      downloadUrl: "#",
    },
    {
      id: 4,
      title: "Project Management Handbook",
      type: "PDF",
      size: "5.7 MB",
      lastUpdated: "2023-11-10",
      category: "Handbook",
      tags: ["Project Management", "Workflows", "Best Practices"],
      description: "Comprehensive handbook for managing architectural projects from concept to completion.",
      downloadUrl: "#",
    },
    {
      id: 5,
      title: "CAD Standards Guide",
      type: "PDF",
      size: "2.9 MB",
      lastUpdated: "2024-01-05",
      category: "Guide",
      tags: ["CAD", "Standards", "Drawing"],
      description: "Standards and best practices for CAD drawing and documentation.",
      downloadUrl: "#",
    },
    {
      id: 6,
      title: "Client Presentation Templates",
      type: "PPTX",
      size: "8.3 MB",
      lastUpdated: "2024-03-01",
      category: "Template",
      tags: ["Presentations", "Client", "Marketing"],
      description: "Professional templates for client presentations and project proposals.",
      downloadUrl: "#",
    },
  ])

  const handleAddResource = () => {
    if (resourceType === "material") {
      if (!newMaterial.name || !newMaterial.supplier || !newMaterial.category || !newMaterial.price) return

      // Convert price to INR (assuming 1 USD = 75 INR)
      const priceValue = Number.parseFloat(newMaterial.price.replace(/[^0-9.]/g, ""))
      const priceINR = isNaN(priceValue) ? "₹0.00" : `₹${(priceValue * 75).toFixed(2)}`

      const newMaterialItem = {
        id: materials.length + 1,
        name: newMaterial.name,
        supplier: newMaterial.supplier,
        category: newMaterial.category,
        price: `$${priceValue.toFixed(2)} per unit`,
        priceINR: `${priceINR} per unit`,
        availability: newMaterial.availability,
        rating: Number.parseFloat(newMaterial.rating) || 4.5,
        image: "/placeholder.svg?height=100&width=200",
        description: "New material added to the resource library.",
      }

      setMaterials([...materials, newMaterialItem])

      // Reset form
      setNewMaterial({
        name: "",
        supplier: "",
        category: "",
        price: "",
        availability: "In Stock",
        rating: 4.5,
      })
    } else {
      if (!newDocument.title || !newDocument.category) return

      const tagsArray = newDocument.tags
        .split(",")
        .map((tag) => tag.trim())
        .filter((tag) => tag)

      const newDocumentItem = {
        id: documents.length + 1,
        title: newDocument.title,
        type: newDocument.type,
        size: newDocument.size || "1.0 MB",
        lastUpdated: new Date().toISOString().split("T")[0],
        category: newDocument.category,
        tags: tagsArray.length > 0 ? tagsArray : ["Documentation"],
        description: "New document added to the resource library.",
        downloadUrl: "#",
      }

      setDocuments([...documents, newDocumentItem])

      // Reset form
      setNewDocument({
        title: "",
        type: "PDF",
        size: "",
        category: "",
        tags: "",
      })
    }

    setShowAddResourceDialog(false)
  }

  const handleDeleteResource = (id, type) => {
    if (type === "material") {
      setMaterials(materials.filter((material) => material.id !== id))
    } else {
      setDocuments(documents.filter((document) => document.id !== id))
    }
  }

  const handleViewDetails = (resource, type) => {
    setSelectedResource({ ...resource, type })
    setShowDetailsDialog(true)
  }

  const filteredMaterials = materials.filter(
    (material) =>
      material.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      material.supplier.toLowerCase().includes(searchQuery.toLowerCase()) ||
      material.category.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const filteredDocuments = documents.filter(
    (document) =>
      document.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      document.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      document.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase())),
  )

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Resources</h1>
        <div className="flex items-center gap-2">
          <Button variant="outline">
            <Filter className="mr-2 h-4 w-4" /> Filter
          </Button>
          <Dialog open={showAddResourceDialog} onOpenChange={setShowAddResourceDialog}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" /> Add Resource
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle>Add New Resource</DialogTitle>
                <DialogDescription>Add a new material or document to your resource library.</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <Label htmlFor="resource-type" className="text-right">
                    Type
                  </Label>
                  <Select value={resourceType} onValueChange={setResourceType}>
                    <SelectTrigger className="col-span-3">
                      <SelectValue placeholder="Select resource type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="material">Material</SelectItem>
                      <SelectItem value="document">Document</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {resourceType === "material" ? (
                  <>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="name" className="text-right">
                        Name
                      </Label>
                      <Input
                        id="name"
                        value={newMaterial.name}
                        onChange={(e) => setNewMaterial({ ...newMaterial, name: e.target.value })}
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="supplier" className="text-right">
                        Supplier
                      </Label>
                      <Input
                        id="supplier"
                        value={newMaterial.supplier}
                        onChange={(e) => setNewMaterial({ ...newMaterial, supplier: e.target.value })}
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="category" className="text-right">
                        Category
                      </Label>
                      <Input
                        id="category"
                        value={newMaterial.category}
                        onChange={(e) => setNewMaterial({ ...newMaterial, category: e.target.value })}
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="price" className="text-right">
                        Price (USD)
                      </Label>
                      <Input
                        id="price"
                        value={newMaterial.price}
                        onChange={(e) => setNewMaterial({ ...newMaterial, price: e.target.value })}
                        placeholder="e.g. 10.50"
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="availability" className="text-right">
                        Availability
                      </Label>
                      <Select
                        value={newMaterial.availability}
                        onValueChange={(value) => setNewMaterial({ ...newMaterial, availability: value })}
                      >
                        <SelectTrigger className="col-span-3">
                          <SelectValue placeholder="Select availability" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="In Stock">In Stock</SelectItem>
                          <SelectItem value="1 Week Lead Time">1 Week Lead Time</SelectItem>
                          <SelectItem value="2 Week Lead Time">2 Week Lead Time</SelectItem>
                          <SelectItem value="3 Week Lead Time">3 Week Lead Time</SelectItem>
                          <SelectItem value="Out of Stock">Out of Stock</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </>
                ) : (
                  <>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="title" className="text-right">
                        Title
                      </Label>
                      <Input
                        id="title"
                        value={newDocument.title}
                        onChange={(e) => setNewDocument({ ...newDocument, title: e.target.value })}
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="type" className="text-right">
                        File Type
                      </Label>
                      <Select
                        value={newDocument.type}
                        onValueChange={(value) => setNewDocument({ ...newDocument, type: value })}
                      >
                        <SelectTrigger className="col-span-3">
                          <SelectValue placeholder="Select file type" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="PDF">PDF</SelectItem>
                          <SelectItem value="DOCX">DOCX</SelectItem>
                          <SelectItem value="XLSX">XLSX</SelectItem>
                          <SelectItem value="PPTX">PPTX</SelectItem>
                          <SelectItem value="DWG">DWG</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="size" className="text-right">
                        File Size
                      </Label>
                      <Input
                        id="size"
                        value={newDocument.size}
                        onChange={(e) => setNewDocument({ ...newDocument, size: e.target.value })}
                        placeholder="e.g. 2.5 MB"
                        className="col-span-3"
                      />
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="category" className="text-right">
                        Category
                      </Label>
                      <Select
                        value={newDocument.category}
                        onValueChange={(value) => setNewDocument({ ...newDocument, category: value })}
                      >
                        <SelectTrigger className="col-span-3">
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Reference">Reference</SelectItem>
                          <SelectItem value="Guide">Guide</SelectItem>
                          <SelectItem value="Template">Template</SelectItem>
                          <SelectItem value="Handbook">Handbook</SelectItem>
                          <SelectItem value="Standard">Standard</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="grid grid-cols-4 items-center gap-4">
                      <Label htmlFor="tags" className="text-right">
                        Tags
                      </Label>
                      <Input
                        id="tags"
                        value={newDocument.tags}
                        onChange={(e) => setNewDocument({ ...newDocument, tags: e.target.value })}
                        placeholder="e.g. Design, Reference (comma separated)"
                        className="col-span-3"
                      />
                    </div>
                  </>
                )}
              </div>
              <DialogFooter>
                <Button type="submit" onClick={handleAddResource}>
                  Add Resource
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="relative w-full max-w-sm">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          type="search"
          placeholder="Search resources..."
          className="w-full pl-8"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>

      <Tabs defaultValue="materials">
        <TabsList>
          <TabsTrigger value="materials">Materials</TabsTrigger>
          <TabsTrigger value="documents">Documents</TabsTrigger>
        </TabsList>
        <TabsContent value="materials" className="mt-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {filteredMaterials.map((material) => (
              <Card key={material.id} className="relative group">
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-2 right-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity bg-background/80 hover:bg-background/90 hover:text-destructive"
                  onClick={() => handleDeleteResource(material.id, "material")}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
                <CardHeader className="pb-2">
                  <div className="aspect-video w-full overflow-hidden rounded-md">
                    <img
                      src={material.image || "/placeholder.svg"}
                      alt={material.name}
                      className="h-full w-full object-cover"
                    />
                  </div>
                </CardHeader>
                <CardContent className="space-y-2">
                  <CardTitle className="text-lg">{material.name}</CardTitle>
                  <CardDescription>{material.supplier}</CardDescription>
                  <div className="flex items-center justify-between">
                    <Badge>{material.category}</Badge>
                    <div className="flex items-center">
                      <Star className="h-4 w-4 fill-current text-yellow-500" />
                      <span className="ml-1 text-sm">{material.rating}</span>
                    </div>
                  </div>
                  <div className="flex justify-between text-sm">
                    <div>{material.priceINR}</div>
                    <div className={material.availability === "In Stock" ? "text-green-500" : "text-amber-500"}>
                      {material.availability}
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full" onClick={() => handleViewDetails(material, "material")}>
                    View Details
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </TabsContent>
        <TabsContent value="documents" className="mt-6">
          <div className="space-y-4">
            {filteredDocuments.map((document) => (
              <Card key={document.id}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <div className="rounded-md bg-muted p-2">
                      <FileText className="h-8 w-8 text-primary" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h3 className="font-medium">{document.title}</h3>
                        <Badge variant="outline">{document.type}</Badge>
                      </div>
                      <div className="mt-1 flex items-center text-xs text-muted-foreground">
                        <span>{document.size}</span>
                        <span className="mx-2">•</span>
                        <span>Updated {new Date(document.lastUpdated).toLocaleDateString()}</span>
                      </div>
                      <div className="mt-2 flex flex-wrap gap-1">
                        {document.tags.map((tag, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button variant="ghost" size="icon" onClick={() => handleViewDetails(document, "document")}>
                        <ExternalLink className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon">
                        <Download className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="text-muted-foreground hover:text-destructive"
                        onClick={() => handleDeleteResource(document.id, "document")}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Resource Details Dialog */}
      <Dialog open={showDetailsDialog} onOpenChange={setShowDetailsDialog}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>Resource Details</DialogTitle>
          </DialogHeader>
          {selectedResource && (
            <div className="py-4">
              {selectedResource.type === "material" ? (
                <div className="space-y-4">
                  <div className="aspect-video w-full overflow-hidden rounded-md">
                    <img
                      src={selectedResource.image || "/placeholder.svg"}
                      alt={selectedResource.name}
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h3 className="font-semibold text-lg">{selectedResource.name}</h3>
                      <p className="text-sm text-muted-foreground">{selectedResource.supplier}</p>
                    </div>
                    <div className="text-right">
                      <div className="font-medium">{selectedResource.priceINR}</div>
                      <div
                        className={selectedResource.availability === "In Stock" ? "text-green-500" : "text-amber-500"}
                      >
                        {selectedResource.availability}
                      </div>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-medium mb-1">Description</h4>
                    <p className="text-sm">{selectedResource.description}</p>
                  </div>
                  <div className="flex items-center justify-between">
                    <Badge>{selectedResource.category}</Badge>
                    <div className="flex items-center">
                      <Star className="h-4 w-4 fill-current text-yellow-500" />
                      <span className="ml-1 text-sm">{selectedResource.rating}</span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <div className="rounded-md bg-muted p-2">
                      <FileText className="h-8 w-8 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-lg">{selectedResource.title}</h3>
                      <div className="flex items-center text-xs text-muted-foreground">
                        <span>{selectedResource.size}</span>
                        <span className="mx-2">•</span>
                        <span>Updated {new Date(selectedResource.lastUpdated).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-medium mb-1">Description</h4>
                    <p className="text-sm">{selectedResource.description}</p>
                  </div>
                  <div>
                    <h4 className="font-medium mb-1">Category</h4>
                    <Badge>{selectedResource.category}</Badge>
                  </div>
                  <div>
                    <h4 className="font-medium mb-1">Tags</h4>
                    <div className="flex flex-wrap gap-1">
                      {selectedResource.tags.map((tag, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
          <DialogFooter>
            <Button onClick={() => setShowDetailsDialog(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

