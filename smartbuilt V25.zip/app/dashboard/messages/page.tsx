"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Paperclip, Plus, Search, Send, Trash2, X } from "lucide-react"
import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function MessagesPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedConversation, setSelectedConversation] = useState(1)
  const [newMessage, setNewMessage] = useState("")
  const [showNewChatDialog, setShowNewChatDialog] = useState(false)
  const [newChat, setNewChat] = useState({
    name: "",
    role: "",
  })

  const [conversations, setConversations] = useState([
    {
      id: 1,
      name: "Priya Sharma",
      role: "Project Manager",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "PS",
      status: "online",
      lastMessage: "Can we discuss the timeline for the Downtown Office project?",
      time: "10:30 AM",
      unread: 2,
    },
    {
      id: 2,
      name: "Vikram Mehta",
      role: "Interior Designer",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "VM",
      status: "online",
      lastMessage: "I've sent over the material samples for your review.",
      time: "Yesterday",
      unread: 0,
    },
    {
      id: 3,
      name: "Ravi Kapoor",
      role: "General Contractor",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "RK",
      status: "offline",
      lastMessage: "We'll need to adjust the schedule due to the weather forecast.",
      time: "Yesterday",
      unread: 0,
    },
    {
      id: 4,
      name: "Raj Singh",
      role: "Landscape Architect",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "RS",
      status: "away",
      lastMessage: "The revised landscape plans are ready for your approval.",
      time: "Mar 5",
      unread: 0,
    },
    {
      id: 5,
      name: "Neha Gupta",
      role: "Structural Engineer",
      avatar: "/placeholder.svg?height=40&width=40",
      initials: "NG",
      status: "online",
      lastMessage: "I've completed the structural analysis for the Community Center.",
      time: "Mar 4",
      unread: 0,
    },
  ])

  const [messages, setMessages] = useState([
    {
      id: 1,
      conversationId: 1,
      sender: "Priya Sharma",
      senderAvatar: "/placeholder.svg?height=40&width=40",
      senderInitials: "PS",
      content: "Hi Arjun, can we discuss the timeline for the Downtown Office project?",
      time: "10:30 AM",
      isMe: false,
    },
    {
      id: 2,
      conversationId: 1,
      sender: "Me",
      content: "Sure, Priya. What specific aspects of the timeline would you like to discuss?",
      time: "10:32 AM",
      isMe: true,
    },
    {
      id: 3,
      conversationId: 1,
      sender: "Priya Sharma",
      senderAvatar: "/placeholder.svg?height=40&width=40",
      senderInitials: "PS",
      content:
        "I'm concerned about the permit approval process. The city has been taking longer than usual to process applications.",
      time: "10:35 AM",
      isMe: false,
    },
    {
      id: 4,
      conversationId: 1,
      sender: "Priya Sharma",
      senderAvatar: "/placeholder.svg?height=40&width=40",
      senderInitials: "PS",
      content: "Do you think we should adjust our timeline to account for potential delays?",
      time: "10:36 AM",
      isMe: false,
    },
  ])

  const handleSendMessage = () => {
    if (newMessage.trim() === "") return

    const newMessageObj = {
      id: messages.length + 1,
      conversationId: selectedConversation,
      sender: "Me",
      content: newMessage,
      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      isMe: true,
    }

    setMessages([...messages, newMessageObj])

    // Update last message in conversation
    setConversations(
      conversations.map((conv) => {
        if (conv.id === selectedConversation) {
          return {
            ...conv,
            lastMessage: newMessage,
            time: "Just now",
          }
        }
        return conv
      }),
    )

    setNewMessage("")
  }

  const handleDeleteMessage = (messageId) => {
    setMessages(messages.filter((message) => message.id !== messageId))
  }

  const handleDeleteConversation = (conversationId) => {
    setConversations(conversations.filter((conv) => conv.id !== conversationId))
    setMessages(messages.filter((message) => message.conversationId !== conversationId))

    if (selectedConversation === conversationId) {
      setSelectedConversation(conversations.length > 1 ? conversations[0].id : null)
    }
  }

  const handleAddNewChat = () => {
    if (!newChat.name || !newChat.role) return

    const initials = newChat.name
      .split(" ")
      .map((part) => part[0])
      .join("")
      .toUpperCase()

    const newConversation = {
      id: conversations.length + 1,
      name: newChat.name,
      role: newChat.role,
      avatar: "/placeholder.svg?height=40&width=40",
      initials: initials,
      status: "online",
      lastMessage: "New conversation started",
      time: "Just now",
      unread: 0,
    }

    setConversations([...conversations, newConversation])
    setSelectedConversation(newConversation.id)

    // Reset form
    setNewChat({
      name: "",
      role: "",
    })
    setShowNewChatDialog(false)
  }

  const filteredConversations = conversations.filter(
    (conversation) =>
      conversation.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      conversation.role.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const conversationMessages = messages.filter((message) => message.conversationId === selectedConversation)

  const selectedConversationData = conversations.find((conversation) => conversation.id === selectedConversation)

  const roles = [
    "Project Manager",
    "Interior Designer",
    "Structural Engineer",
    "Architect",
    "General Contractor",
    "Electrical Contractor",
    "Plumbing Contractor",
    "HVAC Contractor",
    "Landscape Architect",
    "Client",
    "Supplier",
    "Consultant",
  ]

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Messages</h1>
        <Dialog open={showNewChatDialog} onOpenChange={setShowNewChatDialog}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" /> New Message
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Start New Conversation</DialogTitle>
              <DialogDescription>Create a new conversation with a team member or contractor.</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="name" className="text-right">
                  Name
                </Label>
                <Input
                  id="name"
                  value={newChat.name}
                  onChange={(e) => setNewChat({ ...newChat, name: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="role" className="text-right">
                  Role
                </Label>
                <Select value={newChat.role} onValueChange={(value) => setNewChat({ ...newChat, role: value })}>
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select role" />
                  </SelectTrigger>
                  <SelectContent>
                    {roles.map((role) => (
                      <SelectItem key={role} value={role}>
                        {role}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button type="submit" onClick={handleAddNewChat}>
                Start Conversation
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-6 md:grid-cols-[300px_1fr]">
        <div className="flex flex-col gap-4">
          <div className="relative">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search conversations..."
              className="w-full pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <div className="flex-1 overflow-auto rounded-md border">
            {filteredConversations.map((conversation) => (
              <div
                key={conversation.id}
                className={`flex items-start gap-3 p-3 cursor-pointer hover:bg-muted/50 ${
                  selectedConversation === conversation.id ? "bg-muted" : ""
                }`}
              >
                <div className="relative flex-shrink-0" onClick={() => setSelectedConversation(conversation.id)}>
                  <Avatar>
                    <AvatarImage src={conversation.avatar} alt={conversation.name} />
                    <AvatarFallback>{conversation.initials}</AvatarFallback>
                  </Avatar>
                  <span
                    className={`absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-background ${
                      conversation.status === "online"
                        ? "bg-green-500"
                        : conversation.status === "away"
                          ? "bg-amber-500"
                          : "bg-muted"
                    }`}
                  />
                </div>
                <div className="flex-1 min-w-0" onClick={() => setSelectedConversation(conversation.id)}>
                  <div className="flex items-center justify-between">
                    <div className="font-medium">{conversation.name}</div>
                    <div className="text-xs text-muted-foreground">{conversation.time}</div>
                  </div>
                  <div className="text-xs text-muted-foreground">{conversation.role}</div>
                  <div className="mt-1 truncate text-sm text-muted-foreground">{conversation.lastMessage}</div>
                </div>
                <div className="flex flex-col items-center gap-1">
                  {conversation.unread > 0 && <Badge className="ml-auto flex-shrink-0">{conversation.unread}</Badge>}
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-6 w-6 text-muted-foreground hover:text-destructive"
                    onClick={() => handleDeleteConversation(conversation.id)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>

        <Card className="flex flex-col">
          {selectedConversationData ? (
            <>
              <div className="flex items-center gap-3 border-b p-4">
                <div className="relative">
                  <Avatar>
                    <AvatarImage src={selectedConversationData.avatar} alt={selectedConversationData.name} />
                    <AvatarFallback>{selectedConversationData.initials}</AvatarFallback>
                  </Avatar>
                  <span
                    className={`absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-background ${
                      selectedConversationData.status === "online"
                        ? "bg-green-500"
                        : selectedConversationData.status === "away"
                          ? "bg-amber-500"
                          : "bg-muted"
                    }`}
                  />
                </div>
                <div>
                  <div className="font-medium">{selectedConversationData.name}</div>
                  <div className="text-xs text-muted-foreground">{selectedConversationData.role}</div>
                </div>
              </div>

              <CardContent className="flex-1 overflow-auto p-4 space-y-4">
                {conversationMessages.map((message) => (
                  <div key={message.id} className={`flex ${message.isMe ? "justify-end" : "justify-start"}`}>
                    <div
                      className={`max-w-[80%] group relative ${message.isMe ? "bg-primary text-primary-foreground" : "bg-muted"} rounded-lg p-3`}
                    >
                      {!message.isMe && (
                        <div className="flex items-center gap-2 mb-1">
                          <Avatar className="h-6 w-6">
                            <AvatarImage src={message.senderAvatar} alt={message.sender} />
                            <AvatarFallback>{message.senderInitials}</AvatarFallback>
                          </Avatar>
                          <div className="text-xs font-medium">{message.sender}</div>
                        </div>
                      )}
                      <div className="text-sm">{message.content}</div>
                      <div
                        className={`text-xs mt-1 text-right ${message.isMe ? "text-primary-foreground/70" : "text-muted-foreground"}`}
                      >
                        {message.time}
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className={`absolute top-1 right-1 h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity ${
                          message.isMe
                            ? "text-primary-foreground/70 hover:text-primary-foreground"
                            : "text-muted-foreground hover:text-foreground"
                        }`}
                        onClick={() => handleDeleteMessage(message.id)}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>

              <div className="border-t p-4">
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="icon" className="rounded-full">
                    <Paperclip className="h-4 w-4" />
                  </Button>
                  <Input
                    placeholder="Type a message..."
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        handleSendMessage()
                      }
                    }}
                  />
                  <Button size="icon" className="rounded-full" onClick={handleSendMessage}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </>
          ) : (
            <div className="flex h-full items-center justify-center p-8 text-center">
              <div>
                <h3 className="text-lg font-medium">No conversation selected</h3>
                <p className="text-sm text-muted-foreground">Select a conversation from the list or start a new one.</p>
              </div>
            </div>
          )}
        </Card>
      </div>
    </div>
  )
}

