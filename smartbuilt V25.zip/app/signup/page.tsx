"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import {
  Building2,
  Check,
  ChevronLeft,
  ChevronRight,
  Eye,
  EyeOff,
  HardHat,
  Lock,
  Mail,
  User,
  Users,
  Briefcase,
  Award,
  Calendar,
  MapPin,
  Phone,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { ThemeSwitch } from "@/components/theme-switch"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

type UserRole = "architect" | "contractor" | "client"

interface UserData {
  email: string
  password: string
  name: string
  role: UserRole
  phone?: string
  address?: string
  // Architect specific fields
  licenseNumber?: string
  yearsOfExperience?: string
  specialization?: string
  education?: string
  portfolioUrl?: string
  professionalAssociations?: string
  // Contractor specific fields
  companyName?: string
  businessType?: string
  serviceArea?: string
  insuranceInfo?: string
  licenseType?: string
  crewSize?: string
}

export default function SignupPage() {
  const router = useRouter()
  const [step, setStep] = useState(1)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [userData, setUserData] = useState<UserData>({
    email: "",
    password: "",
    name: "",
    role: "client",
    phone: "",
    address: "",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setUserData((prev) => ({ ...prev, [name]: value }))
  }

  const handleRoleChange = (value: UserRole) => {
    setUserData((prev) => ({ ...prev, role: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setUserData((prev) => ({ ...prev, [name]: value }))
  }

  const nextStep = () => {
    // Basic validation before proceeding
    if (step === 1) {
      if (!userData.name || !userData.email || !userData.password) {
        setError("Please fill in all required fields")
        return
      }
      if (userData.password.length < 8) {
        setError("Password must be at least 8 characters long")
        return
      }
    }

    setError("")
    setStep((prev) => prev + 1)
  }

  const prevStep = () => {
    setStep((prev) => prev - 1)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError("")

    try {
      // Simulate API call delay
      await new Promise((resolve) => setTimeout(resolve, 1000))

      // Store user info in localStorage (in a real app, this would be handled by a proper auth system)
      localStorage.setItem("userRole", userData.role)
      localStorage.setItem("userEmail", userData.email)
      localStorage.setItem("userName", userData.name)
      localStorage.setItem("isLoggedIn", "true")

      // Redirect based on role
      if (userData.role === "architect") {
        router.push("/dashboard")
      } else if (userData.role === "contractor") {
        router.push("/contractor-dashboard")
      } else {
        router.push("/client-dashboard")
      }
    } catch (err) {
      setError("Failed to create account. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  const renderStepContent = () => {
    switch (step) {
      case 1:
        return (
          <>
            <CardHeader className="space-y-1">
              <CardTitle className="text-2xl font-bold">Create an account</CardTitle>
              <CardDescription>Enter your basic information to get started</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {error && <div className="bg-destructive/10 text-destructive text-sm p-3 rounded-md">{error}</div>}
              <div className="space-y-2">
                <Label htmlFor="name">Full Name</Label>
                <div className="relative">
                  <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="name"
                    name="name"
                    placeholder="John Doe"
                    className="pl-10"
                    value={userData.name}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    placeholder="name@example.com"
                    className="pl-10"
                    value={userData.email}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Password</Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    id="password"
                    name="password"
                    type={showPassword ? "text" : "password"}
                    className="pl-10 pr-10"
                    value={userData.password}
                    onChange={handleChange}
                    required
                  />
                  <button
                    type="button"
                    className="absolute right-3 top-3 h-4 w-4 text-muted-foreground"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
                <p className="text-xs text-muted-foreground">Password must be at least 8 characters long</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="phone"
                      name="phone"
                      placeholder="+1 (555) 123-4567"
                      className="pl-10"
                      value={userData.phone}
                      onChange={handleChange}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="address">Address</Label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="address"
                      name="address"
                      placeholder="123 Main St, City, State"
                      className="pl-10"
                      value={userData.address}
                      onChange={handleChange}
                    />
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full" onClick={nextStep}>
                Continue <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </CardFooter>
          </>
        )
      case 2:
        return (
          <>
            <CardHeader className="space-y-1">
              <CardTitle className="text-2xl font-bold">Select your role</CardTitle>
              <CardDescription>Choose the role that best describes you</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {error && <div className="bg-destructive/10 text-destructive text-sm p-3 rounded-md">{error}</div>}
              <RadioGroup value={userData.role} onValueChange={(value) => handleRoleChange(value as UserRole)}>
                <div className="flex items-center space-x-2 rounded-md border p-4 cursor-pointer hover:bg-muted/50">
                  <RadioGroupItem value="architect" id="architect" />
                  <Label htmlFor="architect" className="flex-1 cursor-pointer">
                    <div className="flex items-center">
                      <Building2 className="mr-2 h-5 w-5 text-primary" />
                      <div>
                        <div className="font-medium">Architect</div>
                        <div className="text-sm text-muted-foreground">Design and manage architectural projects</div>
                      </div>
                    </div>
                  </Label>
                </div>
                <div className="flex items-center space-x-2 rounded-md border p-4 cursor-pointer hover:bg-muted/50">
                  <RadioGroupItem value="contractor" id="contractor" />
                  <Label htmlFor="contractor" className="flex-1 cursor-pointer">
                    <div className="flex items-center">
                      <HardHat className="mr-2 h-5 w-5 text-amber-500" />
                      <div>
                        <div className="font-medium">Contractor</div>
                        <div className="text-sm text-muted-foreground">
                          Provide construction and specialized services
                        </div>
                      </div>
                    </div>
                  </Label>
                </div>
                <div className="flex items-center space-x-2 rounded-md border p-4 cursor-pointer hover:bg-muted/50">
                  <RadioGroupItem value="client" id="client" />
                  <Label htmlFor="client" className="flex-1 cursor-pointer">
                    <div className="flex items-center">
                      <Users className="mr-2 h-5 w-5 text-green-500" />
                      <div>
                        <div className="font-medium">Client</div>
                        <div className="text-sm text-muted-foreground">
                          Hire architects and contractors for your projects
                        </div>
                      </div>
                    </div>
                  </Label>
                </div>
              </RadioGroup>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" onClick={prevStep}>
                <ChevronLeft className="mr-2 h-4 w-4" /> Back
              </Button>
              <Button onClick={nextStep}>
                Continue <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </CardFooter>
          </>
        )
      case 3:
        if (userData.role === "architect") {
          return (
            <>
              <CardHeader className="space-y-1">
                <CardTitle className="text-2xl font-bold">Architect Verification</CardTitle>
                <CardDescription>Please provide your professional credentials</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {error && <div className="bg-destructive/10 text-destructive text-sm p-3 rounded-md">{error}</div>}
                <div className="space-y-2">
                  <Label htmlFor="licenseNumber">License Number</Label>
                  <div className="relative">
                    <Award className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="licenseNumber"
                      name="licenseNumber"
                      placeholder="e.g. AR12345"
                      className="pl-10"
                      value={userData.licenseNumber || ""}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <p className="text-xs text-muted-foreground">Your professional architect license number</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="yearsOfExperience">Years of Experience</Label>
                    <div className="relative">
                      <Calendar className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                      <Input
                        id="yearsOfExperience"
                        name="yearsOfExperience"
                        type="number"
                        placeholder="e.g. 5"
                        className="pl-10"
                        value={userData.yearsOfExperience || ""}
                        onChange={handleChange}
                        required
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="specialization">Specialization</Label>
                    <Select
                      value={userData.specialization || ""}
                      onValueChange={(value) => handleSelectChange("specialization", value)}
                    >
                      <SelectTrigger id="specialization">
                        <SelectValue placeholder="Select specialization" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="residential">Residential</SelectItem>
                        <SelectItem value="commercial">Commercial</SelectItem>
                        <SelectItem value="industrial">Industrial</SelectItem>
                        <SelectItem value="landscape">Landscape</SelectItem>
                        <SelectItem value="interior">Interior Design</SelectItem>
                        <SelectItem value="urban">Urban Planning</SelectItem>
                        <SelectItem value="sustainable">Sustainable Design</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="education">Education</Label>
                  <Input
                    id="education"
                    name="education"
                    placeholder="e.g. Master of Architecture, University Name"
                    value={userData.education || ""}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="portfolioUrl">Portfolio URL (Optional)</Label>
                  <Input
                    id="portfolioUrl"
                    name="portfolioUrl"
                    placeholder="e.g. https://yourportfolio.com"
                    value={userData.portfolioUrl || ""}
                    onChange={handleChange}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="professionalAssociations">Professional Associations (Optional)</Label>
                  <Textarea
                    id="professionalAssociations"
                    name="professionalAssociations"
                    placeholder="e.g. American Institute of Architects (AIA)"
                    value={userData.professionalAssociations || ""}
                    onChange={handleChange}
                  />
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" onClick={prevStep}>
                  <ChevronLeft className="mr-2 h-4 w-4" /> Back
                </Button>
                <Button onClick={handleSubmit} disabled={isLoading}>
                  {isLoading ? "Creating Account..." : "Create Account"}
                </Button>
              </CardFooter>
            </>
          )
        } else if (userData.role === "contractor") {
          return (
            <>
              <CardHeader className="space-y-1">
                <CardTitle className="text-2xl font-bold">Contractor Verification</CardTitle>
                <CardDescription>Please provide your business information</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {error && <div className="bg-destructive/10 text-destructive text-sm p-3 rounded-md">{error}</div>}
                <div className="space-y-2">
                  <Label htmlFor="companyName">Company Name</Label>
                  <div className="relative">
                    <Briefcase className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      id="companyName"
                      name="companyName"
                      placeholder="e.g. ABC Construction"
                      className="pl-10"
                      value={userData.companyName || ""}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="businessType">Business Type</Label>
                    <Select
                      value={userData.businessType || ""}
                      onValueChange={(value) => handleSelectChange("businessType", value)}
                    >
                      <SelectTrigger id="businessType">
                        <SelectValue placeholder="Select business type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="general">General Contractor</SelectItem>
                        <SelectItem value="electrical">Electrical</SelectItem>
                        <SelectItem value="plumbing">Plumbing</SelectItem>
                        <SelectItem value="hvac">HVAC</SelectItem>
                        <SelectItem value="roofing">Roofing</SelectItem>
                        <SelectItem value="landscaping">Landscaping</SelectItem>
                        <SelectItem value="interior">Interior Finishing</SelectItem>
                        <SelectItem value="masonry">Masonry</SelectItem>
                        <SelectItem value="carpentry">Carpentry</SelectItem>
                        <SelectItem value="painting">Painting</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="licenseType">License Type</Label>
                    <Input
                      id="licenseType"
                      name="licenseType"
                      placeholder="e.g. General Contractor License"
                      value={userData.licenseType || ""}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="serviceArea">Service Area</Label>
                  <Input
                    id="serviceArea"
                    name="serviceArea"
                    placeholder="e.g. New York City, Los Angeles County"
                    value={userData.serviceArea || ""}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="insuranceInfo">Insurance Information</Label>
                  <Textarea
                    id="insuranceInfo"
                    name="insuranceInfo"
                    placeholder="e.g. Liability Insurance Policy #12345, Workers' Comp Policy #67890"
                    value={userData.insuranceInfo || ""}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="crewSize">Crew Size</Label>
                  <Select
                    value={userData.crewSize || ""}
                    onValueChange={(value) => handleSelectChange("crewSize", value)}
                  >
                    <SelectTrigger id="crewSize">
                      <SelectValue placeholder="Select crew size" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1-5">1-5 employees</SelectItem>
                      <SelectItem value="6-15">6-15 employees</SelectItem>
                      <SelectItem value="16-30">16-30 employees</SelectItem>
                      <SelectItem value="31-50">31-50 employees</SelectItem>
                      <SelectItem value="50+">50+ employees</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" onClick={prevStep}>
                  <ChevronLeft className="mr-2 h-4 w-4" /> Back
                </Button>
                <Button onClick={handleSubmit} disabled={isLoading}>
                  {isLoading ? "Creating Account..." : "Create Account"}
                </Button>
              </CardFooter>
            </>
          )
        } else {
          return (
            <>
              <CardHeader className="space-y-1">
                <CardTitle className="text-2xl font-bold">Almost Done!</CardTitle>
                <CardDescription>Review your information before creating your account</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {error && <div className="bg-destructive/10 text-destructive text-sm p-3 rounded-md">{error}</div>}
                <div className="rounded-md bg-muted p-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <div className="text-sm font-medium">Name</div>
                      <div className="text-sm">{userData.name}</div>
                    </div>
                    <div>
                      <div className="text-sm font-medium">Email</div>
                      <div className="text-sm">{userData.email}</div>
                    </div>
                    <div>
                      <div className="text-sm font-medium">Phone</div>
                      <div className="text-sm">{userData.phone || "Not provided"}</div>
                    </div>
                    <div>
                      <div className="text-sm font-medium">Role</div>
                      <div className="text-sm capitalize">{userData.role}</div>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Check className="h-4 w-4 text-green-500" />
                  <span className="text-sm">
                    By creating an account, you agree to our Terms of Service and Privacy Policy.
                  </span>
                </div>
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button variant="outline" onClick={prevStep}>
                  <ChevronLeft className="mr-2 h-4 w-4" /> Back
                </Button>
                <Button onClick={handleSubmit} disabled={isLoading}>
                  {isLoading ? "Creating Account..." : "Create Account"}
                </Button>
              </CardFooter>
            </>
          )
        }
      default:
        return null
    }
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Building2 className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold">SmartBuilt</span>
          </Link>
          <ThemeSwitch />
        </div>
      </header>
      <main className="flex-1 flex items-center justify-center p-4 bg-muted/30">
        <Card className="w-full max-w-md">
          <form onSubmit={(e) => e.preventDefault()}>
            <div className="mb-4 px-6 pt-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <div
                    className={`h-8 w-8 rounded-full flex items-center justify-center ${step >= 1 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}
                  >
                    1
                  </div>
                  <div className={`h-1 w-8 ${step >= 2 ? "bg-primary" : "bg-muted"}`}></div>
                  <div
                    className={`h-8 w-8 rounded-full flex items-center justify-center ${step >= 2 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}
                  >
                    2
                  </div>
                  <div className={`h-1 w-8 ${step >= 3 ? "bg-primary" : "bg-muted"}`}></div>
                  <div
                    className={`h-8 w-8 rounded-full flex items-center justify-center ${step >= 3 ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}
                  >
                    3
                  </div>
                </div>
                <div className="text-sm text-muted-foreground">Step {step} of 3</div>
              </div>
            </div>
            {renderStepContent()}
          </form>
          <CardFooter className="flex-col pt-0">
            <div className="mt-4 text-center text-sm">
              Already have an account?{" "}
              <Link href="/login" className="text-primary hover:underline">
                Login
              </Link>
            </div>
          </CardFooter>
        </Card>
      </main>
    </div>
  )
}

