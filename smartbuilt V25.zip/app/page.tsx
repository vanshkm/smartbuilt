import { Button } from "@/components/ui/button"
import { Building2, Compass, Ruler, Users, ArrowRight, Star, ArrowDown, Globe, Shield, Clock } from "lucide-react"
import Link from "next/link"
import { ThemeSwitch } from "@/components/theme-switch"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Building2 className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold">SmartBuilt</span>
          </Link>
          <nav className="hidden md:flex items-center gap-6">
            <Link href="/features" className="text-sm font-medium hover:text-primary transition-colors">
              Features
            </Link>
            <Link href="/solutions" className="text-sm font-medium hover:text-primary transition-colors">
              Solutions
            </Link>
            <Link href="/pricing" className="text-sm font-medium hover:text-primary transition-colors">
              Pricing
            </Link>
            <Link href="/about" className="text-sm font-medium hover:text-primary transition-colors">
              About
            </Link>
          </nav>
          <div className="flex items-center gap-4">
            <ThemeSwitch />
            <Link href="/login">
              <Button variant="outline" size="sm" className="transition-all hover:border-primary">
                Log in
              </Button>
            </Link>
            <Link href="/signup">
              <Button size="sm" className="shadow-lg shadow-primary/20 transition-all hover:shadow-primary/30">
                Sign Up
              </Button>
            </Link>
          </div>
        </div>
      </header>
      <main className="flex-1">
        {/* Hero Section - Redesigned for more professional impact */}
        <section className="w-full py-20 md:py-30 lg:py-40 relative overflow-hidden">
          <div className="absolute inset-0 bg-[url('/architecture-hero.jpg')] bg-cover bg-center bg-fixed"></div>
          <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/80 to-background/30 dark:from-background/95 dark:via-background/90 dark:to-background/70"></div>

          <div className="container px-4 md:px-6 relative z-10">
            <div className="grid gap-8 lg:grid-cols-2 lg:gap-12 items-center">
              <div className="flex flex-col justify-center space-y-6">
                <div className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 border-transparent bg-primary text-primary-foreground hover:bg-primary/80 w-fit">
                  Transforming Architectural Workflows
                </div>
                <div className="space-y-4">
                  <h1 className="text-4xl font-bold tracking-tighter text-foreground sm:text-5xl md:text-6xl lg:text-7xl">
                    Design. Collaborate. <span className="text-primary">Build.</span>
                  </h1>
                  <p className="max-w-[600px] text-foreground/80 md:text-xl lg:text-2xl">
                    The complete platform for architects to manage projects, collaborate with teams, and deliver
                    exceptional results.
                  </p>
                </div>
                <div className="flex flex-col sm:flex-row gap-4">
                  <Link href="/dashboard">
                    <Button
                      size="lg"
                      className="gap-2 font-bold shadow-lg shadow-primary/20 transition-all hover:shadow-primary/30 text-base"
                    >
                      Get Started <ArrowRight className="h-4 w-4" />
                    </Button>
                  </Link>
                  <Link href="/features">
                    <Button size="lg" variant="outline" className="gap-2 text-base">
                      Explore Features <Compass className="h-4 w-4" />
                    </Button>
                  </Link>
                </div>
                <div className="flex items-center gap-8 pt-4">
                  <div className="flex flex-col">
                    <span className="text-3xl font-bold">10k+</span>
                    <span className="text-sm text-muted-foreground">Architects</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-3xl font-bold">50k+</span>
                    <span className="text-sm text-muted-foreground">Projects</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-3xl font-bold">98%</span>
                    <span className="text-sm text-muted-foreground">Satisfaction</span>
                  </div>
                </div>
              </div>

              <div className="relative h-[400px] w-full rounded-2xl overflow-hidden shadow-2xl">
                <img
                  src="/hero-building-mockup.jpg"
                  alt="SmartBuilt Platform Visualization"
                  className="object-cover w-full h-full"
                />
                <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-transparent mix-blend-overlay"></div>
              </div>
            </div>

            <div className="absolute bottom-8 left-1/2 -translate-x-1/2 hidden md:flex flex-col items-center animate-bounce">
              <span className="text-sm text-muted-foreground mb-2">Scroll to explore</span>
              <ArrowDown className="h-4 w-4 text-muted-foreground" />
            </div>
          </div>
        </section>

        {/* Trusted By Section */}
        <section className="w-full py-12 bg-muted/50">
          <div className="container px-4 md:px-6">
            <div className="text-center mb-8">
              <h2 className="text-xl font-semibold text-muted-foreground">
                Trusted by leading architecture firms worldwide
              </h2>
            </div>
            <div className="flex flex-wrap justify-center items-center gap-8 md:gap-16">
              {["Foster + Partners", "Zaha Hadid Architects", "BIG", "SOM", "Gensler"].map((company, i) => (
                <div
                  key={i}
                  className="text-xl font-bold text-muted-foreground/70 hover:text-foreground transition-colors"
                >
                  {company}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Key Features Section */}
        <section id="features" className="w-full py-20 md:py-32 animated-gradient">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center mb-12">
              <div className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 border-transparent bg-primary/10 text-primary hover:bg-primary/20 w-fit">
                Powerful Features
              </div>
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">
                Designed for <span className="text-primary">Architects</span>
              </h2>
              <p className="max-w-[900px] text-muted-foreground md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Everything you need to manage your architectural projects from concept to completion.
              </p>
            </div>
            <div className="mx-auto grid max-w-5xl grid-cols-1 gap-8 md:grid-cols-3">
              <Link href="/dashboard/team">
                <div className="feature-card flex flex-col items-center space-y-4 rounded-lg border p-6 shadow-sm bg-background hover:bg-muted/10">
                  <div className="rounded-full bg-primary/10 p-3">
                    <Users className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-xl font-bold">Team Collaboration</h3>
                  <p className="text-center text-muted-foreground">
                    Create project teams and assign tasks to contractors, plumbers, and decorators.
                  </p>
                  <div className="mt-auto pt-4">
                    <Button variant="ghost" size="sm" className="gap-1">
                      Learn more <ArrowRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </Link>
              <Link href="/dashboard/map">
                <div className="feature-card flex flex-col items-center space-y-4 rounded-lg border p-6 shadow-sm bg-background hover:bg-muted/10">
                  <div className="rounded-full bg-primary/10 p-3">
                    <Globe className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-xl font-bold">Interactive World Map</h3>
                  <p className="text-center text-muted-foreground">
                    Display project locations and nearby resources, including suppliers and contractors.
                  </p>
                  <div className="mt-auto pt-4">
                    <Button variant="ghost" size="sm" className="gap-1">
                      Learn more <ArrowRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </Link>
              <Link href="/dashboard/material-estimation">
                <div className="feature-card flex flex-col items-center space-y-4 rounded-lg border p-6 shadow-sm bg-background hover:bg-muted/10">
                  <div className="rounded-full bg-primary/10 p-3">
                    <Ruler className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-xl font-bold">Material Estimation</h3>
                  <p className="text-center text-muted-foreground">
                    Calculate the required resources based on project needs and specifications.
                  </p>
                  <div className="mt-auto pt-4">
                    <Button variant="ghost" size="sm" className="gap-1">
                      Learn more <ArrowRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </Link>
            </div>
          </div>
        </section>

        {/* Why Choose Us Section */}
        <section className="w-full py-20 md:py-32 bg-muted/50 pattern-overlay">
          <div className="container px-4 md:px-6">
            <div className="grid gap-12 lg:grid-cols-2 items-center">
              <div className="space-y-6">
                <div className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 border-transparent bg-primary/10 text-primary hover:bg-primary/20 w-fit">
                  Why Choose SmartBuilt
                </div>
                <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl">
                  Trusted by <span className="text-primary">Professionals</span> Worldwide
                </h2>
                <p className="text-muted-foreground md:text-xl">
                  Join thousands of architects and construction professionals who use SmartBuilt to streamline their
                  workflow.
                </p>
                <div className="space-y-4">
                  {[
                    {
                      icon: Clock,
                      title: "Save Time",
                      description: "Reduce project management time by up to 40%",
                    },
                    {
                      icon: Users,
                      title: "Enhance Collaboration",
                      description: "Seamless communication between team members, clients, and contractors",
                    },
                    {
                      icon: Globe,
                      title: "Work Anywhere",
                      description: "Access your projects from anywhere, on any device",
                    },
                    {
                      icon: Shield,
                      title: "Secure & Reliable",
                      description: "Enterprise-grade security for your sensitive project data",
                    },
                  ].map((item, i) => (
                    <div key={i} className="flex items-start gap-4">
                      <div className="rounded-full bg-primary/10 p-2 mt-1">
                        <item.icon className="h-4 w-4 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold">{item.title}</h3>
                        <p className="text-muted-foreground">{item.description}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="pt-4">
                  <Link href="/about">
                    <Button className="gap-2">
                      Learn About Us <ArrowRight className="h-4 w-4" />
                    </Button>
                  </Link>
                </div>
              </div>
              <div className="relative">
                <div className="absolute -inset-4 rounded-xl bg-primary/5 -z-10"></div>
                <div className="grid gap-4 grid-cols-2">
                  <div className="space-y-4">
                    <div className="glass-card p-6 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                        <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                        <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                        <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                        <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                      </div>
                      <p className="text-sm">"SmartBuilt has transformed how we manage our architectural projects."</p>
                      <p className="text-xs text-muted-foreground mt-2">- Sarah J., Principal Architect</p>
                    </div>
                    <div className="glass-card p-6 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                        <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                        <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                        <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                        <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                      </div>
                      <p className="text-sm">
                        "The material estimation feature alone has saved us thousands of dollars."
                      </p>
                      <p className="text-xs text-muted-foreground mt-2">- Michael T., Construction Manager</p>
                    </div>
                  </div>
                  <div className="space-y-4 mt-8">
                    <div className="glass-card p-6 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                        <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                        <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                        <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                        <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                      </div>
                      <p className="text-sm">
                        "As a client, I love being able to track my project's progress in real-time."
                      </p>
                      <p className="text-xs text-muted-foreground mt-2">- David L., Property Developer</p>
                    </div>
                    <div className="glass-card p-6 rounded-lg">
                      <div className="flex items-center gap-2 mb-2">
                        <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                        <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                        <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                        <Star className="h-5 w-5 text-yellow-500 fill-yellow-500" />
                        <Star className="h-5 w-5 text-yellow-500" />
                      </div>
                      <p className="text-sm">
                        "The interactive map feature is a game-changer for managing multiple sites."
                      </p>
                      <p className="text-xs text-muted-foreground mt-2">- Emma R., Urban Planner</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
      </main>
      <footer className="w-full border-t py-8 bg-muted/50">
        <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
          <Link href="/" className="flex items-center gap-2">
            <Building2 className="h-5 w-5 text-primary" />
            <span className="text-lg font-semibold">SmartBuilt</span>
          </Link>
          <p className="text-center text-sm text-muted-foreground">© 2025 SmartBuilt. All rights reserved.</p>
          <div className="flex gap-4">
            <Link href="/terms" className="text-sm text-muted-foreground hover:text-primary transition-colors">
              Terms
            </Link>
            <Link href="/privacy" className="text-sm text-muted-foreground hover:text-primary transition-colors">
              Privacy
            </Link>
            <Link href="/contact" className="text-sm text-muted-foreground hover:text-primary transition-colors">
              Contact
            </Link>
          </div>
        </div>
      </footer>
    </div>
  )
}

