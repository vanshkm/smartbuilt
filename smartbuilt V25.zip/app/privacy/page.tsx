import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function PrivacyPage() {
  return (
    <div className="container py-12 space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl">Privacy Policy</h1>
        <p className="max-w-[700px] mx-auto text-muted-foreground">
          Your privacy is important to us. This policy outlines how we collect, use, and protect your personal
          information.
        </p>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>1. Information We Collect</CardTitle>
        </CardHeader>
        <CardContent>
          <p>
            We collect information you provide directly to us, such as when you create an account, use our services, or
            communicate with us. This may include your name, email address, and other personal details.
          </p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>2. How We Use Your Information</CardTitle>
        </CardHeader>
        <CardContent>
          <p>
            We use the information we collect to provide, maintain, and improve our services, to communicate with you,
            and to personalize your experience with SmartBuilt.
          </p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>3. Data Security</CardTitle>
        </CardHeader>
        <CardContent>
          <p>
            We implement a variety of security measures to maintain the safety of your personal information. However, no
            method of transmission over the Internet or electronic storage is 100% secure.
          </p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>4. Sharing of Information</CardTitle>
        </CardHeader>
        <CardContent>
          <p>
            We do not sell, trade, or otherwise transfer your personally identifiable information to outside parties.
            This does not include trusted third parties who assist us in operating our website, conducting our business,
            or servicing you.
          </p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader>
          <CardTitle>5. Your Rights</CardTitle>
        </CardHeader>
        <CardContent>
          <p>
            You have the right to access, correct, or delete your personal information at any time. You can do this
            through your account settings or by contacting us directly.
          </p>
        </CardContent>
      </Card>
      <p className="text-sm text-muted-foreground text-center">Last updated: March 7, 2024</p>
    </div>
  )
}

