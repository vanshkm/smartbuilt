"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Building2, CreditCard, Check, Smartphone } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function PricingPage() {
  const router = useRouter()
  const [showPaymentDialog, setShowPaymentDialog] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState(null)
  const [paymentMethod, setPaymentMethod] = useState("card")
  const [showConfirmation, setShowConfirmation] = useState(false)

  const plans = [
    {
      name: "Starter",
      price: "₹2,999",
      period: "/month",
      description: "Perfect for freelancers and small practices",
      features: [
        "Up to 5 active projects",
        "Basic project management tools",
        "Client portal",
        "Material estimation",
        "Email support",
      ],
      buttonText: "Start Free Trial",
    },
    {
      name: "Professional",
      price: "₹6,999",
      period: "/6-months",
      description: "Ideal for growing architecture firms",
      features: [
        "Up to 20 active projects",
        "Advanced project management",
        "Team collaboration tools",
        "Resource management",
        "3D blueprint viewer",
        "Priority email and chat support",
      ],
      buttonText: "Subscribe",
    },
    {
      name: "Enterprise",
      price: "₹11,999",
      period: "/year",
      description: "For large firms with complex needs",
      features: [
        "Unlimited active projects",
        "Full suite of project management tools",
        "Advanced analytics and reporting",
        "Custom integrations",
        "Dedicated account manager",
        "24/7 priority support",
      ],
      buttonText: "Subscribe",
    },
  ]

  const handlePlanSelect = (plan) => {
    setSelectedPlan(plan)
    setShowPaymentDialog(true)
  }

  const handlePaymentSubmit = () => {
    setShowConfirmation(true)
  }

  const handleConfirmPayment = () => {
    setShowConfirmation(false)
    setShowPaymentDialog(false)
    // Here you would typically redirect to a success page or dashboard
    router.push("/dashboard")
  }

  const handleContactSales = () => {
    router.push("/contact?inquiry=custom-plan")
  }

  return (
    <div className="container py-12 space-y-12">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold tracking-tighter sm:text-5xl">Transparent Pricing for Every Practice</h1>
        <p className="max-w-[700px] mx-auto text-muted-foreground">
          Choose the plan that best fits your needs. Starter plans include a 7-day free trial.
        </p>
      </div>
      <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
        {plans.map((plan, index) => (
          <Card key={index} className={index === 1 ? "border-primary" : ""}>
            <CardHeader>
              <CardTitle>{plan.name}</CardTitle>
              <CardDescription>{plan.description}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-4xl font-bold">
                {plan.price}
                <span className="text-base font-normal text-muted-foreground">{plan.period}</span>
              </div>
              <ul className="space-y-2">
                {plan.features.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-center">
                    <Check className="h-4 w-4 mr-2 text-primary" />
                    <span className="text-sm">{feature}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              <Button className="w-full" onClick={() => handlePlanSelect(plan)}>
                {plan.buttonText}
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
      <div className="text-center space-y-4">
        <h2 className="text-2xl font-bold">Need a custom solution?</h2>
        <p className="max-w-[600px] mx-auto text-muted-foreground">
          We offer tailored plans for large firms or those with specific requirements. Get in touch to discuss your
          needs.
        </p>
        <Button
          variant="default"
          className="bg-gradient-to-r from-primary to-primary/80 hover:from-primary/90 hover:to-primary/70 text-white"
          onClick={handleContactSales}
        >
          Contact Sales
        </Button>
      </div>

      {/* Payment Dialog */}
      <Dialog open={showPaymentDialog} onOpenChange={setShowPaymentDialog}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Complete Your Subscription</DialogTitle>
            <DialogDescription>
              {selectedPlan &&
                `You've selected the ${selectedPlan.name} plan (${selectedPlan.price}${selectedPlan.period})`}
            </DialogDescription>
          </DialogHeader>

          <Tabs defaultValue="card" onValueChange={setPaymentMethod}>
            <TabsList className="grid grid-cols-4 w-full">
              <TabsTrigger value="card">Card</TabsTrigger>
              <TabsTrigger value="netbanking">Net Banking</TabsTrigger>
              <TabsTrigger value="upi">UPI</TabsTrigger>
              <TabsTrigger value="mastercard">Mastercard</TabsTrigger>
            </TabsList>

            <TabsContent value="card" className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="cardNumber">Card Number</Label>
                <Input id="cardNumber" placeholder="1234 5678 9012 3456" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="expiry">Expiry Date</Label>
                  <Input id="expiry" placeholder="MM/YY" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cvv">CVV</Label>
                  <Input id="cvv" placeholder="123" type="password" />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="nameOnCard">Name on Card</Label>
                <Input id="nameOnCard" placeholder="John Doe" />
              </div>
            </TabsContent>

            <TabsContent value="netbanking" className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="bank">Select Bank</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Select your bank" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sbi">State Bank of India</SelectItem>
                    <SelectItem value="hdfc">HDFC Bank</SelectItem>
                    <SelectItem value="icici">ICICI Bank</SelectItem>
                    <SelectItem value="axis">Axis Bank</SelectItem>
                    <SelectItem value="kotak">Kotak Mahindra Bank</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="accountNumber">Account Number</Label>
                <Input id="accountNumber" placeholder="Enter your account number" />
              </div>
            </TabsContent>

            <TabsContent value="upi" className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="upiId">UPI ID</Label>
                <Input id="upiId" placeholder="yourname@upi" />
              </div>
              <p className="text-sm text-muted-foreground">
                You will receive a payment request on your UPI app. Please complete the payment there.
              </p>
            </TabsContent>

            <TabsContent value="mastercard" className="space-y-4 mt-4">
              <div className="space-y-2">
                <Label htmlFor="mastercardNumber">Mastercard Number</Label>
                <Input id="mastercardNumber" placeholder="5123 4567 8901 2346" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="mastercardExpiry">Expiry Date</Label>
                  <Input id="mastercardExpiry" placeholder="MM/YY" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="mastercardCvv">CVV</Label>
                  <Input id="mastercardCvv" placeholder="123" type="password" />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="mastercardName">Name on Card</Label>
                <Input id="mastercardName" placeholder="Name" />
              </div>
            </TabsContent>
          </Tabs>

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowPaymentDialog(false)}>
              Cancel
            </Button>
            <Button onClick={handlePaymentSubmit}>Proceed to Payment</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Confirmation Dialog */}
      <Dialog open={showConfirmation} onOpenChange={setShowConfirmation}>
        <DialogContent className="sm:max-w-[400px]">
          <DialogHeader>
            <DialogTitle>Confirm Payment</DialogTitle>
            <DialogDescription>Please confirm your payment details are correct.</DialogDescription>
          </DialogHeader>

          {selectedPlan && (
            <div className="py-4">
              <div className="flex justify-between mb-2">
                <span className="font-medium">Plan:</span>
                <span>{selectedPlan.name}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="font-medium">Amount:</span>
                <span>
                  {selectedPlan.price}
                  {selectedPlan.period}
                </span>
              </div>
              <div className="flex justify-between mb-2">
                <span className="font-medium">Payment Method:</span>
                <span className="capitalize">{paymentMethod}</span>
              </div>
              <div className="mt-4 p-3 bg-muted rounded-md text-sm">
                By clicking "Confirm Payment", you agree to our Terms of Service and authorize us to charge your
                selected payment method.
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowConfirmation(false)}>
              Back
            </Button>
            <Button onClick={handleConfirmPayment}>Confirm Payment</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

